<?php
//以下代码为PHP核心代码 如若不明 请勿修改
include './rule/cxurl.php';
if($net){$url=$cxlink.'/index.php/whole/index/'.$net;}else{$url=$cxlink.'/index.php/whole/index/1~~~~~~~0~addtime~~1';}
 //初始化
    $curl = curl_init();
    //设置抓取的url
    curl_setopt($curl, CURLOPT_URL, $url);
    //设置头文件的信息作为数据流输出
    curl_setopt($curl, CURLOPT_HEADER, 1);
    //设置获取的信息以文件流的形式返回，而不是直接输出。
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);    // https请求 不验证证书和hosts
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    //执行命令
    $response = curl_exec($curl);
	$content = curl_exec($curl);
    //关闭URL请求
    curl_close($curl);

$list_match='#<li><a href="/index.php/show/index/(.*?)"><b>(.*?)</b><img src="(.*?)" /><span>(.*?)</span></a></li>#';//首页老尝鲜
$list_match_result = array(
		'id'=>1,
		'img'=>3,
		'title'=>4,
	);
    preg_match_all($list_match,$content,$list_temp);
	foreach($list_temp[$list_match_result['id']] as $k=>$c){
		$resultcx[$k]['id'] = $list_temp[$list_match_result['id']][$k];
		$resultcx[$k]['img'] = $list_temp[$list_match_result['img']][$k];
		$resultcx[$k]['title'] = $list_temp[$list_match_result['title']][$k];
	}
?>