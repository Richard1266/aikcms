<?php
include './rule/cxurl.php';
$content=file_get_contents($cxlink);
$list_match='#<li><a href="/index.php/show/index/(.*?)"><b></b><img src="(.*?)" /><span>(.*?)</span></a></li>#';//首页老尝鲜
$list_match_result = array(
		'id'=>1,
		'img'=>2,
		'title'=>3,
	);
    preg_match_all($list_match,$content,$list_temp);
	foreach($list_temp[$list_match_result['id']] as $k=>$c){
		$resultcx[$k]['id'] = $list_temp[$list_match_result['id']][$k];
		$resultcx[$k]['img'] = $list_temp[$list_match_result['img']][$k];
		$resultcx[$k]['title'] = strip_tags($list_temp[$list_match_result['title']][$k]);
}
?>