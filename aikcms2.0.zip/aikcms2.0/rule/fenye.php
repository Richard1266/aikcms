<?php
$responsefenye = strstr($responsefenye, "<div monitor-desc='分页'") ;
$responsefenye = strstr($responsefenye, '</div>',TRUE) ;
$responsefenye = str_replace('<a','<li><a',$responsefenye);
$responsefenye = str_replace('</a>','</a></li>',$responsefenye);
$responsefenye = str_replace("<li><a target='_self' class='on'>","<li class='hidden-xs active'><a target='_self' class='on'>",$responsefenye);
$responsefenye = str_replace('http://www.360kan.com/',"./index.php?mode=list&net=",$responsefenye);
echo $responsefenye;
?>  