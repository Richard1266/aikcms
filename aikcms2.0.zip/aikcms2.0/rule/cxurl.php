<?php
if($aik_fresh_on == '2'){
$info=file_get_contents($aik_fresh_url);
$cxurl='#<span>(.*?)</span>#';
preg_match_all($cxurl, $info,$urlarr);
$cxlink=$urlarr[1][0];}else{
$cxlink=$aik_fresh_url;
}
?>