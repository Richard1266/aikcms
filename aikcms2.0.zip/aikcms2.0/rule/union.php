<?php
$code = range(0,9);
if(($aik_union_open=='1')||(($aik_union_open=='3')&&($code>4))){
$num = range(0,99);
shuffle($num);
$info=file_get_contents('http://demo.dataoke.com/index.php?r=p&u=1');
$info = strstr($info, '<div class="goods-list clearfix">') ;
//print_r($info);
$vname='#<p class="tit">(.*?)</p>#';                        
$imgg='#<img class="img" src="(.*?)" width="100%"  alt="">#';
$lianjie='#<a href="/(.*?)1" target="_blank">#';
$quan='#<i><b>¥</b>(.*?)</i>#';
$quanh='#<b>券后</b> ¥ <span>(.*?)</span>#';
preg_match_all($vname,$info,$namearr);
preg_match_all($imgg,$info,$imggarr);  
preg_match_all($lianjie,$info,$lianarr);  
preg_match_all($quan,$info,$quanarr);   
preg_match_all($quanh,$info,$quanharr); 
           $img=$imggarr[1];//取出图片链接
           $name=$namearr[1];//取出名字
		   $iidd=$lianarr[1];//取出名字
		   $daiq=$quanarr[1];
		   $daih=$quanharr[1];
		   $unionurl=$aik_union_dtk;
		   $unionid=$aik_union_dtkid;
}elseif(($aik_union_open=='2')||(($aik_union_open=='3')&&($code<5))){		   
$num = range(0,39);
shuffle($num);
$info=file_get_contents('http://demo.jingtuitui.com/?r=real');
//$info = strstr($info, '<ul class="clearfix" style="margin-right: -17px;">') ;
//print_r($info);
$vname='#data-img="(.*?)" alt="(.*?)"#';                        
$lianjie='#class="main_icon_out" href="/(.*?)"#';
$quan='#<span class="price_new_c">￥(.*?)</span>#';
$quanh='#<span class="price_new_a">￥(.*?)</span>#';
preg_match_all($vname,$info,$namearr);
preg_match_all($lianjie,$info,$lianarr);  
preg_match_all($quan,$info,$quanarr);   
preg_match_all($quanh,$info,$quanharr); 
           $img=$namearr[1];//取出图片链接
           $name=$namearr[2];//取出名字
		   $iidd=$lianarr[1];//取出链接
		   $daiq=$quanarr[1];//优惠券
		   $daih=$quanharr[1];
		   $unionurl=$aik_union_jtt;
		   $unionid='';
}