<?php
echo '

<li><a class="'.$movie.'" href="./index.php?mode=list&fl=dianying" title="电影">电影</a></li>
<li><a class="'.$tv.'" href="./index.php?mode=list&fl=dianshi" title="电视剧">电视剧</a></li>
<li><a class="'.$dm.'" href="./index.php?mode=list&fl=dongman" title="动漫">动漫</a></li>
<li><a class="'.$zy.'" href="./index.php?mode=list&fl=zongyi" title="综艺">综艺</a></li>
</ul>
</div>
<div class="content-meun clearfix"><a class="head" href="javascript:;" data-toggle="collapse" data-target="#collapse"><span class="text">已选择</span><span>'.$yixuanze.'</span></a><div class="item collapse" id="collapse">
<ul class="visible-sm visible-xs clearfix">
<li><a class="'.$movie.'" href="./index.php?mode=list&fl=dianying" title="电影">电影</a></li>
<li><a class="'.$tv.'" href="./index.php?mode=list&fl=dianshi" title="电视剧">电视剧</a></li>
<li><a class="'.$dm.'" href="./index.php?mode=list&fl=dongman" title="动漫">动漫</a></li>
<li><a class="'.$zy.'" href="./index.php?mode=list&fl=zongyi" title="综艺">综艺</a></li>
</ul>
<ul class=" clearfix"><li class="text"><span class="text-muted">按类型</span></li>';
$response0 = strstr($response0, '<dt class="type">类型:</dt>') ;
$response0 = strstr($response0, '</dd>',TRUE) ;
$response0 = str_replace('<a class="js-tongjip"',"<li><a ",$response0);
$response0 = str_replace('</a>',"</li></a> ",$response0);
$response0 = str_replace('<dt class="type">类型:</dt>',"",$response0);
$response0 = str_replace('<b class="on">','<li><a class="active">',$response0);
$response0 = str_replace('</b>','</a></li>',$response0);
$response0 = str_replace('<dd class="item g-clear js-filter-content">',"",$response0);
$response0 = str_replace('http://www.360kan.com/',"./index.php?mode=list&net=",$response0);
echo $response0;
if($fl == 'zongyi'){}else{
 echo '
</ul><ul class="clearfix"><li class="text"><span class="text-muted">按年代</span></li>';}
$response = strstr($response, '<dt class="type">年代:</dt>') ;
$response = strstr($response, '</dd>',TRUE) ;
$response = str_replace('<a class="js-tongjip"',"<li><a ",$response);
$response = str_replace('</a>',"</li></a> ",$response);
$response = str_replace('<dt class="type">年代:</dt>',"",$response);
$response = str_replace('<b class="on">','<li><a class="active">',$response);
$response = str_replace('</b>','</a></li>',$response);
$response = str_replace('<dd class="item g-clear js-filter-content">',"",$response);
$response = str_replace('http://www.360kan.com/',"./index.php?mode=list&net=",$response);
echo $response;
echo '
 </ul><ul class="clearfix"><li class="text"><span class="text-muted">按地区</span></li>'; 
$response1 = strstr($response1, '<dt class="type">地区:</dt>') ;
$response1 = strstr($response1, '</dd>',TRUE) ;
$response1 = str_replace('<a class="js-tongjip"',"<li><a ",$response1);
$response1 = str_replace('</a>',"</li></a> ",$response1);
$response1 = str_replace('<dt class="type">地区:</dt>',"",$response1);
$response1 = str_replace('<b class="on">','<li><a class="active">',$response1);
$response1 = str_replace('</b>','</a></li>',$response1);
$response1 = str_replace('<dd class="item g-clear js-filter-content">',"",$response1);
$response1 = str_replace('http://www.360kan.com/',"./index.php?mode=list&net=",$response1);
echo $response1;
if($fl == 'dongman'){}else{
 echo '
</ul><ul class="clearfix"><li class="text"><span class="text-muted">按明星</span></li>'; }
$response2 = strstr($response2, '<dt class="type">明星:</dt>') ;
$response2 = strstr($response2, '</dd>',TRUE) ;
$response2 = str_replace('<a class="js-tongjip"',"<li><a ",$response2);
$response2 = str_replace('</a>',"</li></a> ",$response2);
$response2 = str_replace('<dt class="type">明星:</dt>',"",$response2);
$response2 = str_replace('<b class="on">','<li><a class="active">',$response2);
$response2 = str_replace('</b>','</a></li>',$response2);
$response2 = str_replace('<dd class="item g-clear js-filter-content">',"",$response2);
$response2 = str_replace('http://www.360kan.com/',"./index.php?mode=list&net=",$response2);
echo $response2; 
?>