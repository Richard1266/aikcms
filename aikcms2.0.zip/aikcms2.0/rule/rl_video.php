<?php
$url_array = explode("/", $net);
$player='http://www.360kan.com'.$net;

$tvinfo=file_get_contents($player);
$tvinfoo=file_get_contents($player);
$tvinfooo=file_get_contents($player);
$tvinfoo = strstr($tvinfoo, '<div class="g-clear js-month-page" style="display:block;">') ;// 综艺
$tvinfoo = strstr($tvinfoo, '<div class="juji-page js-juji-page" style="display: none">',TRUE) ;
$tvzz='#<div class="num-tab-main g-clear\s*js-tab"\s*(style="display:none;")?>[\s\S]+?<a data-num="(.*?)" data-daochu="to=(.*?)" href="(.*?)">[\s\S]+?</div>#';
$tvzz1='#<a data-num="(.*?)" data-daochu="to=(.*?)" href="(.*?)">#';
$bflist='#<a data-daochu="to=(.*?)" class="btn js-site ea-site ea-site-(.*?)" href="(.*?)">(.*?)</a>#';
$jianjie='#<p class="item-desc">(.*?)<#';//电影，电视简介
$biaoti='#<h1>(.*?)</h1>#';

$dmend='#<p class="tag">(.*?)<span>(.*?)</span>(.*?)</p>#';

$zytimu="#<li  title='(.*?)' class='w-newfigure w-newfigure-180x153'><a href='(.*?)' data-daochu=to=(.*?) class='js-link'><div class='w-newfigure-imglink g-playicon js-playicon'> <img src='(.*?)' data-src='(.*?)' alt='(.*?)'  /><span class='w-newfigure-hint'>(.*?)</span></div><div class='w-newfigure-detail'><p class='title g-clear'><span class='s1'>(.*?)</span></p></div></a></li>#";
$bofang='#<a data-daochu="(.*?)" class="btn js-site ea-site (.*?)" href="(.*?)">(.*?)</a>
#';
preg_match_all($jianjie,$tvinfo,$jjarr);
preg_match_all($tvzz, $tvinfo,$tvarr);
preg_match_all($bflist, $tvinfo,$tvlist);
preg_match_all($biaoti,$tvinfo,$btarr);
preg_match_all($dmend,$tvinfo,$dmbtarrd);
preg_match_all($zytimu,$tvinfoo,$zybtarr);
preg_match_all($bofang,$tvinfo,$bfarr);
$mvsrc=$tvlist[3];
$bflu=$tvlist[1];
$bfyuan=$tvlist[4];
$jian=$jjarr[1][0];
$timu=$btarr[1][0];
$zybiaoti=$zybtarr[1];
$zylink=$zybtarr[2];
$zytime=$zybtarr[7];
$zyimg=$zybtarr[5];
$dmendd=$dmbtarrd[2][0];
if($dmendd>28){
$tvinfooo = strstr($tvinfooo, '<div class="series-slice-view g-clear js-series0">') ;// 动漫1
$tvinfooo = strstr($tvinfooo, '<div class="c-body g-clear">',TRUE) ;
$dmtimu='#<a data-num="(.*?)"data-daochu="to=(.*?)" href="(.*?)">#';
preg_match_all($dmtimu,$tvinfooo,$dmbtarr);
$dmid=$dmbtarr[1];
$dmlink=$dmbtarr[3];
}else{
$tvinfooo = strstr($tvinfooo, '<div class="site-wrap" id="js-site-wrap">') ;// 动漫2
$tvinfooo = strstr($tvinfooo, '<div class="c-body g-clear">',TRUE) ;
$dmtimu='#<a data-num="(.*?)"data-daochu="to=(.*?)" href="(.*?)">#';
preg_match_all($dmtimu,$tvinfooo,$dmbtarr);
$dmid=$dmbtarr[1];
$dmlink=$dmbtarr[3];		
}
$mvsrc1=str_replace("http://cps.youku.com/redirect.html?id=0000028f&url=","","$mvsrc");
$zcf=implode($glue, $tvarr[0]);
preg_match_all($tvzz1, $zcf,$tvarr1);
//print_r($tvarr1);
$jishu=$tvarr1[1];
$b=$tvarr1[3];
$much=1;
$id=2;
$idd=2;
$iddd=2;
$url = $player;
$array=explode('/', $url);
$dsjid=$array[4];
$ch = curl_init($url); //初始化
curl_setopt($ch, CURLOPT_HEADER, 0); // 不返回header部分
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回字符串，而非直接输出
curl_setopt($ch, CURLOPT_USERAGENT, "Dalvik/1.6.0 (Linux; U; Android 4.1.4; DROID RAZR HD Build/9.8.1Q-62_VQW_MR-2)");
curl_setopt($ch, CURLOPT_REFERER, "-");
$html = curl_exec($ch);
curl_close($ch);
$str = $html;
if (strstr($aik_tort,$timu)){header('location:index.php?mode=404');}
?>


