<?php
$url='http://www.360kan.com/dongman/list';
$info=file_get_contents($url);
$vname='#<span class="s1">(.*?)</span>#';//取出电影的名字
$vlist='#<a class="js-tongjic" href="(.*?)">#';//链接
$vimg='#<div class="cover g-playicon">
                                <img src="(.*?)">#';//取出电影的封面
$nname='#<span class="hint">(.*?)</span>#';
$fname='#<span class="s2">(.*?)</span>#';
$list_match='#<li><a href="/index.php/show/index/(.*?)"><b></b><img src="(.*?)" /><span>(.*?)</span></a></li>
#';
$vname_result = array('name'=>1,);
$vlist_result = array('link'=>1,);
$vimg_result = array('img'=>1,);
$nname_result = array('nname'=>1,);
$fname_result = array('fname'=>1,);
	preg_match_all($vname, $info,$namearr);
    preg_match_all($vlist, $info,$listarr);
    preg_match_all($vimg, $info,$imgarr);
    preg_match_all($nname, $info,$nnamearr);
    preg_match_all($fname, $info,$fnamearr);	
	
	foreach($namearr[$vname_result['name']] as $k=>$c){
		$resultdm[$k]['name'] = $namearr[$vname_result['name']][$k];
		$resultdm[$k]['link'] = $listarr[$vlist_result['link']][$k];
		$resultdm[$k]['img'] = $imgarr[$vimg_result['img']][$k];
		$resultdm[$k]['nname'] = $nnamearr[$nname_result['nname']][$k];
}	
 