<?php
$username=$_COOKIE["username"]; 

$link='http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'].'';
if (isset($_POST['save'])){
  if(!isset($username)){
		alert_href('请登录后操作！','/user.php?mode=login');
	};	
$result = mysql_query('select * from aikcms_user_fav where aik_fav_url = "'.$link.'" and aik_fav_userid = '.get_user_id($username).'');
$row=mysql_fetch_array($result);
if($row){
alert_back('此视频已经收藏过了哦!');
}else{
mysql_query("INSERT INTO aikcms_user_fav (aik_fav_userid, aik_fav_name, aik_fav_url, aik_fav_time) VALUES (".get_user_id($username).", '".$timu."', '".$link."',  CURDATE())");
alert_back('成功加入收藏夹!');
}
}else{
$user_query4 = mysql_query("SELECT min(id) FROM aikcms_user_history WHERE aik_history_userid = '".get_user_id($username)."' ");
$row4 = mysql_fetch_array($user_query4);
$minid=$row4['min(id)'];
$qid = mysql_query("SELECT count(id) FROM aikcms_user_history WHERE aik_history_userid = '".get_user_id($username)."'");
$res = mysql_fetch_array($qid);
$count = $res[0];
$result = mysql_query('select * from aikcms_user_history where aik_history_name = "' .$timu. '" and aik_history_userid = "'.get_user_id($username).'"');
$row=mysql_fetch_array($result);
if($row){
mysql_query("delete from aikcms_user_history WHERE id = '".$row['id']."';");
}
if($count==10){mysql_query("delete from aikcms_user_history WHERE id = '".$minid."';");
mysql_query("INSERT INTO aikcms_user_history (aik_history_userid, aik_history_name, aik_history_url, aik_history_time) VALUES (".get_user_id($username).", '".$timu."', '".$link."',  CURDATE())");
}
if($count<10){
mysql_query("INSERT INTO aikcms_user_history (aik_history_userid, aik_history_name, aik_history_url, aik_history_time) VALUES (".get_user_id($username).", '".$timu."', '".$link."',  CURDATE())");
}
}