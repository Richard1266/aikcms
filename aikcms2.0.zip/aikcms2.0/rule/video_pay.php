﻿<?php
//判定会员是否登录
$username=$_COOKIE["username"]; 
$userid=$_COOKIE["userid"];
if(isset($username)){//登陆
//获取会员信息
     $result = mysql_query('select * from aikcms_user where aik_user_name="'.$username.'"');//查询会员积分
	 if($row = mysql_fetch_array($result)){
     $aik_user_int=$row['aik_user_int'];//会员积分
     $aik_user_groupend=$row['aik_user_groupend'];//到期时间
	 $aik_user_group=$row['aik_user_group'];//会员组
     }		 
	 if($aik_user_group<>"0"){//是会员
		 if(time()>$aik_user_groupend){//到期
		 mysql_query('update `aikcms_user`  set  aik_user_group="0" , aik_user_groupend="0" where aik_user_name = '.$username.'');	
	     alert_href('会员已到期!','user.php?mode=index');
		 }else{//没到期
		 if(!in_array($aik_user_group, $array_video_usergroup)&&(!in_array('0', $array_video_usergroup))){alert_href('该视频仅支持 / '.aik_video_usergroup($video_usergroupid).'观看！',$aik_domain.'user.php?mode=vip');}
			 
		 }//到期	 
	 }else{//不是会员
	        if(!in_array('0', $array_video_usergroup)){ //是会员视频
			 alert_href('该视频仅支持 / '.aik_video_usergroup($video_usergroupid).'观看！',$aik_domain.'user.php?mode=vip');
			}elseif($aik_video_int<>'0'){ //需要积分
                 if($aik_video_int > $aik_user_int){//积分不够
	             alert_href('对不起,此视频需要 '.$aik_video_int.' 个积分，请推广网站或充值积分！',$aik_domain.'user.php?mode=int');	
                   }else{//积分足够
                         $link='http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'].'';
	                     if(aik_video_buy($aik_video_id,$userid)==0){ //没有观看过、购买过
                         $_data['aik_user_int'] = $aik_user_int-$aik_video_int;
                         $updateint = mysql_query('update aikcms_user set '.arrtoupdate($_data).' where aik_user_name="'.$username.'"');
                         $order = date("YmdHis",time()).str_rand();
                         $updateorder= mysql_query('insert into aikcms_user_order (aik_order,aik_order_name,aik_order_videoid,aik_order_videourl,aik_order_price,aik_order_userid,aik_order_time) values ('.$order.',"《'.$timu.'》",'.$aik_video_id.',"'.$link.'","'. $aik_video_int.'积分",'.$userid.','.time().')');	
	                     if ($updateint&&$updateorder){ alert_href('您成功支付'.$aik_video_int.'积分,点击确定观看视频!',$link);}		
	                     }
                         }
	         }
	 }
}else{
	if((!in_array('0', $array_video_usergroup))||($aik_video_int<>'0')){ //是会员视频
			 alert_href('该视频为收费视频，请登录后观看！',$aik_domain.'user.php?mode=login');
	}elseif($aik_login_play=='1'){alert_href('请登录后免费观看！',$aik_domain.'user.php?mode=login');}
	
}
	 

	
	

	
	
	
	
	
	
	
	

	
	













