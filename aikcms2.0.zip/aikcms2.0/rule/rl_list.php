<?php
$content=file_get_contents($url);
$vname='#<span class="s1">(.*?)</span>#';//取出电影的名字
$vlist='#<a class="js-tongjic" href="(.*?)">#';//取出电影的链接
$vstar='# <p class="star">(.*?)</p>#';//取出电影的主演
$vimg='#<div class="cover g-playicon">
                                <img src="(.*?)">#';//取出电影的封面

$beizhu='#<span class="hint">(.*?)</span>#';//取出电影的年份

$vname_result = array('name'=>1,);
$vlist_result = array('link'=>1,);
$vstar_result = array('star'=>1,);
$vimg_result = array('img'=>1,);
$beizhu_result = array('beizhu'=>1,);
	preg_match_all($vname, $content,$namearr);
    preg_match_all($vlist, $content,$listarr);
    preg_match_all($vstar, $content,$stararr);
    preg_match_all($vimg, $content,$imgarr);
    preg_match_all($beizhu, $content,$beizhuarr);	
	
	foreach($namearr[$vname_result['name']] as $k=>$c){
		$resultlb[$k]['name'] = $namearr[$vname_result['name']][$k];
		$resultlb[$k]['link'] = $listarr[$vlist_result['link']][$k];
		$resultlb[$k]['star'] = $stararr[$vstar_result['star']][$k];
		$resultlb[$k]['img'] = $imgarr[$vimg_result['img']][$k];
		$resultlb[$k]['beizhu'] = $beizhuarr[$beizhu_result['beizhu']][$k];
}
?>

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
