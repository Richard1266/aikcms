<?php
if($zy=='okzy'){
	$sourl = "http://okokzy.cc/";
	}elseif($zy=='zdzy'){	
	$sourl = "http://zuidazy.net/";}elseif($zy=='156zy'){	
	$sourl = "http://www.156zy.com/";}elseif($zy=='zkzy'){	
	$sourl = "http://zuikzy.com/";}elseif($zy=='zxzy'){	
	$sourl = "http://www.ziyuanpian.com/";}
	
$link0= $sourl.'?m=vod-detail-id-'.$vodid.'.html';
$tvinfo=file_get_contents($link0);
if($zy=='zkzy'){
$bofang='#<input type="checkbox" name="copy_sel" value="(.*?)" checked=#';
$zyname='#<li class="sa">影片名称: <!--片名开始-->(.*?)<!--片名结束--></li>#';
}else{
$bofang='#checked="" />(.*?)</li>#';
$zyname='#<h2>(.*?)</h2>#';
}
preg_match_all($bofang,$tvinfo,$bfarr);
preg_match_all($zyname,$tvinfo,$zyarr);
$link=$bfarr[1];
$timu=$zyarr[1][0];
$szlen = count($link);
$jiji= strtok($link[0], '$');
$zyfang=substr(strrchr($link[0], "$"), 1);