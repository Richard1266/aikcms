<?php
if($vid){
include 'cxurl.php';
$link=file_get_contents($cxlink.'/index.php/play/index/'.$vid);
$name='#<h3>&nbsp;&nbsp;(.*?)</h3>#';
$jishu='#<li><a id="(.*?)" href="/index.php/play/index/(.*?)">(.*?)</a></li>
#';
$bobo='#<iframe src="(.*?)" marginwidth="0" marginheight="0" border="0" scrolling="no" frameborder="0" topmargin="0" width="100%" height="100%"></iframe>#';
preg_match_all($name,$link,$nmarr);
preg_match_all($jishu,$link,$jjarr);
preg_match_all($bobo,$link,$bfarr);
$timu=$nmarr[1][0];
$iidd=$jjarr[1];
$ljie=$jjarr[2];
$jjshu=$jjarr[3];
$bofang=$bfarr[1][0];
 $b= (strpos($bofang,"/y"));
    $c= (strpos($bofang,"e/"));
	$ye=substr($bofang,$b+2,$c-1); 
	//echo $ye;
if ($ye=='unparse'){
$fang=$cxlink.$bofang;}
else
{$fang=$bofang;}
}elseif($vod){//资源站
$result = mysql_query("select * from aikcms_video  where id='$vod';");
if ($row = mysql_fetch_array($result)){
		$timu = $row['aik_video_name'];
		$bofang = $row['aik_video_url'];
		$jiexi = $row['aik_video_jiexi']<>'' ? $row['aik_video_jiexi']:'';
		$aik_video_seo = $row['aik_video_seo'];
		$aik_video_int = $row['aik_video_int'];
		$video_usergroupid = get_video_usergroup($row['aik_video_group'])== '0' ? $row['aik_video_usergroup']:get_video_usergroup($row['aik_video_group']);
		$array_video_usergroup = explode(",", $video_usergroupid); 	
		$aik_video_id = $row['id'];
		$arr = explode("\n",$bofang);
		$arry = explode("\n",$bofang);
	   }	
}
if (strstr($aik_tort,$timu)){header('location:index.php?mode=404');}
?>