<?php
$url='http://www.360kan.com/dianshi/list';
$info=file_get_contents($url);
$vname='#<span class="s1">(.*?)</span>#';//取出电影的名字
$vlist='#<a class="js-tongjic" href="(.*?)">#';//链接
$vstar='#<p class="star">(.*?)</p>#';//取出电影的主演
$vimg='#<div class="cover g-playicon">
                                <img src="(.*?)">#';//取出电影的封面
$nname='#<span class="hint">(.*?)</span>#';
$list_match='#<li><a href="/index.php/show/index/(.*?)"><b></b><img src="(.*?)" /><span>(.*?)</span></a></li>#';
$vname_result = array('name'=>1,);
$vlist_result = array('link'=>1,);
$vstar_result = array('star'=>1,);
$vimg_result = array('img'=>1,);
$nname_result = array('nname'=>1,);
	preg_match_all($vname, $info,$namearr);
    preg_match_all($vlist, $info,$listarr);
    preg_match_all($vstar, $info,$stararr);
    preg_match_all($vimg, $info,$imgarr);
    preg_match_all($nname, $info,$nnamearr);	
	
	foreach($namearr[$vname_result['name']] as $k=>$c){
		$resulttv[$k]['name'] = $namearr[$vname_result['name']][$k];
		$resulttv[$k]['link'] = $listarr[$vlist_result['link']][$k];
		$resulttv[$k]['star'] = $stararr[$vstar_result['star']][$k];
		$resulttv[$k]['img'] = $imgarr[$vimg_result['img']][$k];
		$resulttv[$k]['nname'] = $nnamearr[$nname_result['nname']][$k];//更新集数
}