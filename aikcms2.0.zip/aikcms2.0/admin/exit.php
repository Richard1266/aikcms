<?php
unset($_SESSION['adminname']);
if (! empty ( $_COOKIE ['adminname'] ) )   
    {  
        setcookie ( "adminname", '', time () - 3600 * 24 * 365 );   
    }  
header('location:../../');
?>
</body>
</html>