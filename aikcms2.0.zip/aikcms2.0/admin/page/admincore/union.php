<?php
if (isset($_POST['update'])) {
	$_data['aik_union_open'] = $_POST['aik_union_open'];
	$_data['aik_union_dtk'] = $_POST['aik_union_dtk'];
	$_data['aik_union_dtkid'] = $_POST['aik_union_dtkid'];
	$_data['aik_union_jtt'] = $_POST['aik_union_jtt'];
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('联盟信息修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
?>