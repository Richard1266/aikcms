<?php
if (isset($_POST['update'])) {
	$_data['aik_zhibo_name'] = $_POST['aik_zhibo_name'];
	$_data['aik_zhibo_url'] = $_POST['aik_zhibo_url'];
	$sql = 'update aikcms_zhibo  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
		alert_href('直播源修改成功!', 'zhibo.php');	
	} else {
		alert_back('修改失败!');
	}
}
