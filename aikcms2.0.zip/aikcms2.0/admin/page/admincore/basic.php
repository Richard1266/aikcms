<?php
if (isset($_POST['update'])) {
	$_data['aik_name'] = $_POST['aik_name'];
	$_data['aik_domain'] = $_POST['aik_domain'];
	$_data['aik_title'] = $_POST['aik_title'];
	$_data['aik_keywords'] = $_POST['aik_keywords'];
	$_data['aik_desc'] = $_POST['aik_desc'];
	$_data['aik_shouquan'] = $_POST['aik_shouquan'];
	$_data['aik_template'] = $_POST['aik_template'];
	$_data['aik_mtemplate'] = $_POST['aik_mtemplate'];
	$_data['aik_icp'] = $_POST['aik_icp'];
	$_data['aik_tongji'] = htmlspecialchars($_POST['aik_tongji']);
	$_data['aik_changyan'] = htmlspecialchars($_POST['aik_changyan']);
	$_data['aik_jiexi1'] = $_POST['aik_jiexi1'];
	$_data['aik_jiexi2'] = $_POST['aik_jiexi2'];
	$_data['aik_jiexi3'] = $_POST['aik_jiexi3'];
	$_data['aik_jiexi4'] = $_POST['aik_jiexi4'];
	$_data['aik_jiexi5'] = $_POST['aik_jiexi5'];
	$_data['aik_jiexi6'] = $_POST['aik_jiexi6'];
	$_data['aik_cache'] = $_POST['aik_cache'];
	$_data['aik_weijing'] = $_POST['aik_weijing'];
	$_data['aik_onlym'] = $_POST['aik_onlym'];
	$_data['aik_fbjiexi1'] = $_POST['aik_fbjiexi1'];
	$_data['aik_fbjiexi2'] = $_POST['aik_fbjiexi2'];	
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('系统设置修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
?>