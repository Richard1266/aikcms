<?php
if (isset($_POST['update'])) {
	$_data['aik_video_name'] = $_POST['aik_video_name'];
	$_data['aik_video_seo'] = $_POST['aik_video_seo'];
	$_data['aik_video_img'] = $_POST['aik_video_img'];
	$_data['aik_video_group'] = $_POST['aik_video_group'];
	$_data['aik_video_pay'] = $_POST['aik_video_pay'];
	$_data['aik_video_int'] = $_POST['aik_video_int'];
	$hobby_arr = array();
    $hobby_arr = $_POST['usergroup'];
    $_data['aik_video_usergroup'] = implode(',', $hobby_arr);//把数组转换为字符串
	$_data['aik_video_level'] = $_POST['aik_video_level'];
	$_data['aik_video_jiexi'] = $_POST['aik_video_jiexi'];
	$_data['aik_video_url'] = $_POST['aik_video_url'];
	$_data['aik_video_remarks'] = $_POST['aik_video_remarks'];
	if(move_uploaded_file($_FILES['aik_video_img']['tmp_name'],'../../../upload/'.$_FILES['aik_video_img']['name'])){  
	$_data['aik_video_img']='/upload/'.$_FILES['aik_video_img']['name'];}	
	null_back($_data['aik_video_img'], '请输入或上传图片');
	$sql = 'update aikcms_video  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
		alert_href('视频更新成功!', 'video_list.php');	
	} else {
		alert_back('修改失败!');
	}
	
}
