<?php
if (isset($_POST['update'])) {
	$_data['aik_ad_seat'] = $_POST['aik_ad_seat'];
	$_data['aik_ad_remarks'] = $_POST['aik_ad_remarks'];
	$_data['aik_ad_code'] = htmlspecialchars($_POST['aik_ad_code']);	
	$sql = 'update aikcms_ad  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
	alert_parent('广告编辑成功!');
	} else {
	alert_back('编辑失败!');
	}
}

