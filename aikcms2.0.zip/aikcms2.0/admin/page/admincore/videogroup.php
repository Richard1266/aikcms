<?php
if (isset($_POST['save'])) {
	$_data['aik_videogroup_name'] = $_POST['aik_videogroup_name'];
	null_back($_POST['aik_videogroup_name'], '请输入视频分组名称！');
	$hobby_arr = array();
    $hobby_arr = $_POST['usergroup'];
    $_data['aik_videogroup_usergroup'] = implode(',', $hobby_arr);//把数组转换为字符串
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_videogroup (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_href('视频分类添加成功!', 'videogroup.php');
	} else {
		alert_back('添加失败!');
	}
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_videogroup where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_href('删除成功!', 'videogroup.php');
	} else {
		alert_back('删除失败！');
	}
}