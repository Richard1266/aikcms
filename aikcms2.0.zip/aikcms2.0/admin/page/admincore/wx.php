<?php
if (isset($_POST['save'])) {
	$_data['aik_wx_token'] = $_POST['aik_wx_token'];
	$_data['aik_wx_img'] = $_POST['aik_wx_img'];
	$_data['aik_wx_reply'] = $_POST['aik_wx_reply'];
	null_back($_data['aik_wx_img'], '请输入图片地址');
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('微信对接参数修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
?>