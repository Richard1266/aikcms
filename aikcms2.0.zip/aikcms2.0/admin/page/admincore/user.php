<?php
if (isset($_POST['wd'])) {
null_back($_POST['wd'], '请输入要查找的用户名！');}
if (isset($_POST['execute'])) {
	null_back($_POST['id'], '请至少选中一项！');
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	switch ($_POST['execute_method']) {
		case 'on':
			$sql = 'update aikcms_user set aik_user_on = 1 where id in (' . $id . ')';
			break;
		case 'off':
			$sql = 'update aikcms_user set aik_user_on = 0 where id in (' . $id . ')';
			break;
		case 'del':
			$sql = 'delete from aikcms_user where id in (' . $id . ')';
			break;
		default:
			alert_back('请选择要执行的操作');
	}
	mysql_query($sql);
	alert_href('执行成功!', 'user.php');
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_user where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_href('删除成功!', 'user.php');
	} else {
		alert_back('删除失败！');
	}
}
