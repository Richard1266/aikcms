<?php
if (isset($_POST['save'])) {
	$_data['aik_nav_name'] = $_POST['aik_nav_name'];
	$_data['aik_nav_color'] = $_POST['aik_nav_color'];
	$_data['aik_nav_papa'] = $_POST['aik_nav_papa'];
	$_data['aik_nav_id'] = $_POST['aik_nav_id'];
	$_data['aik_nav_url'] = $_POST['aik_nav_url'];
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_nav (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
		alert_parent('导航发布成功!');
	} else {
		alert_back('添加失败!');
	}
}

