<?php
if (isset($_POST['update'])) {
	$_data['aik_user_name'] = $_POST['aik_user_name'];
    $t=time();
	$filename = $_data['aik_user_name'].$t.'.gif';
	if(!empty($_POST['aik_user_pw'])){$_data['aik_user_pw'] = md5($_POST['aik_user_pw']);}
	$_data['aik_user_qq'] = $_POST['aik_user_qq'];
	$_data['aik_user_group'] = $_POST['aik_user_group'];
	$_data['aik_user_groupend'] =  $_POST['aik_user_groupend']=="0" ? "0":strtotime($_POST['aik_user_groupend']);
	$_data['aik_user_allmoney'] = $_POST['aik_user_allmoney'];
	$_data['aik_user_int'] = $_POST['aik_user_int'];
	if(move_uploaded_file($_FILES['aik_user_img']['tmp_name'],'../../../upload/'.$filename)){  
	$_data['aik_user_img']='/upload/'.$filename;}		
	$sql = 'update aikcms_user  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
		alert_href('用户资料修改成功!', 'user.php');	
	} else {
		alert_back('修改失败!');
	}
	
}
?>