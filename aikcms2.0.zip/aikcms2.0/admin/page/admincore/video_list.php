<?php
if (isset($_POST['execute'])) {
	null_back($_POST['id'], '请至少选中一项！');
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	$sql = 'delete from aikcms_video where id in (' . $id . ')';
	mysql_query($sql);
	alert_href('删除成功!', 'video_list.php');
}
if (isset($_POST['update'])) {
	null_back($_POST['id'], '请至少选中一项！');
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	$array_id = explode(",", $id); 	
  foreach($array_id as $a){ 
  $roww = mysql_fetch_array(mysql_query('select * from aikcms_video where id='.$a.''));
  include '../caiji/'.$roww['aik_video_col'];  
}
alert_href('视频更新完成！', 'video_list.php');
}

if (isset($_GET['updateimg'])) {
    include '../caiji/'.$_GET['cjgz'];	
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_video where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_href('删除成功!', 'video_list.php');
	} else {
		alert_back('删除失败！');
	}
}