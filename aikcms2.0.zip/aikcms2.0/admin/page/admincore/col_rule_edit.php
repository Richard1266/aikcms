<?php
if (isset($_POST['update'])) {
    $_data['aik_col_name'] = $_POST['aik_col_name'];
	$_data['aik_col_url'] = $_POST['aik_col_url'];
	$_data['aik_col_urlstart'] = $_POST['aik_col_urlstart'];
	$_data['aik_col_urlend'] = $_POST['aik_col_urlend'];
	$_data['aik_col_videogroup'] = $_POST['aik_col_videogroup'];
	$hobby_arr = array();
    $hobby_arr = $_POST['usergroup'];
    $_data['aik_col_usergroup'] = implode(',', $hobby_arr);//把数组转换为字符串
	$_data['aik_col_rule'] = $_POST['aik_col_rule'];
	$sql = 'update aikcms_colrule  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
		alert_href('视频采集规则修改成功!', 'col_rule.php');	
	} else {
		alert_back('修改失败!');
	}
	
}
?>