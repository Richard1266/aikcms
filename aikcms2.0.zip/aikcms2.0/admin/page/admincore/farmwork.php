﻿<?php
include('../data/conn.php');
function login()
{
	if(!isset($_COOKIE['adminname'])||empty($_COOKIE['adminname'])){
		echo "<script>alert('请登录！');window.location.href='../../login.php'</script>";
		exit();
	}
}