<?php
if (isset($_POST['update'])) {
	$_data['aik_nav_name'] = $_POST['aik_nav_name'];
	$_data['aik_nav_color'] = $_POST['aik_nav_color'];
	$_data['aik_nav_papa'] = $_POST['aik_nav_papa'];
	$_data['aik_nav_id'] = $_POST['aik_nav_id'];
	$_data['aik_nav_url'] = $_POST['aik_nav_url'];
	$sql = 'update aikcms_nav  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
		alert_href('导航修改成功!', 'nav.php');	
	} else {
		alert_back('修改失败!');
	}
	
}
?>