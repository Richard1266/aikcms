<?php
if (isset($_POST['save'])) {
	null_back($_POST['aik_admin'], '请填写帐号');
	if ($_POST['aik_pw'] != $_POST['aik_rpw']) {
		alert_back('两次输入的密码不一致');
	}
	$_data['aik_admin'] = $_POST['aik_admin'];
	if(!empty($_POST['aik_pw'])){$_data['aik_pw'] = md5($_POST['aik_pw']);}
	$_data['aik_admin_img'] = $_POST['aik_admin_img'];
	$_data['aik_admin_qq'] = $_POST['aik_admin_qq'];
	
	if(move_uploaded_file($_FILES['aik_admin_img']['tmp_name'],'../../../upload/'.$_FILES['aik_admin_img']['name'])){  
	$_data['aik_admin_img']='/upload/'.$_FILES['aik_admin_img']['name'];}	
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('管理员帐号编辑成功');
	} else {
		alert_back('编辑失败!');
	}
}
