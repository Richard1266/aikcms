<?php
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_gbook where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}
?>