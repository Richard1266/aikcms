<?php

if (isset($_POST['save'])) {
	$_data['aik_link_name'] = $_POST['aik_link_name'];
	$_data['aik_link_img'] = $_POST['aik_link_img'];
	$_data['aik_link_url'] = $_POST['aik_link_url'];
	$_data['aik_link_qq'] = $_POST['aik_link_qq'];
	if(move_uploaded_file($_FILES['aik_link_img']['tmp_name'],'../../../upload/'.$_FILES['aik_link_img']['name'])){  
	$_data['aik_link_img']='/upload/'.$_FILES['aik_link_img']['name'];}	
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_link (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_parent('友情链接添加成功!');
	} else {
		alert_back('添加失败!');
	}
}

