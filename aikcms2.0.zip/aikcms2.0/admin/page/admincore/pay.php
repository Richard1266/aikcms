<?php
if (isset($_POST['update'])) {
	$_data['aik_pay_open'] = $_POST['aik_pay_open'];
	$_data['aik_pay_name'] = $_POST['aik_pay_name'];
	$_data['aik_pay_id'] = $_POST['aik_pay_id'];
	$_data['aik_pay_key'] = $_POST['aik_pay_key'];
	$_data['aik_pay_url'] = $_POST['aik_pay_url'];
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('支付配置修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
?>