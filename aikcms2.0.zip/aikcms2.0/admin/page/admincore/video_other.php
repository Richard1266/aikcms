<?php
if (isset($_POST['save'])) {
	$_data['aik_fresh_on'] = $_POST['aik_fresh_on'];
	$_data['aik_fresh_url'] = $_POST['aik_fresh_url'];
	$_data['aik_rec_on'] = $_POST['aik_rec_on'];
	$_data['aik_login_play'] = $_POST['aik_login_play'];
	$_data['aik_tort'] = $_POST['aik_tort'];
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('参数修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
?>