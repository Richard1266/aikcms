<?php
if (isset($_POST['save'])) {
	$_data['aik_hd_name'] = $_POST['aik_hd_name'];
	$_data['aik_hd_img'] = $_POST['aik_hd_img'];
	$_data['aik_hd_link'] = $_POST['aik_hd_link'];
	if(move_uploaded_file($_FILES['aik_hd_img']['tmp_name'],'../../../upload/'.$_FILES['aik_hd_img']['name'])){  
	$_data['aik_hd_img']='/upload/'.$_FILES['aik_hd_img']['name'];}	
	null_back($_data['aik_hd_link'], '请输入或上传图片');
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_poster (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
		alert_parent('幻灯添加成功!');
	} else {
		alert_back('添加失败!');
	}
}

