<?php
if (isset($_POST['save'])) {
	$_data['aik_usergroup_name'] = $_POST['aik_usergroup_name'];
	$_data['aik_usergroup_price'] = $_POST['aik_usergroup_price'];
	$_data['aik_usergroup_length'] = $_POST['aik_usergroup_length'];
	$_data['aik_usergroup_rem'] = $_POST['aik_usergroup_rem'];
	if(move_uploaded_file($_FILES['aik_usergroup_img']['tmp_name'],'../../../upload/'.$_FILES['aik_usergroup_img']['name'])){  
	$_data['aik_usergroup_img']='/upload/'.$_FILES['aik_usergroup_img']['name'];}		
	null_back($_data['aik_usergroup_img'], '请输入或上传图片');
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_usergroup (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_parent('用户组添加成功!');
	} else {
		alert_back('添加失败!');
	}
}

