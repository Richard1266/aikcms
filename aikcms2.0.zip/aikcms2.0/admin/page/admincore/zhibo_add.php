<?php
if (isset($_POST['save'])) {
	$_data['aik_zhibo_name'] = $_POST['aik_zhibo_name'];
	$_data['aik_zhibo_url'] = $_POST['aik_zhibo_url'];
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_zhibo (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_parent('直播源添加成功!');
	} else {
		alert_back('添加失败!');
	}
}

