<?php
if (isset($_POST['update'])) {
	$_data['aik_usergroup_name'] = $_POST['aik_usergroup_name'];
	$_data['aik_usergroup_price'] = $_POST['aik_usergroup_price'];
	$_data['aik_usergroup_length'] = $_POST['aik_usergroup_length'];
	$_data['aik_usergroup_rem'] = $_POST['aik_usergroup_rem'];
	if(move_uploaded_file($_FILES['aik_usergroup_img']['tmp_name'],'../../../upload/'.$_FILES['aik_usergroup_img']['name'])){  
	$_data['aik_usergroup_img']='/upload/'.$_FILES['aik_usergroup_img']['name'];}		
	$sql = 'update aikcms_usergroup  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
	alert_href('用户组修改成功!', 'usergroup.php');	
	} else {
	alert_back('添加失败!');
	}
}

