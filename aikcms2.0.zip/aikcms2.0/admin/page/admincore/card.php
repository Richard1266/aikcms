<?php
if (isset($_POST['execute'])) {
	null_back($_POST['id'], '请至少选中一项！');
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	$sql = 'delete from aikcms_card where id in (' . $id . ')';
	mysql_query($sql);
	alert_href('删除成功!', 'card.php');
}

if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_card where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}