<?php
if (isset($_POST['update'])) {
	$_data['aik_user_open'] = $_POST['aik_user_open'];	
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('用户注册开启/关闭修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_usergroup where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}