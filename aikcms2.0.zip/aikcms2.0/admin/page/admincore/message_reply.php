<?php
if (isset($_POST['save'])) {
	$_data['aik_gbook_content'] = htmlspecialchars($_POST['aik_gbook_content']);
	$_data['aik_gbook_reply'] = $_POST['aik_gbook_reply'];
	$_data['aik_gbook_time'] = time();
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_gbook (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_back('留言回复成功!');
	} else {
	alert_back('发布失败!');
	}	
	
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_gbook where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}
