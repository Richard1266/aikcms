<?php
if (isset($_POST['update'])) {
	$_data['aik_postercome'] = $_POST['aik_postercome'];	
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('幻灯片来源修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_poster where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}