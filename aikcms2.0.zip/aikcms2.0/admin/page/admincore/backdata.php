<?php
include('../../../common/basic.php');
require_once("backdata.class.php");
$dbbck=new backupData($link);//实例化它，只要一个链接标识就行了 

if (isset($_POST['databack'])) {
	null_back($_POST['id'], '请至少选中一项！');
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	$dbbck->backupTables("aikcms","../../../common/databack/",array($id));
	alert_href('备份成功!','database_list.php');
}
if (isset($_GET['name'])) {
	$dbbck->backupTables("aikcms","../../../common/databack/",array($_GET['name']));
	alert_href('备份成功!','database_list.php');
}

if (isset($_POST['alloptim'])) {
$tablelist = mysql_query("SHOW TABLES");
while($checklist = mysql_fetch_array($tablelist)) {
        $optimization=mysql_query("OPTIMIZE TABLE `$checklist[0]`");
         if ($optimization) {alert_href('所有表优化成功!','database_list.php');}
}
}
if (isset($_GET['optim'])) {	
	  $tables = $_GET['optim'];
      $optimization=mysql_query("OPTIMIZE TABLE `$tables`");	  
	  if ($optimization) {alert_href('表'.$tables.'优化成功!','database_list.php');}
}
?>