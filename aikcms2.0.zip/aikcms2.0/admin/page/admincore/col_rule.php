<?php
if (isset($_GET['caijiid'])||isset($_GET['caijiimg'])) {
	include '../caiji/'.$_GET['cjgz'];
}
if (isset($_POST['execute'])) {
	null_back($_POST['id'], '请至少选中一项！');
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	$sql = 'delete from aikcms_colrule where id in (' . $id . ')';
	mysql_query($sql);
	alert_href('删除成功!', 'col_rule.php');
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_colrule where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_href('删除成功!', 'col_rule.php');
	} else {
		alert_back('删除失败！');
	}
}