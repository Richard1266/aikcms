<?php
if (isset($_POST['update'])) {
	$_data['aik_user_open'] = $_POST['aik_user_open'];
	$_data['aik_user_intra'] = $_POST['aik_user_intra'];
	$_data['aik_user_initint'] = $_POST['aik_user_initint'];
	$_data['aik_user_affint'] = $_POST['aik_user_affint'];
	$_data['aik_buycard'] = $_POST['aik_buycard'];
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('参数修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
?>