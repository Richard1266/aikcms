<?php
if (isset($_GET['name'])) {
require_once("databack.php");
}
if (isset($_GET['del'])) {
    $file ='../../../common/databack/'.$_GET['del'];
	if (!unlink($file)){
		alert_href('删除失败!', 'databack_list.php');
	}else{
		alert_href('删除成功!', 'databack_list.php');
	}
}

