<?php
if (isset($_POST['save'])) {
    $t=time();
	$_data['aik_colgroup_name'] = $_POST['aik_colgroup_name'];
	$_data['aik_colgroup_fburl'] = $_POST['aik_colgroup_fburl'];
	$_data['aik_colgroup_cjurl'] = $_POST['aik_colgroup_cjurl'];
	if(move_uploaded_file($_FILES['aik_colgroup_fburl']['tmp_name'],'../caiji/'.$t.$_FILES['aik_colgroup_fburl']['name'])){  
	$_data['aik_colgroup_fburl']=$t.$_FILES['aik_colgroup_fburl']['name'];}	
	if(move_uploaded_file($_FILES['aik_colgroup_cjurl']['tmp_name'],'../caiji/'.$t.$_FILES['aik_colgroup_cjurl']['name'])){  
	$_data['aik_colgroup_cjurl']=$t.$_FILES['aik_colgroup_cjurl']['name'];}	
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_colgroup (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_href('采集规则发布成功!', 'caiji_rule.php');
	} else {
	alert_back('发布失败!');
	}			
}

if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_colgroup where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_href('删除成功!', 'caiji_rule.php');
	} else {
		alert_back('删除失败！');
	}
}