<?php
if (isset($_POST['save'])) {
	if(move_uploaded_file($_FILES['aik_wxsk']['tmp_name'],'../../../upload/'.$_FILES['aik_wxsk']['name'])){  
	$_data['aik_wxsk']='upload/'.$_FILES['aik_wxsk']['name'];}	
	if(move_uploaded_file($_FILES['aik_zfbsk']['tmp_name'],'../../../upload/'.$_FILES['aik_zfbsk']['name'])){  
	$_data['aik_zfbsk']='upload/'.$_FILES['aik_zfbsk']['name'];}	
	if(move_uploaded_file($_FILES['aik_wxgzh']['tmp_name'],'../../../upload/'.$_FILES['aik_wxgzh']['name'])){  
	$_data['aik_wxgzh']='upload/'.$_FILES['aik_wxgzh']['name'];}		
	if(move_uploaded_file($_FILES['aik_qqjq']['tmp_name'],'../../../upload/'.$_FILES['aik_qqjq']['name'])){  
	$_data['aik_qqjq']='upload/'.$_FILES['aik_qqjq']['name'];}	
	if(move_uploaded_file($_FILES['aik_appxz']['tmp_name'],'../../../upload/'.$_FILES['aik_appxz']['name'])){  
	$_data['aik_appxz']='upload/'.$_FILES['aik_appxz']['name'];}	
			
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_href('二维码修改成功!', 'qrcode.php');
	} else {
		alert_back('修改失败!');
	}
}
?>