<?php
if (isset($_POST['update'])) {
	$_data['aik_biglogo'] = $_POST['aik_biglogo'];	
	$_data['aik_onelogo'] = $_POST['aik_onelogo'];	
	$_data['aik_twologo'] = $_POST['aik_twologo'];	
	if(move_uploaded_file($_FILES['aik_biglogo']['tmp_name'],'../../../upload/'.$_FILES['aik_biglogo']['name'])){  
	$_data['aik_biglogo']='/upload/'.$_FILES['aik_biglogo']['name'];}	
	if(move_uploaded_file($_FILES['aik_onelogo']['tmp_name'],'../../../upload/'.$_FILES['aik_onelogo']['name'])){  
	$_data['aik_onelogo']='/upload/'.$_FILES['aik_onelogo']['name'];}	
	if(move_uploaded_file($_FILES['aik_twologo']['tmp_name'],'../../../upload/'.$_FILES['aik_twologo']['name'])){  
	$_data['aik_twologo']='/upload/'.$_FILES['aik_twologo']['name'];}	
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('导航LOGO修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_nav where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}