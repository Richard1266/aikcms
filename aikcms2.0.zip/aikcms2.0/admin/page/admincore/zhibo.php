<?php
if (isset($_POST['update'])) {
	$_data['aik_zhibo'] = $_POST['aik_zhibo'];	
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('直播来源修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
if (isset($_POST['execute'])) {
	null_back($_POST['id'], '请至少选中一项！');
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	$sql = 'delete from aikcms_zhibo where id in (' . $id . ')';
	mysql_query($sql);
	alert_href('删除成功!', 'zhibo.php');
}
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_zhibo where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}