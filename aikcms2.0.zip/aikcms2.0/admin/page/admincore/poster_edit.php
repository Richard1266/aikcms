<?php
if (isset($_POST['update'])) {
	$_data['aik_hd_name'] = $_POST['aik_hd_name'];
	$_data['aik_hd_img'] = $_POST['aik_hd_img'];
	$_data['aik_hd_link'] = $_POST['aik_hd_link'];
	if(move_uploaded_file($_FILES['aik_hd_img']['tmp_name'],'../../../upload/'.$_FILES['aik_hd_img']['name'])){  
	$_data['aik_hd_img']='/upload/'.$_FILES['aik_hd_img']['name'];}	
	null_back($_data['aik_hd_link'], '请输入或上传图片');
	$sql = 'update aikcms_poster  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
		alert_href('幻灯片修改成功!', 'poster.php');	
	} else {
		alert_back('修改失败!');
	}
}

