<?php
if (isset($_POST['update'])) {
	$_data['aik_videogroup_name'] = $_POST['aik_videogroup_name'];
	$hobby_arr = array();
    $hobby_arr = $_POST['usergroup'];
    $_data['aik_videogroup_usergroup'] = implode(',', $hobby_arr);//把数组转换为字符串
	$sql = 'update aikcms_videogroup  set ' . arrtoupdate($_data) . ' where id = ' . $_GET['id'] . '';
	if (mysql_query($sql)) {
		alert_href('视频分类修改成功!', 'videogroup.php');	
	} else {
		alert_back('修改失败!');
	}
	
}
