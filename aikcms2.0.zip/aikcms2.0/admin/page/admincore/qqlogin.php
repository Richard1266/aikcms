<?php
if (isset($_POST['update'])) {
	$_data['aik_qqlogin'] = $_POST['aik_qqlogin'];
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('QQ互联开启状态修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
if (isset($_POST['save'])) {
	$_data['aik_qqappid'] = $_POST['aik_qqappid'];
	$_data['aik_qqappkey'] = $_POST['aik_qqappkey'];
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('QQ互联参数修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
?>