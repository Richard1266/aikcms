<?php
if (isset($_POST['save'])) {
	null_back($_POST['aik_user_name'], '请填写用户名');
	null_back($_POST['aik_user_pw'], '请填写密码');
	$result = mysql_query('select * from aikcms_user where aik_user_name = "' . $_POST['aik_user_name'] . '"');
	if (mysql_fetch_array($result)) {
		alert_back('帐号重复，请输入新的帐号。');
	}
	$_data['aik_user_name'] = $_POST['aik_user_name'];
	$_data['aik_user_pw'] =  md5($_POST['aik_user_pw']);
	$_data['aik_user_qq'] = $_POST['aik_user_qq'];
	$_data['aik_user_group'] = $_POST['aik_user_group'];
	$_data['aik_user_groupend'] = $_POST['aik_user_groupend']=="0" ? "0" : strtotime($_POST['aik_user_groupend']);
	$_data['aik_user_allmoney'] = $_POST['aik_user_allmoney'];
	$_data['aik_user_int'] = $_POST['aik_user_int'];
	$_data['aik_user_time'] = time();
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_user (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_parent('用户添加成功!');
	} else {
		alert_back('添加失败!');
	}
}

?>