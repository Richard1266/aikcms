<?php

if (isset($_POST['save'])) {
	
	$aik_card_long = $_POST['aik_card_long'];
	$aik_card_group = $_POST['aik_card_group'];
	$aik_card_num = $_POST['aik_card_num'];	

	function getkm($len)
{
$str = "ABCDEFGKLM1234567NOPVWXrstuYHIJZbcdefghijklmQRSTUnopqrstuvwxyz089";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}//开始添加
for ($i = 0; $i < $aik_card_num; $i++) { //添加数量
       $km=getkm($aik_card_long);

	$SQL = "INSERT INTO `aikcms_card` (`id`, `aik_card`, `aik_card_group`) VALUES (NULL, '$km', $aik_card_group)";//生成卡密
	
	mysql_query($SQL);
}
	alert_parent('生成卡密成功，一共生成 ' . $aik_card_num. ' 张卡密！');
	mysql_close();
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
