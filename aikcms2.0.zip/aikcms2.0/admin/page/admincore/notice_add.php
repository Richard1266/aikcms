<?php
if (isset($_POST['save'])) {
	$_data['aik_notice_title'] = $_POST['aik_notice_title'];
	$_data['aik_notice_time'] = time();
	$_data['aik_notice_url'] = $_POST['aik_notice_url'];
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_notice (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	    alert_parent('公告发布成功!');
	} else {
		alert_back('发布失败!');
	}
}

