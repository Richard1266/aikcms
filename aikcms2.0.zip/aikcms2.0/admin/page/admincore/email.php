<?php
if (isset($_POST['update'])) {
	$_data['aik_email_server'] = $_POST['aik_email_server'];
	$_data['aik_email_port'] = $_POST['aik_email_port'];
	$_data['aik_email_add'] = $_POST['aik_email_add'];
	$_data['aik_email_user'] = $_POST['aik_email_user'];
	$_data['aik_email_pw'] = $_POST['aik_email_pw'];
	$_data['aik_email_inbox'] = $_POST['aik_email_inbox'];
	$sql = 'update aikcms_basic set ' . arrtoupdate($_data) . ' where id = 1';
	if (mysql_query($sql)) {
		alert_back('邮箱配置参数修改成功!');
	} else {
		alert_back('修改失败!');
	}
}
?>