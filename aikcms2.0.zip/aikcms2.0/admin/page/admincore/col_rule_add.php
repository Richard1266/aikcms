<?php

if (isset($_POST['save'])) {
	$_data['aik_col_name'] = $_POST['aik_col_name'];
	$_data['aik_col_url'] = $_POST['aik_col_url'];
	$_data['aik_col_urlstart'] = $_POST['aik_col_urlstart'];
	$_data['aik_col_urlend'] = $_POST['aik_col_urlend'];
	$_data['aik_col_videogroup'] = $_POST['aik_col_videogroup'];
	$hobby_arr = array();
    $hobby_arr = $_POST['usergroup'];
    $_data['aik_col_usergroup'] = implode(',', $hobby_arr);//把数组转换为字符串
	$_data['aik_col_rule'] = $_POST['aik_col_rule'];
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_colrule (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_parent('采集规则添加成功!');
	} else {
		alert_back('添加失败!');
	}
}

