<?php
if (isset($_POST['save'])) {
	$_data['aik_ad_seat'] = $_POST['aik_ad_seat'];
	$_data['aik_ad_remarks'] = $_POST['aik_ad_remarks'];
	$_data['aik_ad_code'] = htmlspecialchars($_POST['aik_ad_code']);
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_ad (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_parent('广告发布成功!');
	} else {
		alert_back('发布失败!');
	}
}

