<?php
if (isset($_POST['save'])) {
	$_data['aik_colgroup_name'] = $_POST['aik_colgroup_name'];
	$_data['aik_colgroup_fburl'] = $_POST['aik_colgroup_fburl'];
	$_data['aik_colgroup_cjurl'] = $_POST['aik_colgroup_cjurl'];
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_colgroup (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
	alert_back('正则表达式添加成功!');
	} else {
		alert_back('添加失败!');
	}
}

if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_colgroup where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}