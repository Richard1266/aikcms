<?php
include('../../../common/basic.php');
include('../admincore/qrcode.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>二维码设置</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="//at.alicdn.com/t/font_tnyc012u2rlwstt9.css" media="all" />
	<link rel="stylesheet" href="../../css/main.css" media="all" />
</head>
<body class="childrenBody">


<section class="layui-larry-box">
	<div class="larry-personal">
		<?php
$result = mysql_query('select * from aikcms_basic where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>
		<div class="larry-personal-body">
		

			<form class="layui-form" method="post" enctype="multipart/form-data" >
			<div class="layui-form-item">	
				<label class="layui-form-label">微信收款码</label>
				<div class="layui-inline">
		    <div class="layui-input-inline">
		    	<input  name="aik_wxsk" placeholder="这里可以输入网络图片" class="layui-input" value="<?php echo $row['aik_wxsk']?>">
              </div>  
<input type="file" name="aik_wxsk"  style="height:38px;"  />
		</div>   

		</div><div class="layui-form-item">	
				<label class="layui-form-label">支付宝收款</label>
				<div class="layui-inline">
		    <div class="layui-input-inline">
		    	<input  name="aik_zfbsk" placeholder="这里可以输入网络图片" class="layui-input"  value="<?php echo $row['aik_zfbsk']?>">
		    </div>
<input type="file" name="aik_zfbsk"  style="height:38px;"  />
		</div>
				
		</div><div class="layui-form-item">	
				<label class="layui-form-label">微信公众号</label>
				<div class="layui-inline">
		    <div class="layui-input-inline">
		    	<input  name="aik_wxgzh" placeholder="这里可以输入网络图片" class="layui-input"  value="<?php echo $row['aik_wxgzh']?>">
		    </div>
<input type="file" name="aik_wxgzh"  style="height:38px;"  />
		</div>
				
		</div><div class="layui-form-item">	
				<label class="layui-form-label">QQ加群码</label>
				<div class="layui-inline">
		    <div class="layui-input-inline">
		    	<input  name="aik_qqjq" placeholder="这里可以输入网络图片" class="layui-input"  value="<?php echo $row['aik_qqjq']?>">
		    </div>
<input type="file" name="aik_qqjq"  style="height:38px;"  />
		</div>
				
		</div><div class="layui-form-item">	
				<label class="layui-form-label">APP下载码</label>
				<div class="layui-inline">
		    <div class="layui-input-inline">
		    	<input  name="aik_appxz" placeholder="这里可以输入网络图片" class="layui-input" value="<?php echo $row['aik_appxz']?>">
		    </div>
<input type="file" name="aik_appxz"  style="height:38px;"  />
		</div>
				
		</div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" name="save" >立即提交</button>
		    </div>
		</div></br>
			</form>
					</div><?php }?>
					<blockquote class="layui-elem-quote"><p style="color:red; margin:0 auto;line-height:38px;">1.上传图片不支持中文名称，如上传失败请检查！</p></blockquote><br>
	</div>
</section>
<script type="text/javascript" src="../../layui/layui.js"></script>
</body>
</html>