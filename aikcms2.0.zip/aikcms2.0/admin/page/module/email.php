<?php
include('../../../common/basic.php');
include('../../../inc/email.class.php');
include('../admincore/email.php');
	$titleType = "text/html; charset=utf-8";    
	$contentType = "text/html; charset=utf-8";    
    $title = "测试成功";
    $content = "恭喜，邮箱设置成功！";
if (isset($_POST['ceshi'])) {
	$smtpserver = $_POST['aik_email_server']; //SMTP服务器
    $smtpserverport = $_POST['aik_email_port']; //SMTP服务器端口
    $email = $_POST['aik_email_ceshi'];
    $smtpusermail = $_POST['aik_email_add']; //SMTP服务器的用户邮箱
    $smtpuser = $_POST['aik_email_user']; //SMTP服务器的用户帐号
    $smtppass = $_POST['aik_email_pw']; //SMTP服务器的授权密码
    $smtp = new Smtp($smtpserver, $smtpserverport, true, $smtpuser, $smtppass); //这里面的一个true是表示使用身份验证,否则不使用身份验证.
    $emailtype = "HTML"; //信件类型，文本:text；网页：HTML
    $smtpemailto = $email;
    $smtpemailfrom = $smtpusermail;
    $emailsubject = $title;
    $emailbody = $content;
    //开始发送邮件
    $state = $smtp->sendmail($smtpemailto, $smtpemailfrom, $emailsubject, $emailbody, $emailtype);
if($state=="") {
echo "<script>alert('发送失败');location.href='email.php'</script>";
}else {
echo "<script>alert('发送成功');location.href='email.php'</script>";
}
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>邮箱配置</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="../../css/main.css" media="all" />
	<link rel="stylesheet" href="../../css/user.css" media="all" />
</head>
<body class="childrenBody">


<section class="layui-larry-box">
	<div class="larry-personal">
		<?php
$result = mysql_query('select * from aikcms_basic where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>
		<div class="larry-personal-body clearfix changepwd">
		
			<form class="layui-form" method="post"  enctype="multipart/form-data" >	
			<div class="user_left">	
			<div class="layui-form-item">	
				<label class="layui-form-label">SMTP服务器</label>
				<div class="layui-input-block">  
						<input type="text" name="aik_email_server"  autocomplete="off"  class="layui-input"   value="<?php echo $row['aik_email_server']?>">
					</div> 
		</div>
		<div class="layui-form-item">	
				<label class="layui-form-label">SMTP端口</label>
		    <div class="layui-input-inline">
		    	<input type="text" name="aik_email_port"  placeholder="这里可以输入网络图片" class="layui-input"  value="<?php echo $row['aik_email_port']?>">
              </div>  
		</div><div class="layui-form-item">	
				<label class="layui-form-label">发件人地址</label>
				<div class="layui-input-inline">  
						<input type="text" name="aik_email_add" placeholder="请输入发件人地址"   autocomplete="off"  class="layui-input" value="<?php echo $row['aik_email_add']?>">
					</div> <div class="layui-form-mid layui-word-aux">推荐使用163邮箱作为发件箱</div>
		</div><div class="layui-form-item">	
				<label class="layui-form-label">用户名</label>
				<div class="layui-input-inline">  
						<input type="text" name="aik_email_user" placeholder="请输入发件邮箱用户名"   autocomplete="off"  class="layui-input" value="<?php echo $row['aik_email_user']?>">
					</div> <div class="layui-form-mid layui-word-aux">你的邮箱，如admin@163.com</div>
		</div>
		<div class="layui-form-item">	
				<label class="layui-form-label">密码</label>
				<div class="layui-input-inline">  
						<input type="password" name="aik_email_pw" placeholder="请输入发件邮箱密码"  autocomplete="off"  class="layui-input" value="<?php echo $row['aik_email_pw']?>">
					</div> <div class="layui-form-mid layui-word-aux">你的邮箱登陆密码</div>
		</div><div class="layui-form-item">	
				<label class="layui-form-label">站点默认邮箱</label>
				<div class="layui-input-block">  
						<input type="text" name="aik_email_inbox"  placeholder="请输入接收邮件邮箱" autocomplete="off"  class="layui-input" value="<?php echo $row['aik_email_inbox']?>">
					</div> 
		</div><div class="layui-form-item">	
				<label class="layui-form-label">邮件设置测试</label>
			<div class="layui-input-block">  
						<input type="text" name="aik_email_ceshi"  autocomplete="off"  class="layui-input" value="">
					</div> 
		</div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" name="update" >立即提交</button>
				<button class="layui-btn layui-btn-danger" name="ceshi" >测试</button>
		    </div>
		</div></br></div>
			</form>
					</div><?php }?>
	</div>
</section>
<script type="text/javascript" src="../../layui/layui.js"></script>
</body>
</html>