<?php
include('../../../common/basic.php');
include('../admincore/wx.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>微信对接</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="../../css/main.css" media="all" />
	<link rel="stylesheet" href="../../css/user.css" media="all" />
</head>
<body class="childrenBody">


<section class="layui-larry-box">
	<div class="larry-personal">
		<?php
$result = mysql_query('select * from aikcms_basic where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>
		<div class="larry-personal-body clearfix changepwd">
		
			<form class="layui-form" method="post">	
			<div class="user_left">	
			<div class="layui-form-item">	
				<label class="layui-form-label">URL</label>
				<div class="layui-input-block">  
						<input type="text" name="aik_wx_url"  autocomplete="off"  class="layui-input layui-disabled"  disabled="disabled"  value="<?php echo 'http://'.$_SERVER['SERVER_NAME'];?>/wx_api.php">
					</div> 
		</div>
		<div class="layui-form-item">	
				<label class="layui-form-label">Token</label>
<div class="layui-input-block">  
						<input type="text" name="aik_wx_token"  autocomplete="off"  class="layui-input" value="<?php echo $row['aik_wx_token']?>">
					</div> 	
		</div><div class="layui-form-item">	
				<label class="layui-form-label">回复封面</label>
				<div class="layui-input-block">  
						<input type="text" name="aik_wx_img" placeholder="请输入网络图片" class="layui-input" value="<?php echo $row['aik_wx_img']?>">
					</div> 
		</div><div class="layui-form-item">	
				<label class="layui-form-label">关注回复</label>
				<div class="layui-input-block">  
				<textarea name="aik_wx_reply" placeholder="请输入关注后自动回复的消息" class="layui-textarea"><?php echo $row['aik_wx_reply']?></textarea>
					</div> 
		</div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" name="save" >立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		    </div>
		</div></br></div>
			</form>
					</div><?php }?>
	</div>
</section>
<script type="text/javascript" src="../../layui/layui.js"></script>
</body>
</html>