<?php
include('../../../common/basic.php');
include('../admincore/qqlogin.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>QQ互联登录</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="../../css/main.css" media="all" />
	<link rel="stylesheet" href="../../css/user.css" media="all" />
</head>
<body class="childrenBody">

<?php
$result = mysql_query('select * from aikcms_basic where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>		
        <blockquote class="layui-elem-quote news_search">
	<form method="post"><div class="layui-form" >
				  <div class="layui-form-item" style="margin-bottom: 0;">
				    <label class="layui-form-label">QQ互联登录</label>
					
				    <div class="layui-input-block">
				      <input type="radio" name="aik_qqlogin" value="1" title="开启" <?php if( $row['aik_qqlogin'] == 1 ){ echo 'checked' ;}?> >
				      <input type="radio" name="aik_qqlogin" value="0" title="关闭" <?php if( $row['aik_qqlogin'] == 0 ){ echo 'checked' ;}?>>
				   
				      <button class="layui-btn" name="update">立即提交</button>
				    </div>
				  </div>
				  </div></form>
		
	</blockquote> 
					<?php }?>
<section class="layui-larry-box">
	<div class="larry-personal">
		<?php
$result = mysql_query('select * from aikcms_basic where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>
		<div class="larry-personal-body clearfix changepwd">
		
			<form class="layui-form" method="post"  enctype="multipart/form-data" >	
			<div class="user_left">	
		<div class="layui-form-item">	
				<label class="layui-form-label">App ID</label>
<div class="layui-input-block">  
						<input type="text" name="aik_qqappid" placeholder="请输入App ID"   class="layui-input" value="<?php echo $row['aik_qqappid']?>">
					</div> 	
		</div><div class="layui-form-item">	
				<label class="layui-form-label">App Key</label>
				<div class="layui-input-block">  
						<input type="text" name="aik_qqappkey"  placeholder="请输入App Key"  class="layui-input" value="<?php echo $row['aik_qqappkey']?>">
					</div> 
		</div>
					<div class="layui-form-item">	
				<label class="layui-form-label">回调链接</label>
				<div class="layui-input-block">  
						<input type="text"  autocomplete="off"  class="layui-input layui-disabled"  disabled="disabled"  value="<?php echo 'http://'.$_SERVER['SERVER_NAME'];?>/user.php?mode=qqlogin">
					</div> 
		</div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" name="save" >立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		    </div>
		</div></br></div>
			</form>
					</div><?php }?>
	</div>
</section>
<script type="text/javascript" src="../../layui/layui.js"></script>
</body>
</html>