<?php
include('../../../common/basic.php');
include('../admincore/pay.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>支付配置</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="../../css/main.css" media="all" />
	<link rel="stylesheet" href="../../css/user.css" media="all" />
</head>
<body class="childrenBody">
<section class="layui-larry-box">
	<div class="larry-personal">
		<?php
$result = mysql_query('select * from aikcms_basic where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>
		<div class="larry-personal-body clearfix changepwd">
		
			<form class="layui-form" method="post"  enctype="multipart/form-data" >	
			<div class="user_left">	
			<div class="layui-form-item">	
				<label class="layui-form-label">是否开启</label>
					
				    <div class="layui-input-block">
				      <input type="radio" name="aik_pay_open" value="1" title="开启" <?php echo ($row['aik_pay_open']=='1' ? 'checked':'');?>>
				      <input type="radio" name="aik_pay_open" value="0" title="关闭" <?php echo ($row['aik_pay_open']=='0' ? 'checked':'');?>>
				    </div>
		</div><div class="layui-form-item">	
				<label class="layui-form-label">支付接入商</label>
				<div class="layui-input-inline">
					<select name="aik_pay_name" class="newsLook" lay-filter="browseLook">
						<option value="1">蓝讯数卡</option>
				    </select>
				</div><div class="layui-form-mid layui-word-aux">网址：http://www.lcardy.com/,仅推荐自己使用的！</div>
		</div>
		<div class="layui-form-item">	
				<label class="layui-form-label">商户ID</label>
		    <div class="layui-input-inline">
		    	<input type="text" name="aik_pay_id"  placeholder="请输入商户ID" class="layui-input"  value="<?php echo $row['aik_pay_id']?>">
              </div>  
		</div><div class="layui-form-item">	
				<label class="layui-form-label">商户密钥</label>
				<div class="layui-input-block">  
						<input type="text" name="aik_pay_key" placeholder="请输入商户密钥"  class="layui-input" value="<?php echo $row['aik_pay_key']?>">
					</div> 
		</div><div class="layui-form-item">	
				<label class="layui-form-label">接口网址</label>
				<div class="layui-input-block">  
						<input type="text" name="aik_pay_url" placeholder="请输入接口网址"  class="layui-input" value="<?php echo $row['aik_pay_url']?>">
					</div> 
		</div>

		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" name="update" >立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		    </div>
		</div></br></div>
			</form>
					</div><?php }?>
	</div>
</section>
<script type="text/javascript" src="../../layui/layui.js"></script>
</body>
</html>