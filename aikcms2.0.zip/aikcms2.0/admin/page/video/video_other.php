<?php
include('../../../common/basic.php');
include('../admincore/video_other.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>其他设置</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="//at.alicdn.com/t/font_tnyc012u2rlwstt9.css" media="all" />
	<link rel="stylesheet" href="../../css/main.css" media="all" />
</head>
<body class="childrenBody layui-form">
<blockquote class="layui-elem-quote title">视频播放</blockquote><br>
<?php
$result = mysql_query('select * from aikcms_basic where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>
<form method="post" class="layui-form">
<div class="layui-form-item">
				<label class="layui-form-label">登录后播放</label>
				<div class="layui-input-block">
				    <input type="radio" name="aik_login_play" value="1" title="开启" <?php echo $row['aik_login_play'] == 1 ? 'checked' : '';?>>
				    <input type="radio" name="aik_login_play" value="0" title="关闭" <?php echo $row['aik_login_play'] == 0 ? 'checked' : '';?>>
				</div>
			</div>
<blockquote class="layui-elem-quote title">尝鲜设置</blockquote><br>
<div class="layui-form-item">
          <div class="layui-inline">	
		  <label class="layui-form-label">尝鲜来源</label>
				<div class="layui-input-block">  
						<select name="aik_fresh_on" class="newsLook" lay-filter="browseLook">
						<option value="1" <?php echo $row['aik_fresh_on'] == 1 ? 'selected="selected"' : '';?>>手动更新</option>
						<option value="2" <?php echo $row['aik_fresh_on'] == 2 ? 'selected="selected"' : '';?>>自动更新</option>
						<option value="0" <?php echo $row['aik_fresh_on'] == 0 ? 'selected="selected"' : '';?>>关闭尝鲜</option>
				    </select>
					</div> 
			</div>
			<div class="layui-inline"  style="width:40%;">		
				<label class="layui-form-label">链接</label>
				<div class="layui-input-inline" style="width:40%;">
					<input class="layui-input newsAuthor" name="aik_fresh_url" placeholder="填写对应网址！如关闭请留空！" type="text" value="<?php echo $row['aik_fresh_url']?>">
				</div>
			</div>
		</div>
<blockquote class="layui-elem-quote title">播放页</blockquote><br>
<div class="layui-form-item">
				<label class="layui-form-label">最近更新</label>
				<div class="layui-input-block">
				    <input type="radio" name="aik_rec_on" value="1" title="开启" <?php echo $row['aik_rec_on'] == 1 ? 'checked' : '';?>>
				    <input type="radio" name="aik_rec_on" value="0" title="关闭" <?php echo $row['aik_rec_on'] == 0 ? 'checked' : '';?>>
				</div>
			</div>		
<blockquote class="layui-elem-quote title">侵权设置</blockquote><br>
		<div class="layui-form-item layui-form-text">
				    <label class="layui-form-label">侵权屏蔽</label>
				    <div class="layui-input-block">
				      <textarea name="aik_tort" placeholder="请输入侵权的视频标题" class="layui-textarea"><?php echo $row['aik_tort']?></textarea>
				    <p style="color:red; float:left;line-height:38px;">标题#标题#标题</p>
				  </div></div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" name="save">点击提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		    </div>
		</div><br>

					</form><?php }?>
<script type="text/javascript" src="../../layui/layui.js"></script>
<script type="text/javascript" src="../../js/newslist.js"></script>
</body>
</html>