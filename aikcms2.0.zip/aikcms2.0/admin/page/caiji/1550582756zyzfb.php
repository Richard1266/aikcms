<?php
if (isset($_POST['get'])) {
	$cjgz=$_POST['aik_col_rule'];
    $aik_zylink = $_POST['aik_zylink'];
	$info=file_get_contents($aik_zylink);
	$zylink='#<li><input type="checkbox" name="copy_sel" value="(.*)" checked="" />(.*)</li>#';//播放
    $zyname='#<img class="lazy" src="(.*)" alt="(.*)" />#';  //名+图 
    $zybeizhu='#<span>(.*)</span>#';  //名+图 
preg_match_all($zylink,$info,$arrzyl);
preg_match_all($zyname,$info,$arrzy);
preg_match_all($zybeizhu,$info,$arrbz);
    $vurl=$arrzyl[2];//取出播放链接
    $vname=$arrzy[2][0];//取出名
    $vimg=$arrzy[1][0];//取出图片
    $remarks=$arrbz[1][1];//取出图片
	
    $vlink=count($vurl)-1; 
	
 foreach ($vurl as $key=>$bflink){ 
$linkone = preg_replace('<<a href="(.*)">>',"",$bflink);
$linktwo=str_replace('</a>',"",$linkone);
$alllink.=str_replace("","",$linktwo);//
if ($vlink!=$key) {
	$alllink.="\r\n";
}
}
}

if ((isset($_GET['updateimg']))||(isset($_POST['update']))) {
	if(isset($_GET['updateimg'])){$id=$_GET['updateimg'];}else{$id=$a;}
	$sql="SELECT * FROM `aikcms_video` where id=" . $id . " limit 1";
    $row=mysql_fetch_array(mysql_query($sql));
    $info=file_get_contents($row['aik_video_zylink']);
    $zylink='#<li><input type="checkbox" name="copy_sel" value="(.*)" checked="" />(.*)</li>#';//播放
    $szzimg='#<img class="lazy" src="(.*?)" alt="(.*?)" />#';
	$zybeizhu='#<span>(.*)</span>#';
    preg_match_all($zylink,$info,$arrzyl);
    preg_match_all($zybeizhu,$info,$arrbz);
    preg_match_all($szzimg, $info,$sarrimg);
			$vurl=$arrzyl[2];//取出播放链接
        $remarks=$arrbz[1][1];//取出图片
	    $zimg= $sarrimg[1][0]; 
		$vlink=count($vurl)-1; 
	    foreach ($vurl as $key=>$bflink){ 
        $linkone = preg_replace('<<a href="(.*)">>',"",$bflink);
        $linktwo=str_replace('</a>',"",$linkone);
        $alllink.=str_replace("","",$linktwo);//
        if ($vlink!=$key) {
	    $alllink.="\r\n";
		}
		};
	mysql_query("UPDATE `aikcms_video` SET `aik_video_img` = '$zimg'  ,`aik_video_url` = '$alllink',`aik_video_remarks` = '$remarks' WHERE `aikcms_video`.id=" . $id . "  LIMIT 1 ;");
	if(isset($_GET['updateimg'])){
	alert_href('视频更新完成！', 'video_list.php');}
}
?>