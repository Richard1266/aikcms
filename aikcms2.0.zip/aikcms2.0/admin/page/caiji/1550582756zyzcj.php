<?php
   $cid=$_GET['cid'];
   $cjgz=$_GET['cjgz'];
if (isset($_GET['caijiid'])) {
   $sql="SELECT * FROM `aikcms_colrule` WHERE  `id` ='{$_GET['caijiid']}'";
   $row=mysql_fetch_array(mysql_query($sql));
   $id = $row['id'];
   $cjfenlei = $row['aik_col_videogroup'];
   $cjlink = $row['aik_col_url'];
   $cjstart = $row['aik_col_urlstart'];
   $cjend = $row['aik_col_urlend'];
   $cjjibie = $row['aik_col_usergroup'];
   $url=substr($cjlink, 0, -5) ;//去掉链接中的。htmnl
   $arr = parse_url($cjlink);  
   $link = $arr['scheme'].'://'.$arr['host'];
   if($cid<=$cjend){	 
     $info=file_get_contents($url.'-pg-'.$cid.'.html');//获取页面内容
	 // print_r($info);
    $pattern='#<li><span class="tt"></span><span class="xing_vb4"><a href="(.*?)" target="_blank">(.*?)</a></span> <span class="xing_vb5">(.*?)</span>#';//正则
    preg_match_all($pattern, $info, $arr);//匹配内容到arr数组
   // print_r($arr);die;    
    foreach ($arr[1] as $key => $value) {//二维数组[2]对应id和[1]刚好一样,利用起key
	   $name=$arr[2][$key];
       $cjurl=$link.$value;
	   $time=time();
       $result = mysql_query('select * from aikcms_video where aik_video_zylink = "'.$cjurl.'"');
	   $row=mysql_fetch_array($result);
	   if ($row){exit;}else{
	    $sql="insert into aikcms_video(	aik_video_name,aik_video_group,aik_video_zylink,aik_video_usergroup,aik_video_col,aik_video_time) value ('$name', '$cjfenlei', '$cjurl', '$cjjibie', '$cjgz', '$time')";
	   //echo $sql;
        mysql_query($sql);
		}

    } 
     echo "正在采集数据列表第".$cid."页...请稍后...";
	 $cid++;
     echo "<script>window.location='?caijiid=".$id."&cid=".$cid."&cjgz=".$cjgz."'</script>";

 }else{
     echo "<script>alert('列表采集成功，点击继续采集详情！');window.location.href='?caijiimg=1&cjgz=".$cjgz."'</script>";
 }
}
	
?>
<?php 
if (isset($_GET['caijiimg'])) {
$sqlGetLastID ="SELECT * FROM  `aikcms_video` WHERE  `aik_video_zylink` <> '' AND  `aik_video_img` =  ''  order by id desc limit 1"; 
$resultGetLastID =mysql_query($sqlGetLastID);
$rowGetLastID=mysql_fetch_array($resultGetLastID); 
if(empty($rowGetLastID))
{
$lastID = '0';
}
else
{
$lastID =$rowGetLastID['id'];
}
if($_GET['pdid']){$pdid=$_GET['pdid'];}else{$pdid=$lastID;}


$sql="SELECT * FROM  `aikcms_video` WHERE  `aik_video_zylink` <>  '' AND  `aik_video_img` =  '' OR `aik_video_url` =  ''";
$row=mysql_fetch_array(mysql_query($sql));
if($row){
        $info=file_get_contents($row['aik_video_zylink']);
		$zylink='#<li><input type="checkbox" name="copy_sel" value="(.*)" checked="" />(.*)</li>#';//播放
        $szzimg='#<img class="lazy" src="(.*?)" alt="(.*?)" />#';
		$zybeizhu='#<span>(.*)</span>#';
		preg_match_all($zylink,$info,$arrzyl);
        preg_match_all($zybeizhu,$info,$arrbz);
        preg_match_all($szzimg, $info,$sarrimg);
		$vurl=$arrzyl[2];//取出播放链接
        $remarks=$arrbz[1][1];//取出图片
	    $zimg= $sarrimg[1][0]; 
		$vlink=count($vurl)-1; 
	    foreach ($vurl as $key=>$bflink){ 
        $linkone = preg_replace('<<a href="(.*)">>',"",$bflink);
        $linktwo=str_replace('</a>',"",$linkone);
        $alllink.=str_replace("","",$linktwo);//
        if ($vlink!=$key) {
	    $alllink.="\r\n";
		}
		}
		//echo $zimg;
mysql_query("UPDATE `aikcms_video` SET `aik_video_img` = '$zimg' ,`aik_video_url` = '$alllink',`aik_video_remarks` = '$remarks' WHERE `aikcms_video`.id='$row[id]'  LIMIT 1 ;");
echo $row['aik_video_name'].'>>>>详情采集成功';
$pdid--;
echo "<script>window.location='?caijiimg=1&pdid=".$pdid."&cjgz=".$cjgz."'</script>";
	
	
}else{
	echo "<script>alert('详情采集完成！');window.location.href='video_list.php'</script>";
}
}
?>
<?php
if ((isset($_GET['updateimg']))||(isset($_POST['update']))) {
	if(isset($_GET['updateimg'])){$id=$_GET['updateimg'];}else{$id=$a;}
	$sql="SELECT * FROM `aikcms_video` where id=" . $id . " limit 1";
    $row=mysql_fetch_array(mysql_query($sql));
    $info=file_get_contents($row['aik_video_zylink']);
    $zylink='#<li><input type="checkbox" name="copy_sel" value="(.*)" checked="" />(.*)</li>#';//播放
    $szzimg='#<img class="lazy" src="(.*?)" alt="(.*?)" />#';
	$zybeizhu='#<span>(.*)</span>#';
    preg_match_all($zylink,$info,$arrzyl);
    preg_match_all($zybeizhu,$info,$arrbz);
    preg_match_all($szzimg, $info,$sarrimg);
			$vurl=$arrzyl[2];//取出播放链接
        $remarks=$arrbz[1][1];//取出图片
	    $zimg= $sarrimg[1][0]; 
		$vlink=count($vurl)-1; 
	    foreach ($vurl as $key=>$bflink){ 
        $linkone = preg_replace('<<a href="(.*)">>',"",$bflink);
        $linktwo=str_replace('</a>',"",$linkone);
        $alllink.=str_replace("","",$linktwo);//
        if ($vlink!=$key) {
	    $alllink.="\r\n";
		}
		};
	mysql_query("UPDATE `aikcms_video` SET `aik_video_img` = '$zimg'  ,`aik_video_url` = '$alllink',`aik_video_remarks` = '$remarks' WHERE `aikcms_video`.id=" . $id . "  LIMIT 1 ;");
	if(isset($_GET['updateimg'])){
	alert_href('视频更新完成！', 'video_list.php');}
}
?>




