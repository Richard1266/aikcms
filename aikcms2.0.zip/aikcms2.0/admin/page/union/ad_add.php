<?php
include('../../../common/basic.php');
include('../admincore/ad_add.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>发布公告</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="//at.alicdn.com/t/font_tnyc012u2rlwstt9.css" media="all" />
	<link rel="stylesheet" href="../../css/main.css" media="all" />
</head>
<body class="childrenBody">
	<form class="layui-form" method="post">
		<div class="layui-form-item">
			<div class="layui-inline">		
				<label class="layui-form-label">广告位置</label>
			<div class="layui-input-block">
				<input class="layui-input" name="aik_ad_seat" placeholder="请输入放置广告的位置" type="text" >
			</div>
			</div>
			<div class="layui-inline">		
				<label class="layui-form-label">广告备注</label>
				<div class="layui-input-inline">
					<input class="layui-input" name="aik_ad_remarks" placeholder="请输入备注" type="text">
				</div>
			</div>
		</div>	
		<div class="layui-form-item">
			<label class="layui-form-label">广告代码</label>
			<div class="layui-input-block">
				      <textarea name="aik_ad_code" placeholder="请输入广告代码" class="layui-textarea"></textarea>
					  <div class="layui-form-mid layui-word-aux">*图片广告代码模板：&lt;a href="链接" target="_blank"&gt;&lt;img src="图片地址" style="width:100%;height:100%;"&gt;&lt;/a&gt; </div>
			</div>
		</div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" name="save" >立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		    </div>
		</div></br>
	</form>
<script type="text/javascript" src="../../layui/layui.js"></script>

</body>
</html>