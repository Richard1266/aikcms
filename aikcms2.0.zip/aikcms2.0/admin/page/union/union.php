<?php
include('../../../common/basic.php');
include('../admincore/union.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>用户管理</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="//at.alicdn.com/t/font_tnyc012u2rlwstt9.css" media="all" />
	<link rel="stylesheet" href="../../css/main.css" media="all" />
	<link rel="stylesheet" href="../../css/user.css" media="all" />
</head>
<body class="childrenBody">
   		<?php
$result = mysql_query('select * from aikcms_basic where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>
		<div class="larry-personal-body clearfix changepwd">
		
			<form class="layui-form" method="post" >	
			<div class="user_left">	
			<div class="layui-form-item">	
				<label class="layui-form-label">前台调用</label>
				<div class="layui-input-block selectMsg">  
				<select name="aik_union_open" >
					<option value="1">仅显示大淘客</option>
					<option value="2">仅显示京推推</option>
					<option value="3">随机显示</option>
					<option value="0">关闭</option>
			    </select>
				</div> 
		    </div>
			<div class="layui-form-item">
			<div class="layui-inline">		
				<label class="layui-form-label">大淘客网址</label>
				<div class="layui-input-inline">
					<input class="layui-input" name="aik_union_dtk" placeholder="请输入大淘客网址" type="text" value="<?php echo $row['aik_union_dtk']?>">
				</div>
			</div>
			<div class="layui-inline">		
				<label class="layui-form-label">大淘客ID</label>
				<div class="layui-input-inline">
					<input class="layui-input" name="aik_union_dtkid" placeholder="请输入大淘客ID" type="text" value="<?php echo $row['aik_union_dtkid']?>">
				</div>
			</div>
		    </div>
			<div class="layui-form-item">	
				<label class="layui-form-label">京推推网址</label>
				<div class="layui-input-block">  
						<input type="text" name="aik_union_jtt" placeholder="请输入京推推网址"  class="layui-input"   value="<?php echo $row['aik_union_jtt']?>">
					</div> 
		    </div>
		    <div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" name="update" >立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		    </div>
		</div></br></div>
			</form>
					</div><?php }?>
	</div></div>
</section>
		
	
<script type="text/javascript" src="../../layui/layui.js"></script>
<script type="text/javascript" src="../../js/newslist.js"></script>
</body>
</html>