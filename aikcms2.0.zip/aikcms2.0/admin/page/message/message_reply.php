<?php
include('../../../common/basic.php');
include('../admincore/message_reply.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>消息回复--layui后台管理模板</title>
	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="format-detection" content="telephone=no">
	<link rel="stylesheet" href="../../layui/css/layui.css" media="all" />
	<link rel="stylesheet" href="//at.alicdn.com/t/font_tnyc012u2rlwstt9.css" media="all" />
	<link rel="stylesheet" href="../../css/message.css" media="all" />
</head>
<body class="childrenBody">
<form method="post">
			<div class="replay_edit">
			<textarea class="layui-textarea layui-hide" name="aik_gbook_content" id="msgReply"></textarea><div class="layui-layedit"><div class="layui-unselect layui-layedit-tool"><i class="layui-icon layedit-tool-face" title="表情" layedit-event="face" "=""></i></div><div class="layui-layedit-iframe"><iframe id="LAY_layedit_1" name="LAY_layedit_1" textarea="msgReply" frameborder="0" style="height: 100px;"></iframe></div></div>
			<input type="hidden" name="aik_gbook_reply" value="<?php echo $_GET['id'];?>">
		</div>
			 <button class="layui-btn"   name="save"> 点击回复 </button>
	</form>
		<table class="layui-table msg_box" lay-skin="line">
			<colgroup>
				<col width="50%">
				<col width="30%">
				<col>
			</colgroup>
			<tbody class="msgReplyHtml">
			<?php
					$result = mysql_query('select * from aikcms_gbook where id = '.$_GET['id'].' ');	
					if ($row = mysql_fetch_array($result)){
					?>
			<tr>  <td class="msg_info">    <img src="<?php echo get_user_img($row['aik_gbook_userid'])?>" width="50" height="50">    <div class="user_info">        <h2><?php echo get_user_name($row['aik_gbook_userid'])?></h2>        <p><?php echo htmlspecialchars_decode($row['aik_gbook_content']);?></p>    </div>  </td>  <td class="msg_time"><?php echo date("Y-m-d H:i:s",$row['aik_gbook_time'])?></td>  <td class="msg_reply"><?php echo get_gbook_reply($_GET['id'])?></td></tr>
					<?php }$result = mysql_query('select * from aikcms_gbook where aik_gbook_reply='.$_GET['id'].' order by id desc');
									while($row= mysql_fetch_array($result)){
					?>
									<tr>  <td class="msg_info">    <img src="<?php echo $aik_admin_img;?>" width="50" height="50">    <div class="user_info">        <h2><?php echo $aik_admin;?></h2>        <p><?php echo htmlspecialchars_decode($row['aik_gbook_content']);?></p>    </div>  </td>  <td class="msg_time"><?php echo date("Y-m-d H:i:s",$row['aik_gbook_time'])?></td>  <td class="msg_reply"><a class="layui-btn layui-btn-danger layui-btn-mini"  href="?del=<?php echo $row['id']?>"><i class="layui-icon"></i> 删除</a></td></tr>
									
									<?php }?>
					
			</tbody>
		</table>

	<script type="text/javascript" src="../../layui/layui.js"></script>
	<script type="text/javascript" src="message.js"></script>
</body>
</html>