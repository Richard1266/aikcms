<?php
if(!file_exists('./common/install/install.lock')){
   header('location:/install.php');
} 
include('common/basic.php');
if($aik_cache=='1'){include('common/cache.php');}
if(!isset($mode))$mode = 'index';
$mode_arr = array('md_index','md_video','md_search','md_list','md_play','md_cxlist','md_zhibo','md_gbook','md_404');
if(in_array('md_'.$mode,$mode_arr)){
	include('./template/'.$template.'/aik_'.$mode.'.php');
}else{
	show_error('Not in mode_arr');
}
?>