<?php 
$zhibo = mysql_fetch_array(mysql_query('select * from aikcms_zhibo where id = 1'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/play.css' type='text/css' media='all' />
<script type='text/javascript' src='http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js?ver=0.5'></script>	
<script type="text/javascript " src="<?php echo $aik_domain;?>template/<?php echo $template;?>/js/history.js "></script>	
<title>电视直播-<?php echo $aik_title;?></title>
<meta name="keywords" content="电视直播-<?php echo $aik_keywords;?>">
<meta name="description" content="<?php echo $aik_desc;?>">
</head>
<body>
<?php  include 'aik_head.php';?>
<div class="single-post">
<section class="container">
<?php if($aik_zhibo=="2"){?>
<div class="content-wrap">
<div class="content"><!--删掉可全屏-->
<div class="asst asst-post_header"><?php echo aik_gg(1);?></div>
<div class="am-panel am-panel-default">
<div class="am-panel-bd">
<div class="bofangdiv">
<img id="addid" src="<?php echo $aik_domain;?>template/<?php echo $template;?>/images/loading388.gif" style="display: none;width:100%; ">
<iframe id="video" src="<?php echo $zhibo['aik_zhibo_url'];?>" style="width:100%;border:none"></iframe>
<a style="display:none" id="videourlgo" href=""></a>
</div>
<div id="xlu">
</div>

<div style="clear: both;"></div> 
<div id="xuji"></div>
<?php echo aik_gg(2);?>
<div class="video-list view-font">
<div class="dianshijua"  id="dianshijua"><div id="xlus" style='padding:0' ><form method="post"><button class="btn-default jkbtn" style='float:right' name="save" >加入收藏</button></form></div>
<h3 class='single-strong'>无需安装任何插件</h3>
<div class="top-list-ji">
<h2 class="title g-clear"><em class="a-bigsite a-bigsite-leshi"></em></h2>
<div class="ji-tab-content js-tab-content" style="opacity:1;">
<?php
						$result = mysql_query('select * from aikcms_zhibo order by id asc');
						while($row = mysql_fetch_array($result)){
						?>
						<a  target="ajax" id="<?php echo $row['aik_zhibo_name'];?>" href="<?php echo $row['aik_zhibo_url'];?>"><?php echo $row['aik_zhibo_name'];?></a>
						<?php
						}
						?>

</div>
</div>          
</div>
<div style="clear: both;"></div>
<?php echo $aik_changyan;?>
<div style="clear: both;"></div>
<script type="text/javascript">
	var al = $('.dianshijua a');
	al.attr('class','am-btn am-btn-default lipbtn');
	var ji= new Array();
	var btnji= new Array();
	for(var g=0;g<al.length;g++){
		ji.push(al[g].href);
		btnji.push(al[g].id);
		al[g].href = 'javascript:void(0)';
		al[g].target = '_self';
		al.eq(g).attr('onclick','bofang(\''+ji[g]+'\',\''+btnji[g]+'\')');
	};
</script>
<script type="text/javascript">
	function bofang(mp4url,jiid){
		var tishi = ('正在为您播放《'+jiid+'》');
				document.getElementById('videourlgo').href=mp4url;
		document.getElementById('xuji').innerHTML = tishi;
		
		if((mp4url.indexOf('m3u8')>=0)||(mp4url.indexOf('mp4')>=0)){
			document.getElementById('video').src='<?php echo $aik_jiexi1;?>'+mp4url;
		}else{
			document.getElementById('video').src='<?php echo $jiexi;?>'+mp4url;
		};	
		//点击之后
		document.getElementById('xuji').style.display='block';
		document.getElementById('video').style.display='none';
		document.getElementById('addid').style.display = 'block';
		document.getElementById('xlu').style.display = 'block';
		function test() {
			document.getElementById('video').style.display='block';
			document.getElementById('addid').style.display = 'none';
		}
		setTimeout(test, 5000);
	};
</script>
	
<div class="article-actions clearfix">
 <div class="shares">
        <strong>分享到：</strong>
        <a href="javascript:;" data-url="<?php echo $aik['pcdomain'];?>" class="share-weixin" title="分享到微信"><i class="fa"></i></a><a etap="share" data-share="qzone" class="share-qzone" title="分享到QQ空间"><i class="fa"></i></a><a etap="share" data-share="weibo" class="share-tsina" title="分享到新浪微博"><i class="fa"></i></a><a etap="share" data-share="tqq" class="share-tqq" title="分享到腾讯微博"><i class="fa"></i></a><a etap="share" data-share="qq" class="share-sqq" title="分享到QQ好友"><i class="fa"></i></a><a etap="share" data-share="renren" class="share-renren" title="分享到人人网"><i class="fa"></i></a><a etap="share" data-share="douban" class="share-douban" title="分享到豆瓣网"><i class="fa"></i></a>
    </div>   
 <a href="javascript:;" class="action-rewards" etap="rewards">打赏</a>
</div> 
</div>
</div></div></div></div>
<?php  include 'aik_sidebar.php';?>
<?php }else{?>
<iframe scrolling='no' frameborder='0' src='./rule/zhibo.html' width='100%' height='600px' style='display:block;'></iframe>	
<?php }?>
</section>
</div>
<?php  include 'aik_foot.php';?>
</body>
</html>

