<?php
$rurl=file_get_contents($url);
$rurl = strstr($rurl, "<div monitor-desc='分页'") ;
$rurl = strstr($rurl, '</div>',TRUE) ;
$rurl = str_replace('http://www.360kan.com/',"./index.php?mode=list&net=",$rurl);
echo $rurl;
?>