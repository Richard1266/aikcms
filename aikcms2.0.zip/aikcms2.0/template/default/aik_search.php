<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<title>《<?php echo $wd;?>》-搜索结果-<?php echo $aik_title;?></title>
<meta name="keywords" content="《<?php echo $wd;?>》搜索结果-<?php echo $aik_keywords;?>">
<meta name="description" content="<?php echo $aik_title;?>-《<?php echo $wd;?>》搜索结果-<?php echo $aik_desc;?>">
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/seacher.css' type='text/css' media='all' />
<script type='text/javascript' src='http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js?ver=0.5'></script>

<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
<style>
.w-mfigure{
    width: 18%;min-width:150px;
    height: 180px;
	float:left;
    margin-left: 10px;
    margin-top: 0px;
display: inline-block;}
h4{font-size:12px}
</style>
</head>
<?php  include 'aik_head.php';?>

<section class="container">
<div style="text-align: center;padding: 10px 0;color: #FF7562;font-size: 12px;">温馨提示:请点击搜索结果的标题或封面图进行观看</div>
<strong class="single-strong">站外搜索列表</strong>
<div class="excerpts">
<div class="zhan">
<div class="video-list"><ul class="mvul">
<?php
$result = mysql_query('select * from aikcms_video where `aik_video_name` like "%'.$wd.'%"  order by id desc');
while ($row = mysql_fetch_array($result)){
	if($aik_weijing==1){
$link='./vod/'.$row['id'].'.html';	
}else{
$link='./index.php?mode=play&vod='.$row['id'];
}
	?>
<li  class="item"><a class="js-tongjic" href='<?php echo $link?>' title='<?php echo $row['aik_video_name']?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $row['aik_video_img']?>' alt='<?php echo $row['aik_video_name']?>' />
         
         </div>
         <div class='detail'>
          <p class='title g-clear'>
		    <span class='s1'><?php echo $row['aik_video_name']?></span></p>
          </div>
         </a></li>
<?php } ?></ul>
<ul class="mvul" id="search">
<script>
 $(document).ready(function(){ 
         $('#search').html('<p style="color:#FC5D73; text-align: center; padding:10px; margin:5px;"><img  style=" width: 50px; height: 50px;" src="http://wx1.sinaimg.cn/large/006J7kZbgy1ftl33y8z8yg301o01owea.gif" />拼命加载中 请稍等......</p>');
		 $('#search').load("/api.php?mode=search&wd=<?php echo $wd?>",
function(url,status,c){ 
         if(status=="error"){ 
         $(this).html('<p style="color:#FC5D73; text-align: center; padding:10px; margin:5px;"><img  style=" width: 50px; height: 50px;" src="http://wx1.sinaimg.cn/large/006J7kZbgy1ftl33y8z8yg301o01owea.gif" />加载失败，请刷新页面......</p>');
    } 
  }); 
}) 
</script>
</ul>
</div></div>
</div> 
<strong class="single-strong">全网搜索(来自爱奇艺/优酷/腾讯/乐视等)</strong>
<div class="zhan">
<div class="video-list">
<ul class="mvul" id="searchall">
 <script>
 $(document).ready(function(){ 
         $('#searchall').html('<p style="color:#FC5D73; text-align: center; padding:10px; margin:5px;"><img  style=" width: 50px; height: 50px;" src="http://wx1.sinaimg.cn/large/006J7kZbgy1ftl33y8z8yg301o01owea.gif" />拼命加载中 请稍等......</p>');
		 $('#searchall').load("/api.php?mode=searchall&wd=<?php echo $wd?>",
function(url,status,c){ 
         if(status=="error"){ 
         $(this).html('<p style="color:#FC5D73; text-align: center; padding:10px; margin:5px;"><img  style=" width: 50px; height: 50px;" src="http://wx1.sinaimg.cn/large/006J7kZbgy1ftl33y8z8yg301o01owea.gif" />加载失败，请刷新页面......</p>');
    } 
  }); 
}) 
</script>
</ul>
</div></div>
<div style="clear: both;"></div>
</section>
<?php  include 'aik_foot.php';?>