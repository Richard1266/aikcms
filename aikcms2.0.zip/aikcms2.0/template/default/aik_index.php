<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="bookmark"href="/favicon.ico" />
<title><?php echo $aik_title;?></title>
<meta name="keywords" content="<?php echo $aik_keywords;?>">
<meta name="description" content="<?php echo $aik_desc;?>">
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/index.css' type='text/css' media='all' />
<script type='text/javascript' src='http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js?ver=0.5'></script>
<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
</head>
<body class="home blog">
<?php  include 'aik_head.php';?>
<div id="homeso">
<form method="get" id="soform" style="text-align: center;float: none" action="./index.php">
<img id="imgsrc" src="<?php echo $aik_onelogo;?>"><br><br>
<br><br><input type="hidden" name="mode" value="search">
<input tabindex="2" class="homesoin" id="sos" name="wd" type="text" placeholder="输入你要观看的视频名" value="">
<button id="button" tabindex="3" class="homesobtn" type="submit">搜索</button>
</form>
</div>
<section class="container">

<div class="single-strong">电影尝鲜<span class="chak"><a href="index.php?mode=cxlist&fl=cx">查看更多</a></span></div>
<div class="b-listtab-main">
<div class="s-tab-main">
<ul class="list g-clear">
<?php 
//老尝鲜
if($aik_fresh_on <>'0'){
include './rule/cx.php'; 
foreach($resultcx as $k=>$c){ 
if($k>5){break;}
if($aik_weijing==1){
$link='./vid/'.$c['id'].'.html';	
}else{
$link='./index.php?mode=play&vid='.$c['id'];
}
?>
<li  class="item"><a class="js-tongjic" href='<?php echo $link?>' title='<?php echo $c['title']?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $c['img']?>' alt='<?php echo $c['title']?>' />
         
         </div>
         <div class='detail'>
          <p class='title g-clear'>
		    <span class='s1'><?php echo $c['title']?></span></p>
          </div>
         </a></li>
<?php }} ?>
<?php
if($_COOKIE["userid"]){$userid=$_COOKIE["userid"];}
$n = $aik_fresh_on <>'0' ? '6':'12';
$result = mysql_query('select * from aikcms_video where `aik_video_url`<>""  ORDER BY aik_video_level DESC,id DESC LIMIT 0,'.$n.'');
while ($row = mysql_fetch_array($result)){
	$video_usergroupid = get_video_usergroup($row['aik_video_group'])== '0' ? $row['aik_video_usergroup']:get_video_usergroup($row['aik_video_group']);
	$array_video_usergroup = explode(",", $video_usergroupid); 	
if ((in_array('0', $array_video_usergroup))&&(!aik_video_buy($row['id'],$userid))&&($row['aik_video_int']<>0)){
$point="onclick=\"return confirm('观看此视频需要支付".$row['aik_video_int']."积分，您是否观看？')\"";}else{$point="";}
if($aik_weijing==1){
$link='./vod/'.$row['id'].'.html';	
}else{
$link='./index.php?mode=play&vod='.$row['id'];
}
?>
<li  class="item"><a class="js-tongjic" href='<?php echo $link?>' title='<?php echo $row['aik_video_name']?>' target='_blank' <?php echo $point?>>
         <div class='cover g-playicon'>
          <img src='<?php echo $row['aik_video_img']?>' alt='<?php echo $row['aik_video_name']?>' /><span class='hint'><?php echo $row['aik_video_remarks']?></span>
         
         </div>
         <div class='detail'>
          <p class='title g-clear'>
		    <span class='s1'><?php echo $row['aik_video_name']?></span></p>
          </div>
         </a></li>
<?php } ?>

</ul>
</div>
</div>

<?php if($aik_union_open<>'0'){?>
<div class="single-strong">精品推荐<span class="chak"><a href="../yhq.php?r=l&u=1">查看更多</a></span></div>
<div class="b-listtab-main">
<div class="s-tab-main">
<ul class="list g-clear">
<?php
include './rule/union.php'; 
 for ($i=0; $i < 6; $i++) {
      $k=$num[$i];
	  $yhq=$daiq[$k]-$daih[$k];
		?>
		
		
	  <style>.s0{word-wrap: break-word;font-size: 13px;color: #999;width: 190px;height: 40px;line-height: 15px;}
		  </style>
		  <li  class='item'><a class='js-tongjic' href='<?php echo $unionurl.$iidd[$k].$unionid?>' title='<?php echo $name[$k]?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $img[$k]?>' alt='<?php echo $name[$k]?>' />
          <span class='pay' style=' width:auto;background:#ff435e; padding:0 10px;'>优惠券：<?php echo $yhq?>元</span>
		  <span class='hint' style='right:50px;'>券后价￥</span>
		  <span class='hint' style='background:#fef07e;width: 40px; height:30px; line-height:30px;text-align: center; font-size:14px; font-weight:bold; color:#ff435e;'><?php echo $daih[$k]?></span>
         </div>
         <div class='detail'>
          <p class='title g-clear' style=' margin-top:5px;'>
		    <span class='s0'><?php echo $name[$k]?></span></p>
          </div>
	</a></li>		
 <?php }?>
</ul>
</div>
</div>
 <?php }?>
<div class="single-strong">最新热门电影推荐<span class="chak"><a href="./index.php?mode=list&fl=dianying">查看更多</a></span></div>
<div class="b-listtab-main">
<div class="s-tab-main">
<ul class="list g-clear">
<?php 
include './rule/movie.php'; 
foreach($resultdy as $k=>$c){ 
if($k>11){break;}
if($aik_weijing==1){
$link='./video'.$c['link'];
}else{
$link='./index.php?mode=video&net='.$c['link'];
}
?>
    <li  class='item'><a class='js-tongjic' href='<?php echo $link?>' title='<?php echo $c['name']?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $c['img']?>' alt='<?php echo $c['name']?>' /> <span class='hint'><?php echo $c['nname']?></span>
         </div>
         <div class='detail'>
          <p class='title g-clear'>
		    <span class='s1'><?php echo $c['name']?></span></p>
           <p class='star'><?php echo $c['star']?></p>
          </div>
         </a></li>
		<?php } ?>
</ul>
</div>
</div>


<div class="single-strong">最新热门电视剧推荐<span class="chak"><a href="./index.php?mode=list&fl=dianshi">查看更多</a></span></div>
<div class="b-listtab-main">
<div class="s-tab-main">
<ul class="list g-clear">
<?php 
include './rule/tv.php'; 
foreach($resulttv as $k=>$c){ 
if($k>11){break;}
if($aik_weijing==1){
$link='./video'.$c['link'];	
}else{
$link='./index.php?mode=video&net='.$c['link'];
}
?>
    <li  class='item'><a class='js-tongjic' href='<?php echo $link?>' title='<?php echo $c['name']?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $c['img']?>' alt='<?php echo $c['name']?>' /> <span class='hint'><?php echo $c['nname']?></span>
         </div>
         <div class='detail'>
          <p class='title g-clear'>
		    <span class='s1'><?php echo $c['name']?></span></p>
           <p class='star'><?php echo $c['star']?></p>
          </div>
         </a></li>
		<?php } ?>
</ul>
</div>
</div>

<div class="single-strong">最新热门综艺推荐<span class="chak"><a href="./index.php?mode=list&fl=zongyi">查看更多</a></span></div>
<div class="b-listtab-main">
<div class="s-tab-main">
<ul class="list g-clear">
<?php 
include './rule/zongyi.php'; 
foreach($resultzy as $k=>$c){ 
if($k>11){break;}
if($aik_weijing==1){
$link='./video'.$c['link'];	
}else{
$link='./index.php?mode=video&net='.$c['link'];
}
?>
    <li  class='item'><a class='js-tongjic' href='<?php echo $link?>' title='<?php echo $c['name']?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $c['img']?>' alt='<?php echo $c['name']?>' /> <span class='hint'><?php echo $c['nname']?></span>
         </div>
         <div class='detail'>
          <p class='title g-clear'>
		    <span class='s1'><?php echo $c['name']?></span></p>
           <p class='star'><?php echo $c['star']?></p>
          </div>
         </a></li>
		<?php } ?>
</ul>
</div>
</div>

<div class="single-strong">最新热门动漫推荐<span class="chak"><a href="./index.php?mode=list&fl=dongman">查看更多</a></span></div>
<div class="b-listtab-main">
<div class="s-tab-main">
<ul class="list g-clear">
<?php 
include './rule/dongman.php';
foreach($resultdm as $k=>$c){ 
if($k>11){break;}
if($aik_weijing==1){
$link='./video'.$c['link'];	
}else{
$link='./index.php?mode=video&net='.$c['link'];
}
?>
    <li  class='item'><a class='js-tongjic' href='<?php echo $link?>' title='<?php echo $c['name']?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $c['img']?>' alt='<?php echo $c['name']?>' /> <span class='hint'><?php echo $c['nname']?></span>
         </div>
         <div class='detail'>
          <p class='title g-clear'>
		    <span class='s1'><?php echo $c['name']?></span></p>
           <p class='star'><?php echo $c['star']?></p>
          </div>
         </a></li>
		<?php } ?>
</ul>
</div>
</div>
</section>
<?php  include 'aik_foot.php';?>
</body>
</html>
