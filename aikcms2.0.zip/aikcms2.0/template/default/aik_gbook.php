<?php
$username=$_COOKIE["username"]; 
$num1 = rand(1, 10);
$num2 = rand(1, 10);
$opt = array('+', '-');
$optrand = $opt[rand(0, 1)];
$number = $num1 . $optrand . $num2;
$sum = eval("return $number;");
if (isset($_POST['save'])) {
	$_data['aik_gbook_content'] = htmlspecialchars($_POST['aik_gbook_content']);
	$_data['aik_gbook_userid'] = get_user_id($username);
	$_data['aik_gbook_time'] = time();
	if($_POST['sum']<>$_POST['result']){alert_back('计算结果错误，请检查!');}else{
	$str = arrtoinsert($_data);
	$sql = 'insert into aikcms_gbook (' . $str[0] . ') values (' . $str[1] . ')';
   	if (mysql_query($sql)) {
	alert_href('留言发布成功!', 'index.php?mode=gbook');
	} else {
	alert_back('发布失败!');
	}
	}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<title>留言板-<?php echo $aik_title;?></title>
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/movie.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/gbook.css' type='text/css' media='all' />
<script type='text/javascript' src='http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js?ver=0.5'></script>
</head>
<body>
<?php  include 'aik_head.php';?>
<div id="container">
	<div class="page-full">				
		<div class="commentslist">
	<h2>留言板</h2>	
	<ol>
	
		<?php
			$sql = 'select * from aikcms_gbook where aik_gbook_reply = "0" order by id desc';
									$pager = page_handle('page',10,mysql_num_rows(mysql_query($sql)));
									$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
									while($row= mysql_fetch_array($result)){
									?>
	<li>
		<div class="gravatar">
			<img src="<?php echo get_user_img($row['aik_gbook_userid'])?>" class="avatar"/></div>
		<div class="comment-info">
			<div class="comment-author"><?php echo get_user_name($row['aik_gbook_userid'])?><?php echo aik_gbook_usergroupimg($row['aik_gbook_userid'])?></div>
			<div class="comment-time"><span><?php echo date("Y-m-d H:i:s",$row['aik_gbook_time'])?></span></div>
		</div>	
		<div class="comment-text"><p><?php echo htmlspecialchars_decode($row['aik_gbook_content']);?></p></div>
   <?php if((get_gbook_reply($row['id']))<>""){?> 
	<ul class="children">
	<?php
	$resultt = mysql_query('select * from aikcms_gbook where aik_gbook_reply='.$row['id'].' order by id desc');
   while($roww = mysql_fetch_array($resultt)){?>
   <li>
		<div class="gravatar">
			<img src="<?php echo $aik_admin_img;?>" class="avatar" height="45" width="45" /></div>
		<div class="comment-info">
			<div class="comment-author"><span>管理回复</span></div>
			<div class="comment-time"><span><?php echo date("Y-m-d H:i:s",$row['aik_gbook_time'])?></span>
			</div>
		</div>	
		<div class="comment-text"><p><?php echo htmlspecialchars_decode($roww['aik_gbook_content']);?></p></div>
    </li>	
<?php }?>
	
    </ul>
    <?php }?>
    </li>	
    <?php }?>
</ol>
<div monitor-desc="分页" id="js-ew-page" data-block="js-ew-page" class="ew-page"><?php echo page_show($pager[2],$pager[3],$pager[4],2);?>
</div>
</div>
<div class="commentform" id="respond">
	<h3>发表留言</h3>
		<form method="post">
				<p>
			<label for="url">留言内容：</label>
			<textarea name="aik_gbook_content" cols="100%" rows="4" ></textarea>
		</p>
				<p>
		<label for="math">请输入 <i><?php echo $number;?></i> 的计算结果：</label>
        <input type="text" name="sum" class="text" value="" size="25" tabindex="4">	</p>
        <input type="hidden" name="result"  value="<?php echo $sum;?>" >	</p>
				<p>
		<?php if($username==NULL){echo '<br><a class="submit" href="user.php?mode=login">请先登录</a>';}else{
		echo '<button class="submit"   name="save"> 点击留言 </button>';}
		?>
			
		</p>	</form>
	</div>
			</div>	
</div>
<?php  include 'aik_foot.php';?>
</body>
</html>