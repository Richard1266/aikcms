<?php 
setcookie('affid',$aff);?>
<header class="header">
	<div class="container">
		<h1 class="logo"><a href="<?php echo $aik_domain;?>" title="<?php echo $aik_title;?>"><img src="<?php echo $aik_domain;?><?php echo $aik_biglogo;?>"><span><?php echo $aik_title;?></span></a></h1>	
		<div class="sitenav">
		<ul>
<li class="menu-item"><a href="/">首页</a></li>
<li class="menu-item"><a href="/index.php?mode=list&fl=dianying">电影</a></li>
<li class="menu-item"><a href="/index.php?mode=list&fl=dianshi">电视剧</a></li>
<li class="menu-item"><a href="/index.php?mode=list&fl=zongyi">综艺</a></li>
<li class="menu-item"><a href="/index.php?mode=list&fl=dongman">动漫</a></li>
<li class="menu-item"><a href="/index.php?mode=cxlist&fl=cx">最近更新</a></li>
<?php
						$result = mysql_query('select * from aikcms_nav where aik_nav_papa="0" order by aik_nav_id desc');
						while($row = mysql_fetch_array($result)){
						?>
<li class="menu-item <?php echo $a = aik_nav_baby($row['id']) > "0" ? "menu-item-has-children":""?>"><a href="<?php echo $row['aik_nav_url'];?>"><font color="<?php echo $row['aik_nav_color'];?>"><?php echo $row['aik_nav_name'];?></font></a>
<?php if(aik_nav_baby($row['id']) > "0"){
   echo '<ul class="sub-menu">';
   $resultt = mysql_query('select * from aikcms_nav where aik_nav_papa='.$row['id'].' order by aik_nav_id desc');
   while($roww = mysql_fetch_array($resultt)){
    echo '<li class="menu-item"><a href="'.$roww['aik_nav_url'].'" target="_blank">'.$roww['aik_nav_name'].'</a></li>';
	}echo '</ul></li>';
}?>
						<?php }?>
</ul>
		</div>
		<span class="sitenav-on"><i class="icon-list"></i></span>
		<span class="sitenav-mask"></span>
		<?php if($aik_user_open=="1"){?>
					<div class="searchform">
					 <a href="/user.php?mode=index" target="_blank" class="login more-list-box2 fr"><div class="dl">登录</div></a>
		</div><?php }?>
							<span class="searchstart-on"><i class="icon-search"></i></span>
			<span class="searchstart-off"><i class="icon-search"></i></span>
			<form method="get" class="searchform" action="/index.php" ><input type="hidden" name="mode" value="search">
				<button tabindex="3" class="sbtn" type="submit"><i class="fa"></i></button><input tabindex="2" class="sinput" name="wd" type="text" placeholder="输入关键字" value="">
			
             </form>
			</div>
</header>
