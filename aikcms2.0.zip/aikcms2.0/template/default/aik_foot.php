<div class="foornav">
	<a href="<?php echo $aik_domain;?>"><span><img src="<?php echo $aik_domain;?>template/<?php echo $template;?>/images/index.png"/>首页</span></a>
	<a href="<?php echo $aik_domain;?>index.php?mode=list&fl=dianying"><span><img src="<?php echo $aik_domain;?>template/<?php echo $template;?>/images/video.png"/>电影</span></a>
	<a href="<?php echo $aik_domain;?>index.php?mode=list&fl=dianshi"><span><img src="<?php echo $aik_domain;?>template/<?php echo $template;?>/images/dianshi.png"/>电视剧</span></a>
	<a href="<?php echo $aik_domain;?>index.php?mode=list&fl=zongyi"><span><img src="<?php echo $aik_domain;?>template/<?php echo $template;?>/images/dianshiju.png"/>综艺</span></a>
	<?php if($aik_user_open=="1"){?>
	<a href="<?php echo $aik_domain;?>user.php?mode=index"><span><img src="<?php echo $aik_domain;?>template/<?php echo $template;?>/images/gouwu.png"/>个人中心</span></a><?php }else{?>
	<a href="<?php echo $aik_domain;?>index.php?mode=list&fl=dongman"><span><img src="<?php echo $aik_domain;?>template/<?php echo $template;?>/images/gouwu.png"/>动漫</span></a><?php }?>
</div>
<footer class="footer">
<div class="branding branding-black">
	<div class="container" style="text-align: center;">
		<h2><?php echo $aik_title;?></h2>
<?php
						$result = mysql_query('select * from aikcms_link');
						while($row = mysql_fetch_array($result)){
						?>
						<a class="gobtn" href="<?php echo $row['aik_link_url'];?>" target="_blank"><?php echo $row['aik_link_name'];?></a><?php
						}
						?>
			</div>
</div>


<p style="padding: 0 4px;">本站提供的电影和电视剧资源均收集于各大视频网站,本站只提供web页面服务,并不提供影片资源存储,也不参与录制、上传</br>若本站收录的节目无意侵犯了贵司版权，请与网站管理员联系,我们会及时处理和回复,谢谢。<br/>管理员QQ：<?php echo $aik_admin_qq;?><br/><a href="http://www.miitbeian.gov.cn"><?php echo $aik_icp;?></a>&nbsp; 
        本站主题由<a href="http://www.xiaoerhu.com" target="_blank"><font color="red"><!--请务必保留版权链接，以便更好为您提供服务，超级感谢-->小<!--请务必保留版权链接，以便更好为您提供服务，超级感谢-->二<!--请务必保留版权链接，以便更好为您提供服务，超级感谢-->胡<!--请务必保留版权链接，以便更好为您提供服务，超级感谢-->工<!--请务必保留版权链接，以便更好为您提供服务，超级感谢-->作<!--请务必保留版权链接，以便更好为您提供服务，超级感谢-->室<!--请务必保留版权链接，以便更好为您提供服务，超级感谢--></font></a> 提供 &nbsp; <?php echo $aik_tongji;?> </footer>
	<div class="rewards-popover-mask" etap="rewards-close"></div>
	<div class="rewards-popover">
		<h3>觉得本站还不错就打赏一下吧！</h3>
				<div class="rewards-popover-item">
			<h4>支付宝扫一扫打赏</h4>
			<img src="<?php echo $aik_zfbsk;?>">
		</div>
						<div class="rewards-popover-item">
			<h4>微信扫一扫打赏</h4>
			<img src="<?php echo $aik_wxsk;?>">
		</div>
				<span class="rewards-popover-close" etap="rewards-close"></span>
	</div> 
<script type='text/javascript' src='<?php echo $aik_domain;?>template/<?php echo $template;?>/js/main.js'></script>
