<?php 
if($fl){ $url='http://www.360kan.com/'.$fl.'/list';	}
elseif($net){$url='http://www.360kan.com/'.substr($_SERVER["QUERY_STRING"],14);}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<title><?php echo $aik_title;?></title>
<meta name="keywords" content="<?php echo $aik_keywords;?>">
<meta name="description" content="<?php echo $aik_desc;?>">
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/movie.css' type='text/css' media='all' />
<script type='text/javascript' src='http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js?ver=0.5'></script>
<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
</head>
<body>
<?php  include 'aik_head.php';?>
<section class="container"><div class="fenlei">
<div class="b-listfilter" style="padding: 0px;">

<dl class="b-listfilter-item js-listfilter" style="padding-left: 0px;height:auto;padding-right:0px;">
<dd class="item g-clear js-listfilter-content" style="margin: 0;">
<?php include 'data/filter.php'; ?> 
</dd>
</dl>
</div>
</div>
<div class="m-g">
<div class="b-listtab-main">
<div>
<div>
<div class="s-tab-main">
<ul class="list g-clear">
<?php
if($aik_union_open<>'0'){
include './rule/union.php'; 
 for ($i=0; $i < 2; $i++) {
      $k=$num[$i];
	  $yhq=$daiq[$k]-$daih[$k];
		?>
 <style>.s0{word-wrap: break-word;font-size: 13px;color: #999;width: 190px;height: 40px;line-height: 15px;}
		  </style>
		  <li  class='item'><a class='js-tongjic' href='<?php echo $unionurl.$iidd[$k].$unionid?>' title='<?php echo $name[$k]?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $img[$k]?>' alt='<?php echo $name[$k]?>' />
          <span class='pay' style=' width:auto;background:#ff435e; padding:0 10px;'>优惠券：<?php echo $yhq?>元</span>
		  <span class='hint' style='right:50px;'>券后价￥</span>
		  <span class='hint' style='background:#fef07e;width: 40px; height:30px; line-height:30px;text-align: center; font-size:14px; font-weight:bold; color:#ff435e;'><?php echo $daih[$k]?></span>
         </div>
         <div class='detail'>
          <p class='title g-clear' style=' margin-top:5px;'>
		    <span class='s0'><?php echo $name[$k]?></span></p>
          </div>
	</a></li>
<?php }}?>
<?php 
include 'rule/rl_list.php'; 
foreach($resultlb as $k=>$c){ 
if($aik_weijing==1){
$link='./video'.$c['link'];	
}else{
$link='./index.php?mode=video&net='.$c['link'];
}
?>
<li class="item">
                        <a class="js-tongjic" href="<?php echo $link?>">
                            <div class="cover g-playicon">
                                <img src="<?php echo $c['img']?>">
                                                                <span class="hint"><?php echo $c['beizhu']?></span>   </div>
                            <div class="detail">
                                <p class="title g-clear">
                                    <span class="s1"><?php echo $c['name']?></span>
                                </p>
                                <p class="star"><?php echo $c['star']?></p>
                            </div>
                        </a>
                    </li>

<?php }?>
        </ul>
                </div>
    </div>
</div> </br>
<div style="clear: both;"></div>
<?php include 'data/fenye.php'; ?> 
</div></div>
<div class="asst asst-list-footer"><?php echo aik_gg(3);?></div></section>
<?php  include 'aik_foot.php';?>
</body></html>