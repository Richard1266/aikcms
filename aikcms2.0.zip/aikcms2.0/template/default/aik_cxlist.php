<?php
include './rule/cx_list.php';
$username=$_COOKIE["username"]; 
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<title>视频列表-<?php echo $aik_title;?></title>
<meta name="keywords" content="<?php echo $aik_keywords;?>">
<meta name="description" content="<?php echo $aik_desc;?>">
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/movie.css' type='text/css' media='all' />
<script type='text/javascript' src='http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js?ver=0.5'></script>

<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
</head>
<body>
<?php  include 'aik_head.php';?>
<section class="container"><div class="fenlei">
<div class="b-listfilter" style="padding: 0px;">

<dl class="b-listfilter-item js-listfilter" style="padding-left: 0px;height:auto;padding-right:0px;">
<dd class="item g-clear js-listfilter-content" style="margin: 0;">
<?php
$response = strstr($response, '<div class="header-tag">') ;
$response = strstr($response, '</ul>',TRUE) ;
$response = str_replace('<div class="header-tag">', "", $response);
$response = str_replace("<ul>", "", $response);
$response = str_replace('</li>', '', $response);
$response = str_replace('class="on"', "", $response);
$response = str_replace('<li>', '', $response);
$response = str_replace('<li >', '', $response);
$response = str_replace("/index.php/whole/index/", "./index.php?mode=cxlist&net=", $response);
echo $response;
?>  
<?php
$result = mysql_query('select * from aikcms_videogroup  order by id desc');
while ($row = mysql_fetch_array($result)){
			echo '<a href="./index.php?mode=cxlist&vod='.$row['id'].'">'.$row['aik_videogroup_name'].'</a>';
		}
?> 
</dd>
</dl>
</div>
</div>
<div class="m-g">
<div class="b-listtab-main">
<div>
<div>
<div class="s-tab-main">
<ul class="list g-clear">
<?php
if($aik_union_open<>'0'){
include './rule/union.php'; 
 for ($i=0; $i < 9; $i++) {
      $k=$num[$i];
	  $yhq=$daiq[$k]-$daih[$k];
		?>
 <style>.s0{word-wrap: break-word;font-size: 13px;color: #999;width: 190px;height: 40px;line-height: 15px;}
		  </style>
		  <li  class='item'><a class='js-tongjic' href='<?php echo $unionurl.$iidd[$k].$unionid?>' title='<?php echo $name[$k]?>' target='_blank'>
         <div class='cover g-playicon'>
          <img src='<?php echo $img[$k]?>' alt='<?php echo $name[$k]?>' />
          <span class='pay' style=' width:auto;background:#ff435e; padding:0 10px;'>优惠券：<?php echo $yhq?>元</span>
		  <span class='hint' style='right:50px;'>券后价￥</span>
		  <span class='hint' style='background:#fef07e;width: 40px; height:30px; line-height:30px;text-align: center; font-size:14px; font-weight:bold; color:#ff435e;'><?php echo $daih[$k]?></span>
         </div>
         <div class='detail'>
          <p class='title g-clear' style=' margin-top:5px;'>
		    <span class='s0'><?php echo $name[$k]?></span></p>
          </div>
	</a></li>
<?php }}?>
<?php 
if($net){
foreach($resultcx as $k=>$c){ 
if($aik_weijing==1){
$link='/vid/'.$c['id'].'.html';	
}else{
$link='/index.php?mode=play&vid='.$c['id'];
}
echo '<li class="item"><a href="'.$link.'"><div class="cover g-playicon"><img src="'.$c['img'].'" /></div><div class="detail"><p class="title g-clear"><span class="s1">'.$c['title'].'</span></div></a></li>';}
}else{	
if($vod){
if((in_array(aik_user_usergroupid($username), explode(",", get_video_usergroup($vod))))||(get_video_usergroup($vod)=='0')){
$sql = 'select * from aikcms_video where `aik_video_group`='.$vod.'  and  `aik_video_url`<>""  order by id desc';
$pager = page_handle('page',15,mysql_num_rows(mysql_query($sql)));
$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');	                           
while($row= mysql_fetch_array($result)){
	
	    $video_usergroupid = get_video_usergroup($row['aik_video_group'])== '0' ? $row['aik_video_usergroup']:get_video_usergroup($row['aik_video_group']);
	    $array_video_usergroup = explode(",", $video_usergroupid); 	
        if ((in_array('0', $array_video_usergroup))&&(in_array('0', $array_video_usergroup))&&(!aik_video_buy($row['id'],$userid))&&($row['aik_video_int']<>0)){
        $point="onclick=\"return confirm('观看此视频需要支付".$row['aik_video_int']."积分，您是否观看？')\"";}else{$point="";}
if($aik_weijing==1){
$link='./vod/'.$row['id'].'.html';	
}else{
$link='./index.php?mode=play&vod='.$row['id'];
}
			echo '<li class="item"><a href="'.$link.'" '.$point.'><div class="cover g-playicon"><img src="'.$row['aik_video_img'].'" /><span class="hint">'.$row['aik_video_remarks'].'</span></div><div class="detail"><p class="title g-clear"><span class="s1">'.$row['aik_video_name'].'</span></p></div></a></li>';
}}else{alert_back('该视频分组仅支持 / '.aik_video_usergroup(get_video_usergroup($vod)).'观看！');} 
}else{
$sql = 'select * from aikcms_video where  `aik_video_url`<>""  order by id desc';
$pager = page_handle('page',15,mysql_num_rows(mysql_query($sql)));
$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');	                           
while($row= mysql_fetch_array($result)){	
        $video_usergroupid = get_video_usergroup($row['aik_video_group'])== '0' ? $row['aik_video_usergroup']:get_video_usergroup($row['aik_video_group']);
	    $array_video_usergroup = explode(",", $video_usergroupid); 	
        if ((in_array('0', $array_video_usergroup))&&(in_array('0', $array_video_usergroup))&&(!aik_video_buy($row['id'],$userid))&&($row['aik_video_int']<>0)){
        $point="onclick=\"return confirm('观看此视频需要支付".$row['aik_video_int']."积分，您是否观看？')\"";}else{$point="";}
		if($aik_weijing==1){
        $link='./vod/'.$row['id'].'.html';	
        }else{
        $link='./index.php?mode=play&vod='.$row['id'];
        }
		echo '<li class="item"><a href="'.$link.'" '.$point.'><div class="cover g-playicon"><img src="'.$row['aik_video_img'].'" /><span class="hint">'.$row['aik_video_remarks'].'</span></div><div class="detail"><p class="title g-clear"><span class="s1">'.$row['aik_video_name'].'</span></p></div></a></li>';
	
}}}



?>
        </ul>
                </div>
    </div>
</div> 
<br>
<div style="clear: both;"></div>
<?php
echo '<div class="ew-page">';
if($net){
$content = strstr($content, '<div class="page-list">') ;
$content = strstr($content, '</ul>',TRUE) ;
$content = str_replace("<li", "<a", $content);
$content = str_replace("</li>", "</a>", $content);
$content = str_replace("/index.php/whole/index/", "./index.php?mode=cxlist&net=", $content);
echo $content;	
}else{
echo page_show($pager[2],$pager[3],$pager[4],2);		
}
echo '</div>';
?>  

</div></div>
<div class="asst asst-list-footer"><?php echo aik_gg(3);?></div></section>
<?php  include 'aik_foot.php';?>
</body></html>