<?php 
include './rule/rl_play.php';
if($vod){
include './rule/video_pay.php';}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-css'  href='<?php echo $aik_domain;?>template/<?php echo $template;?>/css/play.css' type='text/css' media='all' />
<script type='text/javascript' src='http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js?ver=0.5'></script>
<script type="text/javascript " src="<?php echo $aik_domain;?>template/<?php echo $template;?>/js/history.js "></script>	
<title>正在播放-<?php echo $timu; ?>-<?php echo $aik_title;?></title>
<meta name="keywords" content="<?php echo $timu; ?>-<?php echo $aik_video_seo; ?>-播放页-<?php echo $aik_keywords;?>">
<meta name="description" content="<?php echo $aik_desc;?>">
</head>
<body>
<?php  include 'aik_head.php';?>
<div class="single-post">
<section class="container">
    <div class="content-wrap">
    	<div class="content"><!--删掉可全屏-->
<div class="asst asst-post_header"><?php echo aik_gg(1);?></div>
<div class="sptitle"><h1><?php echo $timu; ?></h1></div>
<div class="am-panel am-panel-default">
<div class="am-panel-bd">
<div class="bofangdiv">
<img id="addid" src="<?php echo $aik_domain;?>template/<?php echo $template;?>/images/loading388.gif" style="display: none;width:100%; ">
<iframe id="video" src="
<?php 
if($vid){
echo $fang;
}else{		
$arry[0]=explode('$',$arry[0]);
if(strstr($arry[0][1],'m3u8')||strstr($arry[0][1],'mp4')){
echo $aik_jiexi1.$arry[0][1];}else{
echo $jiexi.$arry[0][1];}}
 ?>
" style="width:100%;border:none"></iframe>

<a style="display:none" id="videourlgo" href=""></a>
</div>
<div id="xlu">
</div>

<div style="clear: both;"></div> 
<div id="xuji"></div>
<?php echo aik_gg(2);?>
<div class="video-list view-font">
<div <?php echo $a = $vod<>'' ? 'class="dianshijua"':''?>id="dianshijuid"><div id="xlus" style='padding:0' ><form method="post"><button class="btn-default jkbtn" style='float:right' name="save" >加入收藏</button></form></div>
<h3 class='single-strong'>无需安装任何插件</h3>
<div class="top-list-ji">
<h2 class="title g-clear"><em class="a-bigsite a-bigsite-leshi"></em></h2>
<div class="ji-tab-content js-tab-content" style="opacity:1;">
<?php 

if($vid){
foreach ($iidd as $key=>$iddd){
	if($aik_weijing==1){
    $link='/vid/'.$ljie[$key].'.html';	
    }else{
    $link='/index.php?mode=play&vid='.$ljie[$key];
    }
    //echo $much++;
    //echo $video.'<br/>';
    //echo $key.'<br/>';
echo "<a class='am-btn am-btn-default lipbtn ";
if($vid==$ljie[$key]){echo 'on';}
echo "' href='$link'>";echo "$jjshu[$key]</a>";}
}elseif($vod){		
for($i=0;$i<count($arr);$i++){	
$arr[$i]=explode('$',$arr[$i]);
	echo '<a  target="ajax" id="'.$arr[$i][0].'" href="'.$arr[$i][1].'">'.$arr[$i][0].'</a>';}
} 


?>
</div>
</div>          
</div>
<div style="clear: both;"></div>
<?php echo $aik_changyan;?>
<div style="clear: both;"></div>
<script type="text/javascript">
	var al = $('.dianshijua a');
	al.attr('class','am-btn am-btn-default lipbtn');
	var ji= new Array();
	var btnji= new Array();
	for(var g=0;g<al.length;g++){
		ji.push(al[g].href);
		btnji.push(al[g].id);
		al[g].href = 'javascript:void(0)';
		al[g].target = '_self';
		al.eq(g).attr('onclick','bofang(\''+ji[g]+'\',\''+btnji[g]+'\')');
	};
</script>
<script type="text/javascript">
	function bofang(mp4url,jiid){
		var tishi = ('正在为您播放《<?php echo $timu;?>》'+jiid+'');
				document.getElementById('videourlgo').href=mp4url;
		document.getElementById('xuji').innerHTML = tishi;
		
		if((mp4url.indexOf('m3u8')>=0)||(mp4url.indexOf('mp4')>=0)){
			document.getElementById('video').src='<?php echo $aik_jiexi1;?>'+mp4url;
		}else{
			document.getElementById('video').src='<?php echo $jiexi;?>'+mp4url;
		};	
		//点击之后
		document.getElementById('xuji').style.display='block';
		document.getElementById('video').style.display='none';
		document.getElementById('addid').style.display = 'block';
		document.getElementById('xlu').style.display = 'block';
		function test() {
			document.getElementById('video').style.display='block';
			document.getElementById('addid').style.display = 'none';
		}
		setTimeout(test, 5000);
	};
</script>
<script type="text/javascript "> 
                    var url = window.location.href;
					$MH.limit = 10;
					$MH.recordHistory({
						name: '<?php echo $timu; ?>',
						link: url,
					})
				</script>
		

<div class="article-actions clearfix">
 <div class="shares">
        <strong>分享到：</strong>
        <a href="javascript:;" data-url="<?php echo $aik['pcdomain'];?>" class="share-weixin" title="分享到微信"><i class="fa"></i></a><a etap="share" data-share="qzone" class="share-qzone" title="分享到QQ空间"><i class="fa"></i></a><a etap="share" data-share="weibo" class="share-tsina" title="分享到新浪微博"><i class="fa"></i></a><a etap="share" data-share="tqq" class="share-tqq" title="分享到腾讯微博"><i class="fa"></i></a><a etap="share" data-share="qq" class="share-sqq" title="分享到QQ好友"><i class="fa"></i></a><a etap="share" data-share="renren" class="share-renren" title="分享到人人网"><i class="fa"></i></a><a etap="share" data-share="douban" class="share-douban" title="分享到豆瓣网"><i class="fa"></i></a>
    </div>   
 <a href="javascript:;" class="action-rewards" etap="rewards">打赏</a>
</div> 
</div>
</div></div></div></div>
<?php  include 'aik_sidebar.php';?>
</section>
</div>
<?php  include 'aik_foot.php';?>
<?php include './rule/fav.php';?>
</body>
</html>

