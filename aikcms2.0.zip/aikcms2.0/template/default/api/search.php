<?php 
   include './rule/cxurl.php';
   $url=$cxlink.'/index.php/search?wd='.rawurlencode($wd);
  //初始化
    $curl = curl_init();
    //设置抓取的url
    curl_setopt($curl, CURLOPT_URL, $url);
    //设置头文件的信息作为数据流输出
    curl_setopt($curl, CURLOPT_HEADER, 1);
    //设置获取的信息以文件流的形式返回，而不是直接输出。
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    //执行命令
    $content = curl_exec($curl);
    //关闭URL请求
    curl_close($curl);
    //显示获得的数据
$content = str_replace('/attachment',"$cxlink/attachment",$content);
$list_match='#<li><a href="/index.php/show/index/(.*?)"><b>(.*?)</b><img src="(.*?)" /><span>(.*?)</span></a></li>#';
$list_match_result = array(
		'id'=>1,
		'img'=>3,
		'name'=>4,
	);
    preg_match_all($list_match,$content,$list_temp);
	foreach($list_temp[$list_match_result['id']] as $k=>$c){
		$resultss[$k]['id'] = $list_temp[$list_match_result['id']][$k];
		$resultss[$k]['img'] = $list_temp[$list_match_result['img']][$k];
		$resultss[$k]['name'] = strip_tags($list_temp[$list_match_result['name']][$k]);
}
foreach($resultss as $k=>$c){
if($aik_weijing==1){
$link='/vid/'.$c['id'].'.html';	
}else{
$link='/index.php?mode=play&vid='.$c['id'];
}
 echo '<li><a href="'.$link.'"><img src="'.$c['img'].'" /><span>'.$c['name'].'</span></a></li>';
 } 
?>