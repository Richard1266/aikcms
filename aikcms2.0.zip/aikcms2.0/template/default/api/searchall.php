<?php
$url = 'https://video.360kan.com/v?ie=utf-8&src=360sou_home&q=' .$wd. '&_re=0';
$ch = curl_init($url); //初始化
curl_setopt($ch, CURLOPT_HEADER, 0); // 不返回header部分
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回字符串，而非直接输出
curl_setopt($ch, CURLOPT_USERAGENT, "Dalvik/1.6.0 (Linux; U; Android 4.1.4; DROID RAZR HD Build/9.8.1Q-62_VQW_MR-2)");
curl_setopt($ch, CURLOPT_REFERER, "-");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    // https请求 不验证证书和hosts
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
$seach = curl_exec($ch);
$title='#js-playicon" title="(.*?)"#';
$link='#<a href="http://www.360kan.com(.*?)" class="g-playicon js-playicon#';
$img='#<img src="(.*?)" alt="(.*?)"#';
$title_result = array('name'=>1,);
$link_result = array('link'=>1,'panduan'=>3, );
$img_result = array('img'=>1,);
preg_match_all($title, $seach,$titlearr);//名字
preg_match_all($link, $seach,$linkarr);//链接
preg_match_all($img, $seach,$imgarr);//图片		
	foreach($titlearr[$title_result['name']] as $k=>$c){
		$results[$k]['name'] = $titlearr[$title_result['name']][$k];
		$results[$k]['link'] = $linkarr[$link_result['link']][$k];
		$results[$k]['img'] = $imgarr[$img_result['img']][$k];
}
foreach($results as $k=>$c){ 
if($aik_weijing==1){
$link='./video'.$c['link'];
}else{
$link='./index.php?mode=video&net='.$c['link'];
}
?>
<li><a href="<?php echo $link?>"><img src="<?php echo $c['img']?>" /><span><?php echo $c['name']?></span></a></li>
<?php } ?>
