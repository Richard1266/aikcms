<div class="sidebar">
<style>
.list a{display:block;padding:10px 0 0;background-color:#fff;font-size:13px;border:0}
</style>
<div class="widget widget-textasst">
<a class="style01"  ><strong>观看历史</strong>
<script type="text/javascript ">
					$MH.limit = 10;
					$MH.WriteHistoryBox(200, 170, 'font');
				</script>

</a></div>
<div class="widget widget-textasst">
<?php echo aik_gg(4);?></div>
 </div>
<script>
var ifh=$('.sidebar');
if(ifh.height()<10){
$('.content').css("width","100%");
}else{
}</script>