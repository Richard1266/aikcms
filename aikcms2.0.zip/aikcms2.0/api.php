<?php
include('common/basic.php');
if(!isset($mode))$mode = 'api';
$mode_arr = array('api_search','api_searchall','api_searchzyz','api_video');
if(in_array('api_'.$mode,$mode_arr)){
	include('./template/'.$aik_template.'/api/'.$mode.'.php');
}else{
	show_error('Not in mode_arr');
}
?>