<?php
header("location: common/install/");