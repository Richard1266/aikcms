﻿<?php
error_reporting(0); 
/**  
 * DEMO 2.0 - 蓝讯数卡商户合作开发技术文档规范 
 *
 * Website - www.lcardy.com
 * Company - 海口环讯信息科技有限公司
 *文件列表说明。
 *|----SendTest.html(提供给商户测试用的首页)
 *|----Send.php(支付请求文件，通过此文件发起寄售请求，商家可以在此文件中写入自己的订单信息等，然后把请求提交给蓝讯数卡API接口)
 *|----merchantAttribute.php(商家属性文件，商家可以在此文件中修改商户编号和密钥信息)
 *|----callBack.php(异步通知结果回文件，通过此文件商家判断对应订单的支付状态，并且根据结果修改自己数据库中的订单状态)
 *|----callBackPage.php(同步通知结果返回文件，通过此文件商家判断对应订单的支付状态，并且根据结果修改自己数据库中的订单状态)
 */
 	 
	  include 'Common.php';
	  include 'merchantAttribute.php';
	   
 	  $mercid                 =$merc_id;
	  $merckey                =$merc_key; 
	  $businesstype           ='directpay';
      $version                ='V2.0';
	  $signtype               ='MD5';
	  $orderno				  =$_POST["orderno"];
	  $pamount				  =$_POST["pamount"];
	  $meurl				  ='http://'.$_SERVER['SERVER_NAME'].'/user/pay/callBack.php';
	  $pageurl				  ='http://'.$_SERVER['SERVER_NAME'].'/user/pay/callBackPage.php';
	  $bacode				  =$_POST["bacode"];
	  $exinf				  =$_POST["exinf"];
	  $tracur				  ='CNY';
	  $proname				  ='LcardY';
	  $cdit					  ='LcardY';
	  $deion				  ='LcardY';
	  $mercip				  ='127.0.0.1';
	  $productnum			  ='LcardY';
	  $ordertime			  ='20151102183656';
	    
	  mysql_query("INSERT INTO aikcms_user_pay (aik_pay_userid, aik_pay_num, aik_pay_mode, aik_pay_order, aik_pay_state, aik_pay_time) VALUES ('".$userid."', '".$pamount."', '".$bacode."', '".$orderno."', 0 ,".time().")");
	  	  
	  $signStr   			  ='mercid='.$mercid;
	  $signStr   			  =$signStr.'&orderno='.$orderno;
	  $signStr   			  =$signStr.'&ordertime='.$ordertime;
	  $signStr   			  =$signStr.'&pamount='.$pamount;
	  $signStr   			  =$signStr.'&meurl='.$meurl;
	  $signStr   			  =$signStr.'&pageurl='.$pageurl;
	  $signStr   			  =$signStr.'&bacode='.$bacode;
	  $signStr   			  =$signStr.'&tracur='.$tracur;
	  $signStr   			  =$signStr.'&proname='.$proname;
	  $signStr   			  =$signStr.'&mercip='.$mercip;
	  $signStr   			  =$signStr.'&businesstype='.$businesstype;
	  $signStr   			  =$signStr.'&version='.$version;
	  $signStr   			  =$signStr.'&signtype='.$signtype;
	  $signStr   			  =$signStr.'&merckey='.$merckey;
	  
	  $sign                   =md5sign($signStr);
	  
	  $htmlCodePost 		  ='<form name="lcardy" action="'.$backgroundMerUrl.'" method="POST">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="mercid" value="'.$mercid.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="orderno" value="'.$orderno.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="pamount" value="'.$pamount.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="meurl" value="'.$meurl.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="pageurl" value="'.$pageurl.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="bacode" value="'.$bacode.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="tracur" value="'.$tracur.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="proname" value="'.$proname.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="businesstype" value="'.$businesstype.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="version" value="'.$version.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="signtype" value="'.$signtype.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="exinf" value="'.$exinf.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="sign" value="'.$sign.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="ordertime" value="'.$ordertime.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="cdit" value="'.$cdit.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="deion" value="'.$deion.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="productnum" value="'.$productnum.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'<input type="hidden" name="mercip" value="'.$mercip.'">'."\r";
	  $htmlCodePost			  =$htmlCodePost.'</form>';
	  
	  $html = '<html>';
	  $html = $html.' <head id="Head1">';
	  $html = $html.'   <title></title>';
	  $html = $html.' </head>';
	  $html = $html.' <body onload="document.lcardy.submit()">';
	  $html = $html.$htmlCodePost;
	  $html = $html.' 	</body>';
	  $html = $html.'</html>';
	  echo $html;
 ?>