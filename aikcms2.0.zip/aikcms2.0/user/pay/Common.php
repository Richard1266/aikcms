<?php
/**  
 * DEMO 2.0 - 蓝讯数卡商户合作开发技术文档规范 
 *
 * Website - www.lcardy.com
 * Company - 海口环讯信息科技有限公司
 *文件列表说明。
 *|----SendTest.html(提供给商户测试用的首页)
 *|----Send.php(支付请求文件，通过此文件发起寄售请求，商家可以在此文件中写入自己的订单信息等，然后把请求提交给蓝讯数卡API接口)
 *|----merchantAttribute.php(商家属性文件，商家可以在此文件中修改商户编号和密钥信息)
 *|----callBack.php(异步通知结果回文件，通过此文件商家判断对应订单的支付状态，并且根据结果修改自己数据库中的订单状态)
 *|----callBackPage.php(同步通知结果返回文件，通过此文件商家判断对应订单的支付状态，并且根据结果修改自己数据库中的订单状态)
 */
  include('../../common/basic.php');
  $userid=$_COOKIE["userid"]; 
function md5sign($sign)
{
   $str=strtolower(md5($sign));
   return $str;
}
 
 
 
 
 
  ?>