<?php
unset($_SESSION['username']);
if (! empty ( $_COOKIE ['username'] ) )   
    {  
        setcookie ( "username", null, time () - 3600 * 24 * 365 );   
    }  
header('location:./user.php?mode=login');
?>
</body>
</html>