        <div class="col-xs-12 col-sm-2 user-nav f-16 mb15">
    <ul class="bgb border">
        <li><a href="user.php?mode=index"><i class="fa fa-home"></i> 管理首页</a></li>
        <li><a href="user.php?mode=order_list"><i class="fa fa-list"></i> 订单管理</a></li>
		<?php if($aik_pay_open<>'0'){?>
        <li><a href="user.php?mode=account"><i class="fa fa-credit-card"></i> 财务管理</a></li>
		<?php }?>
        <li><a href="user.php?mode=vip"><i class="fa fa-star"></i> VIP会员</a></li>
        <li><a href="user.php?mode=shoucang"><i class="fa fa-folder-open"></i> 我的收藏</a></li>
        <li><a href="user.php?mode=aff"><i class="fa fa-group (alias)"></i> 我的推广</a></li>
        <li><a href="user.php?mode=member_edit"><i class="fa fa-user"></i> 资料管理</a></li>
    </ul>
</div>