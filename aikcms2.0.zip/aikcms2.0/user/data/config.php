<?php
//error_reporting(0);
ini_set('date.timezone','Asia/Shanghai');
header('Content-type:text/html;charset=utf-8');
$username=$_COOKIE["username"]; 
$affid=$_COOKIE["affid"]; 
if($username==NULL)
{
	header("Location:user.php?mode=login");
	exit;
}
$result = mysql_query('select * from aikcms_user where aik_user_name = "'.$username.'"');
$row = mysql_fetch_array($result);
$aik_user_id = $row['id'];
$aik_user_img = $row['aik_user_img'];
$aik_user_on = $row['aik_user_on'];
$aik_user_allmoney = $row['aik_user_allmoney'];
$aik_user_usedmoney = $row['aik_user_usedmoney'];
$aik_user_group = $row['aik_user_group'];
$aik_user_groupend = $row['aik_user_groupend'];
$aik_user_int = $row['aik_user_int'];
$aik_user_affid = $row['aik_user_affid'];
$aik_user_alias = $row['aik_user_alias'];
$aik_user_qq = $row['aik_user_qq'];
$show_name = $aik_user_alias=="" ? $username : $aik_user_alias; 

?>