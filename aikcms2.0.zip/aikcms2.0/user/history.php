 <?php include 'data/config.php';?> 
 <!DOCTYPE html> 
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
<title>我的浏览-<?php echo $aik_name;?>-控制面板</title>
<?php include 'header.php'?> 
</head>
<body>
     <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>
 <div class="col-xs-12 col-sm-10">
<div class="bgb border mb20 clearfix">
<ul class="user-tab f-18 clearfix mb20">
    <li><a href="user.php?mode=shoucang">我的收藏</a></li>
    <li class="active"><a href="user.php?mode=history">我的浏览</a></li>
</ul>
<ul class="ul-28">
<?php
        $result = mysql_query('select * from aikcms_user_history where aik_history_userid = '.$aik_user_id.' order by id desc');
		while($row = mysql_fetch_array($result)){
						?>
<li><span class="pull-right hui"><?php echo $row['aik_history_time']?></span><a target="_blank" href="<?php echo $row['aik_history_url']?>"><i class="fa fa-caret-right hui"></i> <?php echo $row['aik_history_name']?></a></li>
 <?php }?>
 </ul>
                    </div>
                </div>


</div></div></div>
 <?php include 'foot.php'?>

</body>
</html>