 <?php include './user/data/config.php';?> 
 <!DOCTYPE html> 
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
<title>财务信息-<?php echo $aik_name;?>-控制面板</title>
<?php include 'header.php'?>    
</head>
<body>
     <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>


<div class="col-xs-12 col-sm-10">
<div class="bgb border mb20 clearfix">
<ul class="user-tab f-18 clearfix">
    <li class="active"><a href="user.php?mode=account">财务信息</a></li>
    <li><a href="user.php?mode=charge">充值记录</a></li>
    <li><a href="user.php?mode=chargecard_new">我要充值</a></li>
</ul>
<div class="pd20">
    <table class="tx-table text-center mb20">
           <tr class="bgh">
               <td width="33.33%">入账总额</td>
               <td width="33.33%">已消费</td>
               <td width="33.33%">可用金额</td>
           </tr>
           <tr>
<?php
        $result = mysql_query('select * from aikcms_user where id = '.$aik_user_id.'');
		if($row = mysql_fetch_array($result)){
						?>
               <td><?php echo $row['aik_user_allmoney']?>元</td>
               <td><?php echo $row['aik_user_usedmoney']?>元</td>
               <td style="color:red;font-weight:bold"><?php echo $row['aik_user_allmoney']-$row['aik_user_usedmoney']?>元</td>
 <?php }?>
           </tr>
       </table>
       
       <p class="img-d"><?php echo aik_gg(5);?></p>
</div>
</div>
</div> 
</div></div></div>
 <?php include 'foot.php'?>

</body>
</html><!--39.27 ms , 7 query , 3958kb memory , 0 error-->