<?php 
include './user/data/config.php';
setcookie('userid',$aik_user_id);
if(($aik_user_group<>"0")&&(time()>$aik_user_groupend)){
	mysql_query('update `aikcms_user`  set  aik_user_group="0" , aik_user_groupend="0" where aik_user_name = '.$username.'');	
	alert_href('会员已到期!','user.php?mode=index');
	}
?> 
 <!DOCTYPE html> 
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
<title>管理首页-<?php echo $aik_name;?>-控制面板</title>
<?php include 'header.php'?> 
</head>
<body>
     <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>
<div class="col-xs-12 col-sm-10">
<div class="bgb border pd15-t mb20 clearfix">
<div class="clearfix mb20">
<div style="height:50px; width:50px; border-radius:50%; overflow:hidden; margin-right:20px;border: 1px solid #e6e6e6;float:left; ">  
<img src=<?php echo $aik_user_img;?>  style="height:100%; width:100%;border:0; line-height:100px;text-align:center;">
</div>				
        <h2 class="f-18 mb10">欢迎你：<?php echo $show_name;?><?php echo aik_user_usergroupimg($username)?><font style="float:right;"><a target="_blank" href="./user.php?mode=exit">>>退出登录</a></font></h2>
        <p class="hui">到期时间：<?php echo $a = $aik_user_groupend=="0" ? "永久" : date("Y-m-d H:i:s",$aik_user_groupend); ?></p>	
</div>

<ul class="user-home-ul row">
<li class="col-xs-6 col-sm-3 mb15"><a href="user.php?mode=vip"><?php echo aik_user_usergroup($username)?></a><i>等级</i></li>
    <li class="col-xs-6 col-sm-3 mb15"><a href="user.php?mode=account"><?php echo ($aik_user_allmoney-$aik_user_usedmoney)?>元</a><i>余额</i></li>
    <li class="col-xs-6 col-sm-3 mb15"><a href="user.php?mode=int"><?php echo $aik_user_int;?></a><i>积分</i></li>
    <li class="col-xs-6 col-sm-3 mb15"><a href="user.php?mode=order_list">
	<?php 
	$result = mysql_query('SELECT * from aikcms_user_order where  aik_order_userid = '.$aik_user_id.' ');//你的查询
	$count = mysql_num_rows($result);
    echo $count;
	?>
	</a><i>订单</i></li>
    
</ul>
</div>
    
    
 <div class="row">
      <div class="col-xs-12 col-sm-6 mb20">
       <div class="border bgb">
           <h2 class="border-b f-18 pd15-2 lh-38 bgh">最新公告</h2>
           <ul class="ul-28">
		   <?php
						$result = mysql_query('select * from aikcms_notice order by id desc limit 8');
						while($row = mysql_fetch_array($result)){
						?>					
                <li><span class="hui fr"><?php echo date("Y-m-d",$row['aik_notice_time']);?></span><a target="_blank" href="<?php echo $row['aik_notice_url'];?>"> <i class="fa fa-caret-right hui"></i><?php echo $row['aik_notice_title'];?></a></li>
				<?php }?>
				</ul>
       </div>
   </div>
      <div class="col-xs-12 col-sm-6 mb20">
       <div class="border bgb">
           <h2 class="border-b f-18 pd15-2 lh-38 bgh">最新视频</h2>
           <ul class="ul-28">
		   		   <?php
						$result = mysql_query('select * from aikcms_video order by id desc limit 8');
						while($row = mysql_fetch_array($result)){
						?>					
                <li><span class="hui fr"><?php echo date("Y-m-d",$row['aik_video_time']);?></span><a target="_blank" href="<?php echo $link = $aik_weijing==1 ? 
'./vod/'.$row['id'].'.html':'./index.php?mode=play&vid='.$row['id'];
?>"> <i class="fa fa-caret-right hui"></i><?php echo $row['aik_video_name'];?></a></li>
				<?php }?>				
				</ul>
       </div>
       
   </div>

 </div>
     <p class="img-d"><?php echo aik_gg(5);?></p>  
</div> 

</div></div></div>

 <?php include 'foot.php'?>

</body>
</html><!--43.97 ms , 10 query , 4122kb memory , 0 error-->