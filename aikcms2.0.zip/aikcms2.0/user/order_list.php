 <?php include './user/data/config.php';?> 
 <!DOCTYPE html> 
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
<title>订单管理-<?php echo $aik_name;?>-控制面板</title>
<?php
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_user_order where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_href('删除成功!','user.php?mode=order_list');
	} else {
		alert_back('删除失败！');
	}
}
?>
<?php include 'header.php'?> 
</head>
<body>
    <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>
<div class="col-xs-12 col-sm-10">
<div class="bgb border mb20 clearfix">
<h1 class="border-b f-18 pd15-2 lh-38 bgh">已购商品</h1>
<div class="pd20-t">
<div class="order-search">
    <form method="post">
                          <div class="form-group input-group">
                                <input type="text" class="form-control" name="search" placeholder="可输入订单名称搜索">
                                <span class="input-group-btn"><button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button></span>
                            </div>
                        </form>
</div>
 <table class="tx-table">
                                <thead>

    <tr>
                    <th width="20%">订单号</th>
                    <th width="30%">商品名称</th>
                    <th width="10%">价格</th>
                    <th>时间</th>
                    <th>操作</th>
                  </tr>
                                </thead>
                                <tbody>
								<?php
		$sql = 'select * from aikcms_user_order where  aik_order_userid = '.$aik_user_id.'  order by id desc';
		$pager = page_handle('page',10,mysql_num_rows(mysql_query($sql)));
		$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
		if (isset($_POST['search'])) {
		$sql = 'select * from aikcms_user_order where aik_order_name LIKE "%'.$_POST['search'].'%" order by id desc';
		$pager = page_handle('page',10,mysql_num_rows(mysql_query($sql)));
		$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
							}
		while($row = mysql_fetch_array($result)){
					?>	
                                    <form  method="post"><tr>
                                        <td><?php echo $row['aik_order'];?></td>
                                        <td><?php echo $a = $row['aik_order_videourl']<>'' ? '<a href="'.$row['aik_order_videourl'].'" target="_blank">':'';?><?php echo $row['aik_order_name'];?></a></td>
                                        <td><?php echo $row['aik_order_price'];?></td>
                                        <td><?php echo date("Y-m-d H:i:s",$row['aik_order_time']);?></td>
										
                                        <td><a title="点击删除订单" class="button"  alt="点击删除订单" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];?>&del=<?php echo $row['id']?>"  type="submit"><img src="./user/static/images/delete.png"/></a></td>
                                    </tr></form>
					<?php }?>
</tbody>
</table>
<nav>
  <ul class="pagination">
 <?php echo page_show1($pager[2],$pager[3],$pager[4],2);?> </ul>
</nav>

</div>
</div>
</div>
</div></div></div>
 <?php include 'foot.php'?>


</body>
</html><!--39.36 ms , 9 query , 4053kb memory , 0 error-->