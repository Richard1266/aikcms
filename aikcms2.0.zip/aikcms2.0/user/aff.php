 <?php include './user/data/config.php';?> 
 <!DOCTYPE html> 
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
 <title>我的推广-<?php echo $aik_name;?>-控制面板</title>
<?php include 'header.php'?>   
</head>
<body>
    <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>
<div class="col-xs-12 col-sm-10">
<div class="bgb border mb20 clearfix">
<h1 class="border-b f-18 pd15-2 lh-38 bgh">我的推广</h1>
<div class="pd20">
<table class="tx-table mb20">
                            <tbody>
                            <tr><th>
                            <label for="disabledSelect">您的永久推广链接为：</label></th></tr>
                            <tr><td>
                            <input type="text" readonly="" id="disabledInput" class="form-control"  value="<?php echo 'http://'.$_SERVER['HTTP_HOST'].'/index.php?aff='.$aik_user_id.''?>" ></td></tr>
</tbody>
</table>

                            <table class="tx-table">
                                     <thead>
                                       <tr><th>用户ID</th>
                                         <th>注册时间</th>
                                         <th>消费金额</th>
                                         <th>推广提成</th>
                                       </tr>
                                     </thead>


     <tbody>
<?php
        $sql = 'select * from aikcms_user where aik_user_affid = "'.$aik_user_id.'" order by id desc';
		$pager = page_handle('page',10,mysql_num_rows(mysql_query($sql)));
		$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
		while($row = mysql_fetch_array($result)){
						?>
<tr>
<td rowspan="1"><?php echo $row['id']?></td>
 <td><?php echo date("Y-m-d H:i:s",$row['aik_user_time']);?></td>
 <td rowspan="1"><?php echo $row['aik_user_usedmoney']?>元</td>
 <td rowspan="1">积分:<?php echo $aik_user_affint;?>  / RMB:<?php echo ($row['aik_user_usedmoney']*0.05)?>元</td>
 </tr>
 <?php }?>
</tbody>
</table>
<nav>
   <ul class="pagination">
 <?php echo page_show1($pager[2],$pager[3],$pager[4],2);?> </ul>
</nav>
<table class="tx-table table-bordered table-hover table-striped">
  <tr>
  <td>备注</td>
    <td>1、邀请注册的cookie有效期为三天，即：从用户访问邀请链接后三天内注册的帐号能成为您的有效推广用户。<br />
    2、受邀注册的用户如和您在同一网段内，邀请注册链接无效。<br />
    3、受邀注册的用户成功消费后，您将获得5%的销售提成。<br />
    </td>
  </tr>
</table>

                        </div>
                    </div>
                </div>
  <!-- /content -->
</div></div></div>
 <?php include 'foot.php'?>

</body>
</html><!--43.22 ms , 9 query , 4044kb memory , 0 error-->