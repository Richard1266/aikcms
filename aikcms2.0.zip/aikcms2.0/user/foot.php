
    <div class="footer pd15-1 f-12 bc-hui border-t">
        <div class="container">
            <ul class="row">
                <li class="col-xs-12 col-sm-10 phone-center">
                    <p>Powered By AikCms， Theme By <a href="http://www.xiaoerhu.com/" target="_blank" rel="nofollow">小儿胡工作室</a>，Copyright © 2019-2029，<a href="http://www.miibeian.gov.cn/" target="_blank" rel="nofollow"> <?php echo $aik_icp;?></a></p>
                </li>
                <li class="col-xs-12 col-sm-2 text-right phone-center">
                    <?php echo $aik_tongji;?>
                </li>
            </ul>
        </div>
    </div>
    <div id="tbox"> <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $aik_admin_qq;?>&site=qq&menu=yes" target="_blank" rel="nofollow" class="phone-none"><i class="fa fa-qq"></i> <em>在线QQ</em></a>
        <div id="gotop"><i class="fa fa-angle-up"></i></div>
    </div>
<script type="text/javascript">$(".menu-search").on("click", function(e){
    if($(".search-main").is(":hidden")){
        $(".search-main").slideDown();
        $(".menu-search i").addClass("fa-close (alias)");
    }else{
        $(".search-main").slideUp();
        $(".menu-search i").removeClass("fa-close (alias)");
    }

    $(document).one("click", function(){
        $(".search-main").slideUp();
        $(".menu-search i").removeClass("fa-close (alias)");
    });

    e.stopPropagation();
});
$(".search-main").on("click", function(e){
    e.stopPropagation();
});


$(".foot-weixin").hover(function(){
    $(".foot-weixin>div").toggle();
});
$(".foot-qqun").hover(function(){
    $(".foot-qqun>div").toggle();
});</script>
<script src="static/js/bootstrap.js"></script>


