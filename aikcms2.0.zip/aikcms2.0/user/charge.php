 <?php include './user/data/config.php';?> 
 <!DOCTYPE html> 
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
<title>充值记录-<?php echo $aik_name;?>-控制面板</title>
<?php include 'header.php'?> 
</head>
<?php
if (isset($_GET['del'])) {
	$sql = 'delete from aikcms_user_pay where id = ' . $_GET['del'] . '';
	if (mysql_query($sql)) {
		alert_back('删除成功!');
	} else {
		alert_back('删除失败！');
	}
}
?>
<body>
     <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>
<div class="col-xs-12 col-sm-10">
<div class="bgb border mb20 clearfix">
<ul class="user-tab f-18 clearfix">
    <li><a href="user.php?mode=account">财务信息</a></li>
    <li class="active"><a href="user.php?mode=charge">充值记录</a></li>
    <li><a href="user.php?mode=chargecard_new">我要充值</a></li>
</ul>
<span class="place pull-right f-12" style="display:none"><a href="/user/account.php">财务信息</a> - 充值管理</span>
<div class="pd20">
<table class="tx-table">
                                <thead>

    <tr>
                    <th width="25%">订单号</th>
                    <th width="15%">充值金额</th>
                    <th width="15%">交易状态</th>
                    <th width="15%">付款方式</th>
                    <th width="20%">创建时间</th>
                    <th width="10%">操作</th>
                  </tr>
                                </thead>
                                <tbody>

<?php
        $sql = 'select * from aikcms_user_pay where aik_pay_userid = "'.$aik_user_id.'" order by id desc';
		$pager = page_handle('page',20,mysql_num_rows(mysql_query($sql)));
		$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
		while($row = mysql_fetch_array($result)){
						?>
<tr>
<td rowspan="1"><?php echo $row['aik_pay_order']?></td>
 <td><?php echo $row['aik_pay_num']?></td>
 <td rowspan="1"><?php echo $row['aik_pay_state'] = $row['aik_pay_state']=="0" ? '<font color="red">未付款</font>' : '<font color="green">已付款</font>'; ?></td>
 <td rowspan="1"><?php if($row['aik_pay_mode']=='ALIPAY'){echo '支付宝';}elseif($row['aik_pay_mode']=='WEIXINPAY'){echo '微信';}else{echo 'QQ钱包';}?></td>
 <td rowspan="1"><?php echo $row['aik_pay_time']?></td>
 <td rowspan="1">
<a title="点击删除订单" class="button"  alt="点击删除订单" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];?>&del=<?php echo $row['id']?>"  type="submit"><img src="./user/static/images/delete.png"/></a>	</td>
 </tr>
 <?php }?>

</tbody>
</table>
<nav>
  <ul class="pagination">
 <?php echo page_show1($pager[2],$pager[3],$pager[4],2);?> </ul>
</nav>
 <p class="img-d"><?php echo aik_gg(5);?></p>
                        </div>
                    </div>
                </div>

</div></div></div>
 <?php include 'foot.php'?>

</body>
</html>