 <?php 
include './user/data/config.php';
if (isset($_POST['edit'])) {
	if ($_POST['Password'] != $_POST['Password']) {
	alert_back('两次输入的密码不一致');
	}
	if(!empty($_POST['Password'])){$_data['aik_user_pw'] = md5($_POST['Password']);}
	 $t=time();
	$filename = $username.$t.'.gif';
	$_data['aik_user_alias'] = $_POST['Alias'];
	$_data['aik_user_qq'] = $_POST['QQ'];
	if(move_uploaded_file($_FILES['aik_user_img']['tmp_name'],'upload/'.$filename)){  
	$_data['aik_user_img']='/upload/'.$filename;}		
	$sql = 'update aikcms_user  set ' . arrtoupdate($_data) . ' where aik_user_name = ' . $username . '';
	if (mysql_query($sql)) {
	alert_back('用户资料修改成功!');	
	} else { 
	alert_back('用户资料修改失败!');
	}
}
 ?> 
 <!DOCTYPE html> 
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
<title>资料管理-<?php echo $aik_name;?>-控制面板</title>
<?php include 'header.php'?> 
<style>
    .div_img {
        position: relative;
		margin-left:100px;;
    }
    .div_imgup {
        width: 100px;
        height: 36px;
        background: #2178fc;
        color: #fff;
        text-align: center;
        line-height: 36px;
    }

    .file_input {
        width: 200px;/*因为file-input在部分浏览器中会自带一个输入框，需要双击才可以点击上传,放大后将其定位到div外面就好啦*/
        height: 36px;
        position: absolute;
        left: -100px;
        top: 0;
        z-index:1;
        -moz-opacity: 0;
        -ms-opacity: 0;
        -webkit-opacity: 0;
        opacity: 0;  /*css属性——opcity不透明度，取值0-1*/
        filter: alpha(opacity=0); /*兼容IE8及以下--filter属性是IE特有的，它还有很多其它滤镜效果，而filter: alpha(opacity=0); 兼容IE8及以下的IE浏览器(如果你的电脑IE是8以下的版本，使用某些效果是可能会有一个允许ActiveX的提示,注意点一下就ok啦)*/
        cursor: pointer;
    }
</style>
</head>
<body>
     <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>
<div class="col-xs-12 col-sm-10">
<div class="bgb border mb20 clearfix">
<h1 class="border-b f-18 pd15-2 lh-38 bgh">个人资料管理</h1>
<div class="pd20">
        <form method="post"  enctype="multipart/form-data">
			       <div class="div_img">
						<div class="div_imgup"><input type="file" name="aik_user_img" accept="image/*" class="file_input"  onchange="changImg(event)">上传图片</div>
					</div>
					<div style="height:80px; width:80px; border-radius:50%; overflow:hidden;border: 1px solid #e6e6e6;margin:-50px 0 10px 0;">  
						<img  id="myImg" alt="暂无图片" src="<?php echo $aik_user_img;?>"  style="height:100%; width:100%;border:0; line-height:80px;text-align:center;">
					</div>
					
		<div class="tx-xian">
				<input  class="tx-input"  size="40" name="Name" maxlength="20" type="text" value="<?php echo $username;?>" readonly="readonly" />
				<label class="tx-label">用户名<strong class="f-red">*</strong></label>
    </div>
		<div class="tx-xian">
		        <input type="hidden" name="Password"  value="<?php echo $row['aik_pw']?>"> 
				<input  class="tx-input" size="40" name="Password"  type="password" value=""/>
				<label class="tx-label">密码</label>
</div>
		<div class="tx-xian">
				<input  class="tx-input"  size="40" name="Password"  type="password" value=""  placeholder=""/>
				<label class="tx-label">确认密码</label>
</div>
			<div class="tx-xian">
				<input  class="tx-input"  size="40" name="Alias" type="text" value="<?php echo $a = $aik_user_alias=="" ? $username : $aik_user_alias; ?>"/>
				<label class="tx-label">别名<strong class="f-red">*</strong></label>
		</div>
			<div class="tx-xian">
			    <input  class="tx-input"  size="40" name="QQ" type="text" value="<?php echo $aik_user_qq;?>" />
				<label class="tx-label">QQ<strong class="f-red">*</strong></label>
				</div>

		<div class="form-group">
                            <button type="submit" class="btn btn-primary"  name="edit" >提交</button>
                            </div>
</form>


                    </div>
                </div>
                <!-- /.row -->


</div>



  <!-- /content -->
</div></div></div>
 <?php include 'foot.php'?>
<script type="text/javascript">  
     function changImg(e){  
        for (var i = 0; i < e.target.files.length; i++) {  
            var file = e.target.files.item(i);  
            if (!(/^image\/.*$/i.test(file.type))) {  
                continue; //不是图片 就跳出这一次循环  
            }  
            //实例化FileReader API  
            var freader = new FileReader();  
            freader.readAsDataURL(file);  
            freader.onload = function(e) {  
                $("#myImg").attr("src",e.target.result);  
            }  
        }  
    }  
</script> 
</body>
</html><!--37.29 ms , 5 query , 3979kb memory , 0 error-->