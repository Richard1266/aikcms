<link rel="stylesheet" rev="stylesheet" href="./user/static/css/bootstrap.min.css" media="all" />
<link rel="stylesheet" rev="stylesheet" href="./user/static/css/txcstx.css" type="text/css" media="all" />
<link rel="stylesheet" rev="stylesheet" href="./user/static/css/font-awesome.min.css" media="all" />
<link rel="stylesheet" rev="stylesheet" href="./user/static/css/txcstx_1.css" media="all" />
    <script src="./user/static/js/jquery.js"></script>
    <script src="./user/static/js/zbp_add.js"></script>
    <!-- ZCenter js-->
    <!-- zbp system -->
    <script src="./user/static/js/zblogphp.js" type="text/javascript"></script>
    <script src="./user/static/js/c_admin_js_add.js" type="text/javascript"></script>
<!--
    <script src="static/js/jquery-ui.custom.min.js" type="text/javascript"></script>
    <link rel="stylesheet" type="text/css" href="static/css/jquery-ui.custom.css"/>
-->
    <script src="./user/static/js/functions.js"></script>
    <script src="./user/static/js/nav.js"></script>
	


