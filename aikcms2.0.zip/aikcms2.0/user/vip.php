<?php
include './user/data/config.php';
if (isset($_POST['buy'])) {
	$price = $_POST['price'];
	$length = $_POST['length'];
	$groupid = $_POST['groupid'];
	$order = $_POST['order'];
	$money=$aik_user_allmoney ;
	if($money<$price){alert_href('金额不足，请充值！','user.php?mode=chargecard_new');}else{
	$usedmoney = $price+$aik_user_usedmoney;
	$time = $aik_user_groupend>time() ? $aik_user_groupend+$length*86400 :time()+$length*86400;
	$timeend = $length=="9999" ? "0" : $time;
	$result =mysql_query('update `aikcms_user`  set aik_user_usedmoney='.$usedmoney.' , aik_user_group='.$groupid.' , aik_user_groupend='.$timeend.' where id = '.$aik_user_id.'');	
	if($result){ 
	mysql_query('insert into `aikcms_user_order` (aik_order ,aik_order_name,aik_order_price,aik_order_userid,aik_order_time) values ('.$order.',"'.$_POST['name'].'","'.$price.'元",'.$aik_user_id.','.time().')');	
	if(!empty($aik_user_affid)){$affaddm= get_user_allmoney($aik_user_affid)+$price;
	   mysql_query('UPDATE `aikcms_user` SET `aik_user_allmoney`='.$affaddm.'  WHERE id='.$aik_user_affid.'');}
	alert_href('支付成功!','user.php?mode=index');}else{alert_href('支付失败，请重新支付!','user.php?mode=vip');}
	}
}
if (isset($_POST['recharge'])) {
	$card=$_POST['charge_code'];
	$result=mysql_query('SELECT * FROM `aikcms_card` where aik_card="'.$card.'" and aik_card_group<>"" and aik_card_user=""');//判断卡密
	$row=mysql_fetch_array($result);
	if($row){//卡密存在&&未用
	  $length=aik_user_usergrouplength($row['aik_card_group']);
	  $time = $aik_user_groupend>time() ? $aik_user_groupend+$length*86400 :time()+$length*86400; 	
	  $resultt =mysql_query('update `aikcms_user` set aik_user_group='.$row['aik_card_group'].' , aik_user_groupend='.$time.' where id = '.$aik_user_id.'');	
	  if($resultt){
		  mysql_query('UPDATE `aikcms_card` SET `aik_card_user`='.$username.' ,`aik_card_utime`='.time().'  WHERE aik_card="'.$card.'"');//判断卡密
		  alert_href('充值成功!','user.php?mode=index');}else{alert_href('充值失败，请重新充值!','user.php?mode=vip');}
	}else{alert_back('卡密已使用或使用类型错误!');}
}
?> 
 <!DOCTYPE html>  
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
<title>开通VIP-<?php echo $aik_name;?>-控制面板</title>
<?php include 'header.php'?> 
</head>
<body>
     <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>
<div class="col-xs-12 col-sm-10">
<div class="bgb border mb20 clearfix">
<ul class="user-tab f-18 clearfix">
    <li class="active"><a href="user.php?mode=vip">加入VIP</a></li>
    <li><a href="user.php?mode=int">积分充值</a></li>
</ul>
<div class="pd20">
<?php if($aik_pay_open<>'0'){?>
    <table class="tx-table mb20">
                            <colgroup>
						<col width="150">
						<col>
						<col>
						<col width="150">
					</colgroup>
					<thead>
						<tr>
						    <th>用户组</th>
                            <th>价格</th>
                            <th>时长</th>
                            <th>购买链接</th>
						</tr>
					</thead>	
                                <tbody>
<?php
                    $result = mysql_query('select * from aikcms_usergroup   order by id desc');
					while($row = mysql_fetch_array($result)){
					?>	
                                    <form  method="post"><tr>
                                        <td><?php echo $row['aik_usergroup_name'];?></td>
                                        <td style="color:green;font-weight:bold;" ><?php echo $row['aik_usergroup_price'];?></td>
										<input type="hidden"  name="order"  value='<?php echo date("YmdHis",time()).str_rand();?>'>
										<input type="hidden"  name="name"  value='<?php echo $row['aik_usergroup_name'];?>'>
										<input type="hidden"  name="price" value='<?php echo $row['aik_usergroup_price'];?>'>
										<input type="hidden"  name="length"  value='<?php echo $row['aik_usergroup_length'];?>'>
										<input type="hidden"  name="groupid"  value='<?php echo $row['id'];?>'>
                                        <td><?php echo $a = $row['aik_usergroup_length']=="9999" ? "永久" : $row['aik_usergroup_length']."天"; ?></td>
                                        <td> <input type="submit" class="btn btn-primary" name="buy" onclick="return confirm('确定加入本站VIP么？')" value="立即购买" /></td>
                                    </tr></form>
					<?php }?>
                                </tbody>
       </table>
<?php }?>      
<div class="mb20 border">
    <h2 class="bc-hui lh-38 f-18 border-b title-i"><i class="fa fa-yen (alias)"></i> 充值卡充值 <span class="f-12"><a href="<?php echo $aik_buycard;?>"  target="_blank">>>点击购买卡密<<</a></span></h2>
    <dl class="pd20">
 <form method="post" class="tx-form2">
<input class="tx-input2"   name="charge_code"  placeholder="请输入充值卡卡号点击充值按钮即可充值">
<button  class="tx-btn2"  name="recharge">充值</button>
</form>
</dl>
</div>   
       <p class="img-d"><?php echo aik_gg(5);?></p>
</div>
</div>
</div>
  <!-- /content -->
</div></div></div>
 <?php include 'foot.php'?>

</body>
</html><!--38.36 ms , 7 query , 3967kb memory , 0 error-->