<?php 
include './user/data/config.php';
if (isset($_POST['buy'])) {
 $intnum=$_POST['intnum'];
 $order = $_POST['order'];
 $newint=$aik_user_int+$intnum;
 $needmoney=$intnum/$aik_user_intra;
 $money=$aik_user_allmoney-$aik_user_usedmoney;
 $newmoney=$aik_user_usedmoney+$needmoney;
if($money<$needmoney){ alert_href('余额不足，请先充值!', 'user.php?mode=chargecard_new');}else{
	$sql='UPDATE `aikcms_user` SET `aik_user_int`='.$newint.', `aik_user_usedmoney`='.$newmoney.'  WHERE aik_user_name='.$username.'';
    if (mysql_query($sql)) {
	mysql_query('insert into aikcms_user_order (aik_order ,aik_order_name,aik_order_price,aik_order_userid,aik_order_time) values ('.$order.',"积分充值【'.$intnum.'】","'. $needmoney.'元",'.$aik_user_id.','.time().')');		
   if(!empty($aik_user_affid)){$affaddm= get_user_allmoney($aik_user_affid)+$needmoney;
	   mysql_query('UPDATE `aikcms_user` SET `aik_user_allmoney`='.$affaddm.'  WHERE id='.$aik_user_affid.'');}
    alert_href('恭喜充值成功!', 'user.php?mode=index');
	} else {
	    alert_back('充值失败!');
	}	
	
}
}
if (isset($_POST['recharge'])) {
	$card=$_POST['charge_code'];
	$result=mysql_query('SELECT * FROM `aikcms_card` where aik_card="'.$card.'" and aik_card_int<>"" and aik_card_user=""');//判断卡密
	$row=mysql_fetch_array($result);
	if($row){//卡密存在&&未用
	  $newint=$aik_user_int+$row['aik_card_int'];
	  $resultt =mysql_query('update `aikcms_user` set aik_user_int='.$newint.'  where id = '.$aik_user_id.'');	
	  if($resultt){
		  mysql_query('UPDATE `aikcms_card` SET `aik_card_user`='.$username.' ,`aik_card_utime`='.time().'  WHERE aik_card="'.$card.'"');//判断卡密
		  alert_href('充值成功!','user.php?mode=int');}else{alert_href('充值失败，请重新充值!','user.php?mode=int');}
	}else{alert_back('卡密已使用或使用类型错误!');}
}
?> 
 <!DOCTYPE html> 
 <html> 
 <head> 
 <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"> 
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
 <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
 <meta name="renderer" content="webkit">
<title>我要充值-<?php echo $aik_name;?>-控制面板</title>		
<?php include 'header.php'?>    
</head>
<body>
     <?php include 'head.php'?> 
<div class="pd20-1 bgh-1">
<div class="user-mian container">
    <div class="row">
   <?php include 'leftlist.php'?>
<div class="col-xs-12 col-sm-10">
<div class="bgb border mb20 clearfix">
<ul class="user-tab f-18 clearfix">
    <li><a href="user.php?mode=vip">加入VIP</a></li>
    <li class="active"><a href="user.php?mode=int">积分充值</a></li>
</ul>

<div class="pd20">
<div class="clearfix mb20">
        <h2 class="f-18 mb10">现有积分：<font style="color:red;font-weight:bold"><?php echo $aik_user_int;?></font></h2>	
</div>
<?php if($aik_pay_open<>'0'){?>
<div class="mb20 border">
    <h2 class="bc-hui lh-38 f-18 border-b title-i"><i class="fa fa-yen (alias)"></i> 在线充值 <span class="f-12">(请确保余额充足)</span></h2>
<dl class="pd20">
<form method="post">							
<input type="hidden"  name="order"  value='<?php echo date("YmdHis",time()).str_rand();?>'>
<div class="tx-form2">
<input class="tx-input2"   name="intnum"  placeholder="请输入一个整数后点击按钮即可进行充值">
<button  class="tx-btn2"  name="buy" onclick="return confirm('1RMB=<?php echo $aik_user_intra?>积分，兑换前请确保余额充足！')" >充值</button></div>
</form>
</dl>
</div>     
<?php }?>
<div class="mb20 border">
    <h2 class="bc-hui lh-38 f-18 border-b title-i"><i class="fa fa-yen (alias)"></i> 充值卡充值 <span class="f-12"><a href="<?php echo $aik_buycard;?>"  target="_blank">>>点击购买卡密<<</a></span></h2>
    <dl class="pd20">
 <form method="post" class="tx-form2">
<input class="tx-input2"   name="charge_code"  placeholder="请输入充值卡卡号点击充值按钮即可充值">
<button  class="tx-btn2"  name="recharge">充值</button>
</form>
</dl>
</div> 

 
 
</div>  
 </div>
     <p class="img-d"><?php echo aik_gg(5);?></p>  
</div> 
</div></div></div>
 <?php include 'foot.php'?>

</body>
</html><!--38.52 ms , 7 query , 3957kb memory , 0 error-->