 <div class="header clearfix">
        <div class="container">
            <h1 class="logo img-d"><a href="/"><img src="<?php echo $aik_biglogo;?>" style="width:80%" alt="<?php echo $aik_name;?>"/></a></h1>
            <div class="txnav">
                <nav class="navbar navbar-default" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> <span class="sr-only">切换导航</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                    </div>
                    <div class="collapse navbar-collapse" id="example-navbar-collapse">
                        <ul class="nav navbar-nav">
							<li><a href="./"><i class="fa fa-home"></i> 首页</a></li>
                            <li><a href="./index.php?mode=list&fl=dianying">电影</a></li>
                            <li><a href="./index.php?mode=list&fl=dianshi">电视剧</a></li>
                            <li><a href="./index.php?mode=list&fl=zongyi">综艺</a></li>
                            <li><a href="./index.php?mode=list&fl=dongman">动漫</a></li>
                            <li><a href="./index.php?mode=cxlist&fl=cx">最近更新</a></li>
							
							<?php
						$result = mysql_query('select * from aikcms_nav where aik_nav_papa="0" order by aik_nav_id desc');
						while($row = mysql_fetch_array($result)){
						?>
<li><a href="<?php echo $a = aik_nav_baby($row['id']) > "0" ? "javascript:void()":$row['aik_nav_url']?>"><font color="<?php echo $row['aik_nav_color'];?>"><?php echo $row['aik_nav_name'];?></font></a>
<?php if(aik_nav_baby($row['id']) > "0"){
   echo '<ul>';
   $resultt = mysql_query('select * from aikcms_nav where aik_nav_papa='.$row['id'].' order by aik_nav_id desc');
   while($roww = mysql_fetch_array($resultt)){
    echo '<li id="category"><a href="'.$roww['aik_nav_url'].'" target="_blank">'.$roww['aik_nav_name'].'</a></li>';
	}echo '</ul></li>';
}?>
						<?php }?>

                        </ul>
                    </div>
                </nav>
            </div>
            <div class="search"><a href="javascript:;" class="menu-search"><i class="fa fa-search"></i></a></div>
        </div>
        <div class="search-main" style="display:none;">
            <form name="search" method="post" action="/index.php" target="_blank" class="clearfix">
			<input type="hidden" name="mode" value="search">
                <input type="text" name="wd" size="11" id="search-keyword" value="输入影片关键字" onfocus="if (value =='输入影片关键字'){value =''}" onblur="if (value ==''){value='输入影片关键字'}" />
                <button class="search-submit" id="btnPost" type="submit"><i class="fa fa-search"></i></button>
            </form>
          
        </div>
    </div>