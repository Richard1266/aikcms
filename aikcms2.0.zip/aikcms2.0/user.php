<?php
include('common/basic.php');
if ($aik_user_open=="0"){alert_back('本站未开启用户注册功能！');}
if(!isset($mode))$mode = 'index';
$mode_arr = array('md_index','md_login','md_reg','md_exit','md_forget','md_order_list','md_account','md_vip','md_int','md_charge','md_chargecard_new','md_shoucang','md_history','md_aff','md_member_edit','md_qqlogin');
if(in_array('md_'.$mode,$mode_arr)){
	include('./user/'.$mode.'.php');
}else{
	show_error('Not in mode_arr');
}

?>