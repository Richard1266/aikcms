﻿<?php
    include 'data/config.php';
    include 'email.class.php';
    $smtpserver = $aik_email_server; //SMTP服务器
    $smtpserverport = $aik_email_port; //SMTP服务器端口
    $smtpusermail = $aik_email_add; //SMTP服务器的用户邮箱
    $smtpuser = $aik_email_user; //SMTP服务器的用户帐号
    $smtppass = $aik_email_pw; //SMTP服务器的授权密码
    $smtp = new Smtp($smtpserver, $smtpserverport, true, $smtpuser, $smtppass); //这里面的一个true是表示使用身份验证,否则不使用身份验证.
    $emailtype = "HTML"; //信件类型，文本:text；网页：HTML
    $smtpemailto = $email;
    $smtpemailfrom = $smtpusermail;
    $emailsubject = $title;
    $emailbody = $content;
    //开始发送邮件
    $state = $smtp->sendmail($smtpemailto, $smtpemailfrom, $emailsubject, $emailbody, $emailtype);
	if($state=="") {
echo "<script>alert('发送失败');location.href='email.php'</script>";
}else {
echo "<script>alert('发送成功');location.href='email.php'</script>";
}
?>