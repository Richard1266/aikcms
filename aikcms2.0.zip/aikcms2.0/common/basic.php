<?php
error_reporting(0);
//session_start();
define('AIKCMS',TRUE); 
ini_set('date.timezone','Asia/Shanghai'); 
header('Content-type:text/html; charset=utf-8');
include('config/config.php');
include('inc/init.php');
include('inc/rule.php');
$template = $aik_onlym == 1 && isMobile()==1 ? $aik_mtemplate:$aik_template;
?>