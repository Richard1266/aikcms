-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2019 年 03 月 07 日 13:57
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `aikcms`
--

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_ad`
--

CREATE TABLE IF NOT EXISTS `aikcms_ad` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aik_ad_remarks` varchar(255) NOT NULL,
  `aik_ad_seat` varchar(255) NOT NULL,
  `aik_ad_code` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `aikcms_ad`
--

INSERT INTO `aikcms_ad` (`id`, `aik_ad_remarks`, `aik_ad_seat`, `aik_ad_code`) VALUES
(1, '大淘客', '播放器上', '&lt;a href=&quot;http://tao.uuhuo.cn&quot; target=&quot;_blank&quot;&gt;&lt;img src=&quot;https://s2.ax1x.com/2019/02/16/krHHk6.png&quot; style=&quot;width:100%;&quot;&gt;&lt;/a&gt;'),
(2, '点击绿条', '播放器下', '&lt;style&gt; \r\n .black_overlay{  display: none;  position: absolute;  top: 0%;  left: 0%;  width: 100%;  height: 100%;  background-color: black;  z-index:1001;  -moz-opacity: 0.8;  opacity:.80;  filter: alpha(opacity=80);  }  .white_content {  display: none;  position: absolute;  top: 25%;  left: 25%;  width: 50%;   height: auto; padding: 16px;  border: 16px solid orange;  background-color: white;  z-index:1002;  overflow: auto;  }  &lt;/style&gt; \r\n&lt;a href=&quot;javascript:void(0)&quot; onclick=&quot;document.getElementById(''light'').style.display=''block'';document.getElementById(''fade'').style.display=''block''&quot;&gt;&lt;p style=&quot;text-align:center;color: #fff;font-size: 10px;background: #6ED56C;padding:11px 8px;border-radius: 2px;&quot;&gt;点击关注“爱客影院”官方微信，看电影更方便!&lt;/p&gt;&lt;/a&gt;\r\n&lt;div id=&quot;light&quot; class=&quot;white_content&quot;&gt; \r\n  &lt;img src=&quot;https://s2.ax1x.com/2019/02/16/krz9Wq.png&quot; width=&quot;100%&quot; height=&quot;100%&quot;&gt;\r\n    &lt;a href=&quot;javascript:void(0)&quot; onclick=&quot;document.getElementById(''light'').style.display=''none'';document.getElementById(''fade'').style.display=''none''&quot;&gt; \r\n    &lt;span class=&quot;rewards-popover-close&quot; etap=&quot;rewards-close&quot;&gt;&lt;/span&gt;&lt;/a&gt;&lt;/div&gt; \r\n&lt;div id=&quot;fade&quot; class=&quot;black_overlay&quot;&gt; \r\n&lt;/div&gt;'),
(3, '大淘客', '分类列表下', '&lt;a href=&quot;http://tao.uuhuo.cn&quot; target=&quot;_blank&quot;&gt;&lt;img src=&quot;https://s2.ax1x.com/2019/02/16/krHHk6.png&quot; style=&quot;width:100%;&quot;&gt;&lt;/a&gt;'),
(5, '挖片模板', '搜索页右下', '&lt;a  href=&quot;https://s.click.taobao.com/okHmscw&quot; target=&quot;_blank&quot;&gt;&lt;img src=&quot;https://s2.ax1x.com/2019/02/16/ks9ilt.jpg&quot; style=&quot;width:100%;&quot;&gt;&lt;/a&gt;'),
(4, '', '播放页侧边', '&lt;div class=&quot;widget widget-textasst&quot;&gt;&lt;a class=&quot;style02&quot; href=&quot;http://wpa.qq.com/msgrd?v=3&amp;uin=776774592&amp;site=qq&amp;menu=yes&quot; target=&quot;_blank&quot;&gt;&lt;strong&gt;源码出售&lt;/strong&gt;&lt;h2&gt;更好的视频主题&lt;/h2&gt;&lt;p&gt;1.扁平化、简洁风、多功能配置，优秀的电脑、平板、手机支持，响应式布局，不同设备不同展示效果...2.视频全自动采集，不需人工干预，懒人必备！&lt;/p&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;widget widget-textasst&quot;&gt;&lt;a class=&quot;style03&quot;  href=&quot;https://s.click.taobao.com/okHmscw&quot; target=&quot;_blank&quot;&gt;&lt;strong&gt;本站同款&lt;/strong&gt;&lt;/br&gt;&lt;/br&gt;&lt;img src=&quot;https://s2.ax1x.com/2019/02/16/ks9ilt.jpg&quot;&gt;&lt;/a&gt;&lt;/div&gt;');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_basic`
--

CREATE TABLE IF NOT EXISTS `aikcms_basic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aik_name` varchar(255) DEFAULT NULL,
  `aik_domain` varchar(255) DEFAULT NULL,
  `aik_title` varchar(255) DEFAULT NULL,
  `aik_keywords` varchar(255) DEFAULT NULL,
  `aik_desc` varchar(255) DEFAULT NULL,
  `aik_shouquan` varchar(255) DEFAULT NULL,
  `aik_template` varchar(255) DEFAULT NULL,
  `aik_mtemplate` varchar(255) NOT NULL,
  `aik_icp` varchar(255) DEFAULT NULL,
  `aik_tongji` text,
  `aik_changyan` text,
  `aik_jiexi1` varchar(255) DEFAULT NULL,
  `aik_jiexi2` varchar(255) DEFAULT NULL,
  `aik_jiexi3` varchar(255) DEFAULT NULL,
  `aik_jiexi4` varchar(255) DEFAULT NULL,
  `aik_jiexi5` varchar(255) DEFAULT NULL,
  `aik_cache` varchar(255) DEFAULT NULL,
  `aik_weijing` varchar(255) DEFAULT NULL,
  `aik_onlym` varchar(255) DEFAULT NULL,
  `aik_postercome` varchar(255) DEFAULT NULL,
  `aik_wxsk` varchar(255) DEFAULT NULL,
  `aik_zfbsk` varchar(255) DEFAULT NULL,
  `aik_wxgzh` varchar(255) DEFAULT NULL,
  `aik_qqjq` varchar(255) DEFAULT NULL,
  `aik_appxz` varchar(255) DEFAULT NULL,
  `aik_biglogo` varchar(255) DEFAULT NULL,
  `aik_onelogo` varchar(255) DEFAULT NULL,
  `aik_twologo` varchar(255) DEFAULT NULL,
  `aik_wx_url` varchar(255) DEFAULT NULL,
  `aik_wx_token` varchar(255) DEFAULT NULL,
  `aik_wx_appid` varchar(255) DEFAULT NULL,
  `aik_wx_appsecret` varchar(255) DEFAULT NULL,
  `aik_wx_img` varchar(255) DEFAULT NULL,
  `aik_wx_reply` varchar(255) DEFAULT NULL,
  `aik_admin` varchar(255) DEFAULT NULL,
  `aik_admin_img` varchar(255) NOT NULL,
  `aik_admin_qq` varchar(32) NOT NULL,
  `aik_pw` varchar(255) DEFAULT NULL,
  `aik_user_open` int(11) DEFAULT NULL,
  `aik_fbjiexi1` varchar(255) DEFAULT NULL,
  `aik_fbjiexi2` varchar(255) DEFAULT NULL,
  `aik_jiexi6` varchar(255) DEFAULT NULL,
  `aik_qqappid` varchar(32) DEFAULT NULL,
  `aik_qqappkey` varchar(255) DEFAULT NULL,
  `aik_qqlogin` int(11) DEFAULT NULL,
  `aik_fresh_on` int(11) DEFAULT NULL,
  `aik_fresh_url` varchar(255) DEFAULT NULL,
  `aik_rec_on` int(11) DEFAULT NULL,
  `aik_login_play` int(12) NOT NULL,
  `aik_tort` varchar(255) DEFAULT NULL,
  `aik_zhibo` int(11) DEFAULT NULL,
  `aik_email_server` varchar(255) DEFAULT NULL,
  `aik_email_port` int(11) DEFAULT NULL,
  `aik_email_add` varchar(255) DEFAULT NULL,
  `aik_email_user` varchar(255) DEFAULT NULL,
  `aik_email_pw` varchar(255) DEFAULT NULL,
  `aik_email_inbox` varchar(255) DEFAULT NULL,
  `aik_pay_name` varchar(255) DEFAULT NULL,
  `aik_pay_id` int(255) DEFAULT NULL,
  `aik_pay_key` varchar(255) DEFAULT NULL,
  `aik_pay_url` varchar(255) DEFAULT NULL,
  `aik_pay_open` int(11) DEFAULT NULL,
  `aik_qqurl` varchar(255) DEFAULT NULL,
  `aik_user_intra` int(32) DEFAULT NULL,
  `aik_user_affint` int(32) DEFAULT NULL,
  `aik_user_initint` int(32) DEFAULT NULL,
  `aik_buycard` varchar(255) DEFAULT NULL,
  `aik_union_open` int(11) DEFAULT NULL,
  `aik_union_dtk` varchar(255) NOT NULL,
  `aik_union_dtkid` varchar(255) NOT NULL,
  `aik_union_jtt` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `aikcms_basic`
--

INSERT INTO `aikcms_basic` (`id`, `aik_name`, `aik_domain`, `aik_title`, `aik_keywords`, `aik_desc`, `aik_shouquan`, `aik_template`, `aik_mtemplate`, `aik_icp`, `aik_tongji`, `aik_changyan`, `aik_jiexi1`, `aik_jiexi2`, `aik_jiexi3`, `aik_jiexi4`, `aik_jiexi5`, `aik_cache`, `aik_weijing`, `aik_onlym`, `aik_postercome`, `aik_wxsk`, `aik_zfbsk`, `aik_wxgzh`, `aik_qqjq`, `aik_appxz`, `aik_biglogo`, `aik_onelogo`, `aik_twologo`, `aik_wx_url`, `aik_wx_token`, `aik_wx_appid`, `aik_wx_appsecret`, `aik_wx_img`, `aik_wx_reply`, `aik_admin`, `aik_admin_img`, `aik_admin_qq`, `aik_pw`, `aik_user_open`, `aik_fbjiexi1`, `aik_fbjiexi2`, `aik_jiexi6`, `aik_qqappid`, `aik_qqappkey`, `aik_qqlogin`, `aik_fresh_on`, `aik_fresh_url`, `aik_rec_on`, `aik_login_play`, `aik_tort`, `aik_zhibo`, `aik_email_server`, `aik_email_port`, `aik_email_add`, `aik_email_user`, `aik_email_pw`, `aik_email_inbox`, `aik_pay_name`, `aik_pay_id`, `aik_pay_key`, `aik_pay_url`, `aik_pay_open`, `aik_qqurl`, `aik_user_intra`, `aik_user_affint`, `aik_user_initint`, `aik_buycard`, `aik_union_open`, `aik_union_dtk`, `aik_union_dtkid`, `aik_union_jtt`) VALUES
(1, 'AikCMS - 演示站', 'http://localhost/', '﻿爱客影院 - 海量高清VIP视频免费观看', '爱客影院,电视直播网站,零八影院快播,高清云影视,云点播,免费看视频,湖南卫视直播,80电影网,最新电影天堂免费在线观看', '﻿爱客影院,热剧快播,最好看的剧情片尽在﻿爱客影院,高清云影视免费为大家提供最新最全的免费电影，电视剧，综艺，动漫无广告在线云点播，以及电视直播', '23434', 'wapian', 'wapian', '国ICP备18888888号', '&lt;script src=&quot;https://s13.cnzz.com/z_stat.php?id=1274908264&amp;web_id=1274908264&quot; language=&quot;JavaScript&quot;&gt;&lt;/script&gt;', '', 'http://app.baiyug.cn:2019/vip/?url=', 'http://api.bbbbbb.me/jx/?url=', 'http://jx.aeidu.cn/index.php?url=', 'http://player.jidiaose.com/supapi/iframe.php?v=', 'http://vip.thxcw.com/api.php?url=', '0', '0', '0', '3', 'upload/wx.png', 'upload/zfb.png', 'upload/gzh.png', '', '', '../upload/logo.png', '../upload/sologo.png', '', '1', 'weixin', 'wx07cf4ae335bbff12', '23434324234', '', '微信最大在线观看电影平台,最新院线大片免费看,输入电影【关键字】即可获取最新电影,上万部院线大片资源,可能是微信上最有温度的电影平台', 'admin', '/upload/admin.jpg', '88888888', 'e10adc3949ba59abbe56e057f20f883e', 1, 'http://app.baiyug.cn:2019/vip/?url=', '', 'http://app.baiyug.cn:2019/vip/?url=', '101528766', '4b28abd4f5812d4aad3313b13b5ceb45', 1, 2, 'http://zhanwai.aiktv.cn', 1, 0, '醉玲珑#无证之罪#权力的游戏第七季#奇葩大会第2季#相爱的七种设计#我的恋爱时代', 1, 'smtp.163.com', 25, '', '', '', '', '1', 10005422, 'b5fd07acc172aa6658f2613b7c592e9382606227f719b8b0', 'https://interface.lcardy.com/Online_Banking_interface', 1, '4b28abd4f5812d4aad3313b13b5ceb45', 10, 10, 10, 'http://tao.uuhuo.cn/index.php?r=nine&u=1205740', 3, 'http://tao.uuhuo.cn/', '18122309', 'http://vip.uuhuo.cn/');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_card`
--

CREATE TABLE IF NOT EXISTS `aikcms_card` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aik_card` varchar(255) NOT NULL DEFAULT '',
  `aik_card_group` varchar(8) NOT NULL DEFAULT '' COMMENT '分类',
  `aik_card_int` varchar(11) NOT NULL DEFAULT '' COMMENT '天数',
  `aik_card_time` varchar(255) NOT NULL DEFAULT '0',
  `aik_card_user` varchar(255) NOT NULL DEFAULT '',
  `aik_card_utime` varchar(255) DEFAULT '',
  `c_addtime` int(10) NOT NULL DEFAULT '0',
  `c_usetime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `c_used` (`aik_card_time`),
  KEY `c_sale` (`aik_card_user`),
  KEY `c_user` (`aik_card_utime`),
  KEY `c_addtime` (`c_addtime`),
  KEY `c_usetime` (`c_usetime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_colgroup`
--

CREATE TABLE IF NOT EXISTS `aikcms_colgroup` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aik_colgroup_name` varchar(255) NOT NULL,
  `aik_colgroup_fburl` varchar(255) NOT NULL,
  `aik_colgroup_cjurl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`aik_colgroup_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `aikcms_colgroup`
--

INSERT INTO `aikcms_colgroup` (`id`, `aik_colgroup_name`, `aik_colgroup_fburl`, `aik_colgroup_cjurl`) VALUES
(1, '资源站（一）', '1550582756zyzfb.php', '1550582756zyzcj.php');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_colrule`
--

CREATE TABLE IF NOT EXISTS `aikcms_colrule` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `aik_col_name` varchar(255) NOT NULL DEFAULT '',
  `aik_col_url` varchar(255) NOT NULL DEFAULT '',
  `aik_col_urlstart` varchar(32) NOT NULL DEFAULT '',
  `aik_col_urlend` varchar(32) NOT NULL DEFAULT '',
  `aik_col_videogroup` varchar(32) NOT NULL DEFAULT '',
  `aik_col_usergroup` varchar(32) NOT NULL,
  `aik_col_rule` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `aikcms_colrule`
--

INSERT INTO `aikcms_colrule` (`id`, `aik_col_name`, `aik_col_url`, `aik_col_urlstart`, `aik_col_urlend`, `aik_col_videogroup`, `aik_col_usergroup`, `aik_col_rule`) VALUES
(1, 'OK资源网-动作片', 'http://okokzy.cc/?m=vod-type-id-5.html', '1', '2', '1', '0', '1550582756zyzcj.php'),
(2, 'OK资源网-喜剧片', 'http://okokzy.cc/?m=vod-type-id-6.html', '1', '2', '2', '0', '1550582756zyzcj.php');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_gbook`
--

CREATE TABLE IF NOT EXISTS `aikcms_gbook` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aik_gbook_content` text NOT NULL,
  `aik_gbook_time` varchar(255) NOT NULL,
  `aik_gbook_reply` int(11) NOT NULL DEFAULT '0',
  `aik_gbook_userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `aikcms_gbook`
--

INSERT INTO `aikcms_gbook` (`id`, `aik_gbook_content`, `aik_gbook_time`, `aik_gbook_reply`, `aik_gbook_userid`) VALUES
(1, '13123', '1551959621', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_link`
--

CREATE TABLE IF NOT EXISTS `aikcms_link` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `aik_link_name` varchar(64) NOT NULL DEFAULT '',
  `aik_link_img` varchar(255) NOT NULL DEFAULT '',
  `aik_link_url` varchar(255) NOT NULL DEFAULT '',
  `aik_link_qq` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `aikcms_link`
--

INSERT INTO `aikcms_link` (`id`, `aik_link_name`, `aik_link_img`, `aik_link_url`, `aik_link_qq`) VALUES
(1, '小二胡工作室', '', 'http://www.xiaoerhu.com', '');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_nav`
--

CREATE TABLE IF NOT EXISTS `aikcms_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aik_nav_name` varchar(255) DEFAULT NULL,
  `aik_nav_color` varchar(32) NOT NULL,
  `aik_nav_papa` int(11) NOT NULL DEFAULT '0',
  `aik_nav_url` varchar(255) DEFAULT NULL,
  `aik_nav_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `aikcms_nav`
--

INSERT INTO `aikcms_nav` (`id`, `aik_nav_name`, `aik_nav_color`, `aik_nav_papa`, `aik_nav_url`, `aik_nav_id`) VALUES
(1, '爱客券券', '#FF0000', 0, '', 0),
(2, '淘宝内部券', '', 1, 'http://tao.uuhuo.cn', 0),
(3, '京东优惠券', '', 1, 'http://vip.uuhuo.cn', 0),
(4, '直播', '', 0, 'index.php?mode=zhibo', 0),
(5, '求片留言', '', 0, 'index.php?mode=gbook', 0);

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_notice`
--

CREATE TABLE IF NOT EXISTS `aikcms_notice` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aik_notice_title` varchar(255) NOT NULL,
  `aik_notice_url` varchar(255) NOT NULL,
  `aik_notice_time` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`aik_notice_title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `aikcms_notice`
--

INSERT INTO `aikcms_notice` (`id`, `aik_notice_title`, `aik_notice_url`, `aik_notice_time`) VALUES
(1, '淘宝内部券', 'http://tao.uuhuo.cn', '1550310663');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_poster`
--

CREATE TABLE IF NOT EXISTS `aikcms_poster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aik_hd_name` varchar(255) DEFAULT NULL,
  `aik_hd_img` varchar(255) DEFAULT NULL,
  `aik_hd_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `aikcms_poster`
--

INSERT INTO `aikcms_poster` (`id`, `aik_hd_name`, `aik_hd_img`, `aik_hd_link`) VALUES
(1, '新人领60元优惠券', '/upload/1.png', 'tao.uuhuo.cn');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_user`
--

CREATE TABLE IF NOT EXISTS `aikcms_user` (
  `id` smallint(8) unsigned NOT NULL AUTO_INCREMENT,
  `aik_user_img` varchar(255) NOT NULL DEFAULT '/upload/default/default.gif',
  `aik_user_name` varchar(255) NOT NULL DEFAULT '',
  `aik_user_alias` varchar(255) NOT NULL DEFAULT '',
  `aik_user_pw` varchar(255) NOT NULL DEFAULT '',
  `aik_user_group` varchar(255) NOT NULL DEFAULT '0',
  `aik_user_int` varchar(32) NOT NULL DEFAULT '0',
  `aik_user_time` varchar(255) NOT NULL DEFAULT '',
  `aik_user_qq` varchar(255) NOT NULL DEFAULT '',
  `aik_user_on` tinyint(1) NOT NULL DEFAULT '1',
  `aik_user_nick` varchar(255) NOT NULL DEFAULT '',
  `aik_user_qqlogin` int(11) NOT NULL DEFAULT '0',
  `aik_user_allmoney` varchar(32) NOT NULL DEFAULT '0',
  `aik_user_usedmoney` varchar(32) NOT NULL DEFAULT '0',
  `aik_user_groupend` char(255) NOT NULL DEFAULT '0',
  `aik_user_affid` varchar(11) NOT NULL DEFAULT '',
  `aik_user_ip` varchar(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `u_group` (`aik_user_allmoney`),
  KEY `u_status` (`aik_user_qq`),
  KEY `u_flag` (`aik_user_on`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `aikcms_user`
--

INSERT INTO `aikcms_user` (`id`, `aik_user_img`, `aik_user_name`, `aik_user_alias`, `aik_user_pw`, `aik_user_group`, `aik_user_int`, `aik_user_time`, `aik_user_qq`, `aik_user_on`, `aik_user_nick`, `aik_user_qqlogin`, `aik_user_allmoney`, `aik_user_usedmoney`, `aik_user_groupend`, `aik_user_affid`, `aik_user_ip`) VALUES
(1, '/upload/default/default.gif', '123', '', '202cb962ac59075b964b07152d234b70', '0', '10', '1551797020', '123', 1, '', 0, '0', '0', '0', '', '::1');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_usergroup`
--

CREATE TABLE IF NOT EXISTS `aikcms_usergroup` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `aik_usergroup_name` varchar(255) NOT NULL DEFAULT '',
  `aik_usergroup_img` varchar(255) NOT NULL,
  `aik_usergroup_price` varchar(255) NOT NULL DEFAULT '',
  `aik_usergroup_length` varchar(255) NOT NULL DEFAULT '',
  `aik_usergroup_level` int(11) NOT NULL,
  `aik_usergroup_rem` varchar(255) NOT NULL DEFAULT '',
  `aik_usergroup_open` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `aikcms_usergroup`
--

INSERT INTO `aikcms_usergroup` (`id`, `aik_usergroup_name`, `aik_usergroup_img`, `aik_usergroup_price`, `aik_usergroup_length`, `aik_usergroup_level`, `aik_usergroup_rem`, `aik_usergroup_open`) VALUES
(1, '赞助会员', '/upload/21.gif', '8.8', '31', 0, '', 0),
(2, '年费会员', '/upload/22.gif', '88.8', '366', 0, '', 0),
(3, '永久会员', '/upload/24.gif', '888.8', '9999', 0, '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_user_fav`
--

CREATE TABLE IF NOT EXISTS `aikcms_user_fav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aik_fav_name` varchar(255) DEFAULT NULL,
  `aik_fav_url` varchar(255) DEFAULT NULL,
  `aik_fav_userid` int(11) DEFAULT NULL,
  `aik_fav_time` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `aikcms_user_fav`
--

INSERT INTO `aikcms_user_fav` (`id`, `aik_fav_name`, `aik_fav_url`, `aik_fav_userid`, `aik_fav_time`) VALUES
(1, '雪地娘子军', 'http://localhost/index.php?mode=video&net=/tv/QLVqaX7lRWLlMX.html', 1, '2019-03-05'),
(2, '老中医', 'http://localhost/index.php?mode=video&net=/tv/QrJtcH7lRWLoNX.html', 1, '2019-03-05');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_user_history`
--

CREATE TABLE IF NOT EXISTS `aikcms_user_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aik_history_name` varchar(255) DEFAULT NULL,
  `aik_history_url` varchar(255) DEFAULT NULL,
  `aik_history_userid` int(11) DEFAULT NULL,
  `aik_history_time` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- 转存表中的数据 `aikcms_user_history`
--

INSERT INTO `aikcms_user_history` (`id`, `aik_history_name`, `aik_history_url`, `aik_history_userid`, `aik_history_time`) VALUES
(2, '地下凶猛', 'http://localhost/index.php?mode=video&net=/m/f6LkaRH4SHr8Tx.html', 1, '2019-03-05'),
(5, '雪地娘子军', 'http://localhost/index.php?mode=video&net=/tv/QLVqaX7lRWLlMX.html', 1, '2019-03-05'),
(9, '老中医', 'http://localhost/index.php?mode=video&net=/tv/QrJtcH7lRWLoNX.html', 1, '2019-03-07'),
(8, '海王', 'http://localhost/index.php?mode=play&vid=25571', 1, '2019-03-07');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_user_order`
--

CREATE TABLE IF NOT EXISTS `aikcms_user_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aik_order` varchar(255) NOT NULL,
  `aik_order_name` varchar(255) DEFAULT NULL,
  `aik_order_videoid` int(64) NOT NULL,
  `aik_order_videourl` varchar(255) NOT NULL,
  `aik_order_price` varchar(255) DEFAULT NULL,
  `aik_order_userid` int(11) DEFAULT NULL,
  `aik_order_time` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_user_pay`
--

CREATE TABLE IF NOT EXISTS `aikcms_user_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aik_pay_order` varchar(255) DEFAULT NULL,
  `aik_pay_num` varchar(255) DEFAULT NULL,
  `aik_pay_mode` varchar(32) NOT NULL,
  `aik_pay_userid` int(11) DEFAULT NULL,
  `aik_pay_state` int(11) NOT NULL,
  `aik_pay_time` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_video`
--

CREATE TABLE IF NOT EXISTS `aikcms_video` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aik_video_name` varchar(255) NOT NULL DEFAULT '',
  `aik_video_img` varchar(255) NOT NULL DEFAULT '',
  `aik_video_seo` varchar(255) DEFAULT NULL,
  `aik_video_group` varchar(11) DEFAULT '',
  `aik_video_pay` varchar(11) NOT NULL DEFAULT '',
  `aik_video_int` varchar(255) DEFAULT '0',
  `aik_video_usergroup` varchar(255) DEFAULT NULL,
  `aik_video_level` varchar(11) DEFAULT '0',
  `aik_video_jiexi` varchar(255) DEFAULT NULL,
  `aik_video_url` mediumtext,
  `aik_video_time` varchar(255) DEFAULT NULL,
  `aik_video_remarks` varchar(255) DEFAULT NULL,
  `aik_video_col` varchar(255) DEFAULT NULL,
  `aik_video_zylink` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `d_letter` (`aik_video_group`),
  KEY `d_name` (`aik_video_name`),
  KEY `d_enname` (`aik_video_seo`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=103 ;

--
-- 转存表中的数据 `aikcms_video`
--

INSERT INTO `aikcms_video` (`id`, `aik_video_name`, `aik_video_img`, `aik_video_seo`, `aik_video_group`, `aik_video_pay`, `aik_video_int`, `aik_video_usergroup`, `aik_video_level`, `aik_video_jiexi`, `aik_video_url`, `aik_video_time`, `aik_video_remarks`, `aik_video_col`, `aik_video_zylink`) VALUES
(1, '复仇战姬HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15506512570.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/699123454aa4781d475b96aaac59dc62\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190220/21641_3d2cea19/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190220/21641_3d2cea19/复仇战姬.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-14081.html'),
(2, '侠女传奇HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/155063998016.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://tudou.com-l-tudou.com/share/cf247d6dafc3aadcdf0b2cd608ac8f72\r\nHD高清$http://tudou.com-l-tudou.com/20190220/16050_a3b08240/index.m3u8\r\nHD高清$http://xunlei4.okzyxz.com/20190220/16050_a3b08240/侠女传奇-粤国双语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-29074.html'),
(3, '鹰爪铁布衫HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15505589802.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/4b12d1170b1c520116d2b7987dd47140\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190220/21636_43aabd95/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190220/21636_43aabd95/鹰爪铁布衫1977(粤语中字).mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-29006.html'),
(4, '虎口飞花HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/201902201550637213.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/f18224a1adfb7b3dbff668c9b655a35a\r\nHD高清$http://56.com-t-56.com/20190219/5431_2a3b8eb2/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190219/5431_2a3b8eb2/虎口飞花.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-29062.html'),
(5, '香港超人大破摧花党HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15505509544.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://tudou.com-l-tudou.com/share/07d8be4e98fe2f96153d2e43b791d4ea\r\nHD高清$http://tudou.com-l-tudou.com/20190219/16037_45ad6ff7/index.m3u8\r\nHD高清$http://xunlei4.okzyxz.com/20190219/16037_45ad6ff7/香港超人大破摧花党.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28999.html'),
(6, '宇宙狙击HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/201902181550476786.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/f5ac21cd0ef1b88e9848571aeb53551a\r\nHD高清$http://youku.com-t-youku.com/20190217/5098_efc29f3b/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190217/5098_efc29f3b/宇宙狙击.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28961.html'),
(7, '血腥FridayHD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15504777522.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/5a9542c773018268fc6271f7afeea969\r\nHD高清$http://youku.com-t-youku.com/20190217/5097_b17c19ff/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190217/5097_b17c19ff/血腥FRIDAY.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28959.html'),
(8, '头文字D真人版HD', 'http://pic.china-gif.com/pic/upload/vod/2018-10/153863075412.jpg', NULL, '1', '', '0', '0', '0', NULL, '粤语$http://youku.com-t-youku.com/20190217/5094_edcb4d88/index.m3u8\r\n国语$http://youku.com-i-youku.com/20181003/9158_8d10d1fd/index.m3u8\r\n粤语$http://youku.com-t-youku.com/share/358f9e7be09177c17d0d17ff73584307\r\n国语$http://youku.com-i-youku.com/share/316282ddb77e11b0b58c60ed59b1e308\r\n粤语$http://xunlei9.okzyxz.com/20190217/5094_edcb4d88/头文字D粤语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-21173.html'),
(9, '狮神再现HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15504777460.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/197838c579c3b78927e0cd15ba4c9689\r\nHD高清$http://youku.com-t-youku.com/20190217/5093_d83566c8/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190217/5093_d83566c8/狮神再现.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28957.html'),
(10, '杀陷HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/201902181550476304.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/73d915c91b99b170993ea97d875a6330\r\nHD高清$http://youku.com-t-youku.com/20190217/5092_5689056e/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190217/5092_5689056e/杀陷.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28956.html'),
(11, '伦敦战场HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15504677773.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/6578ea8c336aa704c7e8ea2c5f19353b\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190218/21609_856e900e/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190218/21609_856e900e/伦敦战场.London.fields.2018.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28919.html'),
(12, '麻辣女孩HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15503940820.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD机翻$http://bilibili.com-l-bilibili.com/20190217/8037_40309563/index.m3u8\r\nHD机翻$http://bilibili.com-l-bilibili.com/share/3a9de64a6c62c8cd6ff8320bafb8452f\r\nHD机翻$http://xunlei1.okzyxz.com/20190217/8037_40309563/麻辣女孩 Kim Possible (2019)HD机翻.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28898.html'),
(13, '古法泰拳HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/201902171550389202.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/aa155ec10ec4a303cda6180852c343d1\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190217/21604_9adfd683/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190217/21604_9adfd683/古法泰拳.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28896.html'),
(14, '盗窃战HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15503745684.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/b7e67bd1951c09018e6a851fb2e7d9ca\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190217/21588_358ade68/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190217/21588_358ade68/盗窃战purasangre2016.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28843.html'),
(15, '杀人优越权HD', 'http://pic.china-gif.com/pic/upload/vod/2017-12-01/201712011512098770.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://cn2.okokyun.com/share/w21pVD3L7Jxyzj1s\r\nHD高清$http://cn2.okokyun.com/20171201/0fwhOoN0/index.m3u8', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-3607.html'),
(16, '阿丽塔：战斗天使TS中字', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15502437970.jpg', NULL, '1', '', '0', '0', '0', NULL, 'TS机翻$http://sina.com-l-sina.com/20190216/29496_5d81b9f1/index.m3u8\r\nTS机翻$http://sina.com-l-sina.com/share/5cd338743288fdb62b74ee279d51bf93\r\nTS机翻$http://xunlei7.okzyxz.com/20190216/29496_5d81b9f1/阿丽塔：战斗天使TS机翻.mp4', NULL, 'TS中字', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28795.html'),
(17, '冷血追击TS英语无字', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15502406782.jpg', NULL, '1', '', '0', '0', '0', NULL, 'TS英语无字$http://iqiyi.com-l-iqiyi.com/share/feb31e0af2ca1ebde5c5c4f73a57fef8\r\nTS英语无字$http://iqiyi.com-l-iqiyi.com/20190216/21585_61622d95/index.m3u8\r\nTS英语无字$http://xunlei.okzyxz.com/20190216/21585_61622d95/Cold.Pursuit.2019.mp4', NULL, 'TS英语无字', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28793.html'),
(18, '重生之绝世医仙HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/155021711516.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/d5ff135377d39f1de7372c95c74dd962\r\nHD高清$http://youku.com-t-youku.com/20190213/4022_18caa7eb/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190213/4022_18caa7eb/重生之绝世医仙.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28786.html'),
(19, '最萌警探HD', 'http://pic.china-gif.com/pic/upload/vod/2018-12/15441883740.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://pptv.com-l-pptv.com/share/d169e16da608a6a8d61bc64a2d333e8a\r\nHD高清$http://pptv.com-l-pptv.com/20190210/14435_cacee05f/index.m3u8\r\nHD高清$http://xunlei3.okzyxz.com/20190210/14435_cacee05f/最萌警探-BD1280俄语中字.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-24565.html'),
(20, '撕票风云HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/201902101549782905.jpg', NULL, '1', '', '0', '0', '0', NULL, '粤语$http://youku.com-t-youku.com/share/0060ef47b12160b9198302ebdb144dcf\r\n国语$http://youku.com-t-youku.com/share/6c91724b896cdcf48285039ab05b3aaf\r\n粤语$http://youku.com-t-youku.com/20190210/3492_e5f41eeb/index.m3u8\r\n国语$http://youku.com-t-youku.com/20190210/3491_c6dd3778/index.m3u8\r\n粤语$http://xunlei9.okzyxz.com/20190210/3492_e5f41eeb/撕票风云粤语.mp4\r\n国语$http://xunlei9.okzyxz.com/20190210/3491_c6dd3778/撕票风云国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28523.html'),
(21, '师父HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/201902101549782771.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/72f67e70f6b7cdc4cc893edaddf0c4c6\r\nHD高清$http://youku.com-t-youku.com/20190210/3490_7225eb18/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190210/3490_7225eb18/师父.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28522.html'),
(22, '三少爷的剑2016HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15497853681.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/2be9bd7a3434f7038ca27d1918de58bd\r\nHD高清$http://56.com-t-56.com/20190208/3333_5a49d28f/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190208/3333_5a49d28f/三少爷的剑2016.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28521.html'),
(23, '三少爷的剑1977HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15497853650.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/0a2a51dac6138826127f093500461d91\r\nHD高清$http://56.com-t-56.com/20190208/3331_d214b632/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190208/3331_d214b632/三少爷的剑1977.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28520.html'),
(24, '皇家师姐7HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/154978166513.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/c7b90b0fc23725f299b47c5224e6ec0d\r\nHD高清$http://youku.com-t-youku.com/20190210/3488_285e7455/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190210/3488_285e7455/皇家师姐7.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28516.html'),
(25, '皇家师姐6HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/154978166212.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/944a5ae3483ed5c1e10bbccb7942a279\r\nHD高清$http://youku.com-t-youku.com/20190210/3487_35e0a7a6/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190210/3487_35e0a7a6/皇家师姐6.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28515.html'),
(26, '皇家师姐5HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/154978165911.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/ab4f2b5fd96ca65349119909c1eada2d\r\nHD高清$http://youku.com-t-youku.com/20190210/3486_69c3ecbd/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190210/3486_69c3ecbd/皇家师姐5.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28514.html'),
(27, '皇家师姐HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/154978165610.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-t-youku.com/share/dfeb9598fbfb97cc6bbcc0aff2c785d6\r\nHD高清$http://youku.com-t-youku.com/20190210/3485_e392ab5f/index.m3u8\r\nHD高清$http://xunlei9.okzyxz.com/20190210/3485_e392ab5f/皇家师姐.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28513.html'),
(28, '白虎HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15497816456.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/a4351b79d9ea3d842efa89fae5d02b24\r\nHD高清$http://56.com-t-56.com/20190208/3323_394e9305/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190208/3323_394e9305/白虎.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28506.html'),
(29, '云南虫谷HD', 'http://pic.china-gif.com/pic/upload/vod/2018-12/15460763103.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/f1b2bbc102904120c225e2e80b60d0fe\r\nHD高清$http://sina.com-l-sina.com/20190209/29489_8d8b73bc/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190209/29489_8d8b73bc/云南虫谷.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-25775.html'),
(30, '命运手枪HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15496947825.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/9eec67a7083de7ce59a9e898049a065e\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190209/21476_b93c23dc/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190209/21476_b93c23dc/[命运手枪][多米尼加].La.Gunguna.2015.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28455.html'),
(31, '海王韩版/国语', 'http://pic.china-gif.com/pic/upload/vod/2018-12/201812071544147322.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/f3e473999b625855bdf3f6a75f7b8f3a\r\n国语版$http://sina.com-l-sina.com/share/f68b5a44fdcb800076afc2ea0fe16305\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190123/21250_46cb1501/index.m3u8\r\n国语版$http://sina.com-l-sina.com/20190208/29483_416fe509/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190123/21250_46cb1501/海王.Aquaman.2018.mp4\r\n国语版$http://xunlei7.okzyxz.com/20190208/29483_416fe509/海王(国语配).mp4', NULL, '韩版/国语', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-24415.html'),
(32, '暗杀教室真人版HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15496280520.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/b4944963b5c83d545c3d3022bcf03282\r\nHD高清$http://56.com-t-56.com/20190207/2890_3c7385b3/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190207/2890_3c7385b3/暗杀教室真人版.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28411.html'),
(33, '生化危机1HD', 'http://pic.china-gif.com/pic/upload/vod/2017-09-09/201709091504938301.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/488c1e0332065eb80e1129139a67d6e0\r\nHD高清$http://56.com-t-56.com/20190207/2888_0803b8c3/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190207/2888_0803b8c3/生化危机1.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-2008.html'),
(34, '叶问外传：张天志HD国粤双语', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15495254700.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD国语高清$http://iqiyi.com-l-iqiyi.com/20190207/21452_40ff89c1/index.m3u8\r\nHD粤语高清$http://iqiyi.com-l-iqiyi.com/20190207/21451_238f4789/index.m3u8\r\nHD国语高清$http://iqiyi.com-l-iqiyi.com/share/51e7fea7f69ef6875f82e22c5eda5e26\r\nHD粤语高清$http://iqiyi.com-l-iqiyi.com/share/a5451ac57849a2ed0d3938dd4a3efa39\r\nHD国语高清$http://xunlei.okzyxz.com/20190207/21452_40ff89c1/叶问外传：张天志(国语).mp4\r\nHD粤语高清$http://xunlei.okzyxz.com/20190207/21451_238f4789/叶问外传：张天志(粤语).mp4', NULL, 'HD国粤双语', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-25247.html'),
(35, '柏林HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15495252730.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/7e0a0209b929d097bd3e8ef30567a5c1\r\nHD高清$http://56.com-t-56.com/20190206/2872_33d26633/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190206/2872_33d26633/柏林.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28352.html'),
(36, '霸主HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15492871240.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/e5fa8a713417afe3c4fd2b9ddfb2d734\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190204/21419_b041c394/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190204/21419_b041c394/霸主.Overlord.2018.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-23109.html'),
(37, '少侠好功夫HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15490954831.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/c8fd9e36fdeb06bcc93a0732c667b6d8\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190202/21384_1f22d35e/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190202/21384_1f22d35e/少侠好功夫-国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28123.html'),
(38, '广东十虎铁桥三之王者荣威HD', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15490254400.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/c519d2a456ff3844afd6966f7707100b\r\nHD高清$http://sina.com-l-sina.com/20190201/29473_9ec2e8f8/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190201/29473_9ec2e8f8/广东十虎铁桥三之王者荣威.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-28066.html'),
(39, '挪威7·22爆炸枪击案HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15488544570.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/14515b66c19dfb745f5a2fccc8f1393f\r\nHD高清$http://sina.com-l-sina.com/20190130/29470_1b63fa21/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190130/29470_1b63fa21/挪威7·22爆炸枪击案.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27969.html'),
(40, '重装捍将HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15488458438.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/5a142a55461d5fef016acfb927fee0bd\r\nHD高清$http://56.com-t-56.com/20190129/1710_72a2af41/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190129/1710_72a2af41/重装捍将.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27966.html'),
(41, '赌城大亨II之至尊无敌HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/154876771211.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://56.com-t-56.com/share/571d3a9420bfd9219f65b643d0003bf4\r\nHD高清$http://56.com-t-56.com/20190128/1475_162c7972/index.m3u8\r\nHD高清$http://xunlei11.okzyxz.com/20190128/1475_162c7972/赌城大亨2之至尊无敌国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27918.html'),
(42, '黄飞鸿之英雄有梦HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15487676883.jpg', NULL, '1', '', '0', '0', '0', NULL, '粤语$http://56.com-t-56.com/share/ac796a52db3f16bbdb6557d3d89d1c5a\r\n国语$http://56.com-t-56.com/share/daa96d9681a21445772454cbddf0cac1\r\n粤语$http://56.com-t-56.com/20190128/1473_555da8f3/index.m3u8\r\n国语$http://56.com-t-56.com/20190128/1472_d4e39ebb/index.m3u8\r\n粤语$http://xunlei11.okzyxz.com/20190128/1473_555da8f3/黄飞鸿之英雄有梦粤语.mp4\r\n国语$http://xunlei11.okzyxz.com/20190128/1472_d4e39ebb/黄飞鸿之英雄有梦国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27910.html'),
(43, '铁血雄风HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901281548669444.jpg', NULL, '1', '', '0', '0', '0', NULL, '英语$http://56.com-t-56.com/share/24146db4eb48c718b84cae0a0799dcfc\r\n国语$http://56.com-t-56.com/share/82b8a3434904411a9fdc43ca87cee70c\r\n英语$http://56.com-t-56.com/20190127/1026_52b29e3c/index.m3u8\r\n国语$http://56.com-t-56.com/20190127/1025_32f0f754/index.m3u8\r\n英语$http://xunlei10.okzyxz.com/20190127/1026_52b29e3c/铁血雄风英语.mp4\r\n国语$http://xunlei10.okzyxz.com/20190127/1025_32f0f754/铁血雄风国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27826.html'),
(44, '一代宗师HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15486713970.jpg', NULL, '1', '', '0', '0', '0', NULL, '粤语$http://56.com-t-56.com/share/08d98638c6fcd194a4b1e6992063e944\r\n国语$http://56.com-t-56.com/share/1595af6435015c77a7149e92a551338e\r\n粤语$http://56.com-t-56.com/20190127/682_019a36ee/index.m3u8\r\n国语$http://56.com-t-56.com/20190127/681_8b8ef585/index.m3u8\r\n粤语$http://xunlei10.okzyxz.com/20190127/682_019a36ee/一代宗师粤语.mp4\r\n国语$http://xunlei10.okzyxz.com/20190127/681_8b8ef585/一代宗师国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27825.html'),
(45, '印度暴徒HD国印双语', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15466891411.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清印地语$http://iqiyi.com-l-iqiyi.com/share/c644332952f476c37daa950b502c850e\r\nHD高清国语$http://iqiyi.com-l-iqiyi.com/share/0d6d4579fd82b21026c44e6910669fcf\r\nHD高清印地语$http://iqiyi.com-l-iqiyi.com/20190105/20820_1751a869/index.m3u8\r\nHD高清国语$http://iqiyi.com-l-iqiyi.com/20190128/21322_e1d359cb/index.m3u8\r\nHD高清印地语$http://xunlei.okzyxz.com/20190105/20820_1751a869/印度暴徒Thugs.of.Hindostan.2018.mp4\r\nHD高清国语$http://xunlei.okzyxz.com/20190128/21322_e1d359cb/印度暴徒(国语).mp4', NULL, 'HD国印双语', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26208.html'),
(46, '无双BD国粤高清', 'http://pic.china-gif.com/pic/upload/vod/2018-12/15453210360.jpg', NULL, '1', '', '0', '0', '0', NULL, 'BD国语高清$http://iqiyi.com-l-iqiyi.com/share/2f5d21999da313309846db2cf8f995df\r\nBD粤语高清$http://iqiyi.com-l-iqiyi.com/share/b8d60045db7568e16e497defc192abdf\r\nBD国语高清$http://iqiyi.com-l-iqiyi.com/20181220/20358_5b32e04b/index.m3u8\r\nBD粤语高清$http://iqiyi.com-l-iqiyi.com/20190116/21098_91eb51b8/index.m3u8\r\nBD国语高清$http://xunlei.okzyxz.com/20181220/20358_5b32e04b/无双_高清.mp4\r\nBD粤语高清$http://xunlei.okzyxz.com/20190116/21098_91eb51b8/无双.2018.HD1080P.X264.AAC.粤语中字.mp4', NULL, 'BD国粤高清', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-25216.html'),
(47, '奇兵1990HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901261548479945.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/f5abe18064d57c2e5a768504a2041036\r\nHD高清$http://sina.com-l-sina.com/20190126/28911_14a7249c/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190126/28911_14a7249c/奇兵.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27711.html'),
(48, '特警霸王花HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901251548414231.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/a12848aeac58ac57e95977f93fec17fd\r\nHD高清$http://sina.com-l-sina.com/20190125/28640_f575af74/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190125/28640_f575af74/特警霸王花.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27668.html'),
(49, '猎狼行动HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901251548414044.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/5c6839e11219ac4b4021d194b43665f7\r\nHD高清$http://sina.com-l-sina.com/20190125/28634_8edcf0b6/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190125/28634_8edcf0b6/猎狼行动(赌豪).mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27666.html'),
(50, '肝胆相照HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901251548413643.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/6ce9f61e2ff2bc4b922aeda874e96d5b\r\nHD高清$http://sina.com-l-sina.com/20190125/28630_d0d0cc24/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190125/28630_d0d0cc24/肝胆相照.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27662.html'),
(51, '赌煞HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901251548413481.jpg', NULL, '1', '', '0', '0', '0', NULL, '粤语$http://sina.com-l-sina.com/share/35c1124dd508ead6eb8c4aee9a7f5d71\r\n国语$http://sina.com-l-sina.com/share/b67d084d74c3f7c0145f96a0ac4c82a8\r\n粤语$http://sina.com-l-sina.com/20190125/28628_8c34edb7/index.m3u8\r\n国语$http://sina.com-l-sina.com/20190125/28627_8ffe6c1f/index.m3u8\r\n粤语$http://xunlei7.okzyxz.com/20190125/28628_8c34edb7/赌煞粤语.mp4\r\n国语$http://xunlei7.okzyxz.com/20190125/28627_8ffe6c1f/赌煞国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27660.html'),
(52, '赌鬼', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901251548413257.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/37563f059c2d815bf5fc637cb88e1df3\r\nHD高清$http://sina.com-l-sina.com/20190125/28625_75d6e246/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190125/28625_75d6e246/赌鬼.mp4', NULL, '', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27658.html'),
(53, '霸道纵横HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15484139512.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/544d86a583c877780b83a3b31e226465\r\nHD高清$http://sina.com-l-sina.com/20190125/28623_e241de16/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190125/28623_e241de16/霸道纵横.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27656.html'),
(54, '龙凤贼捉贼HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901251548412373.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/b4049a148eacf5ac3b5eac7c67e85758\r\nHD高清$http://sina.com-l-sina.com/20190125/28616_14957dc2/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190125/28616_14957dc2/龙凤贼捉贼粤语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27649.html'),
(55, '黄飞鸿笑传HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901251548412301.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/4f6cb5f6a3723a126aa3cae19027a2f8\r\nHD高清$http://sina.com-l-sina.com/20190125/28614_6a1952b2/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190125/28614_6a1952b2/黄飞鸿笑传.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27647.html'),
(56, '霸王女福星HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15484126610.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/3a95790514f43839f9aef7a3e9d00d5c\r\nHD高清$http://sina.com-l-sina.com/20190125/28613_d3c24d43/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190125/28613_d3c24d43/霸王女福星.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27646.html'),
(57, '极线杀手HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15484089761.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/e0433ffcc207263b70a14fd965ae86ca\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190125/21296_ae1e1057/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190125/21296_ae1e1057/极线杀手.Polar.2019.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27641.html'),
(58, '死侍2：我爱我家HD英语无字', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15484052660.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/9a8f0030ad1618cfb965b48634eecdad\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190125/21294_36849822/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190125/21294_36849822/死侍2：我爱我家.mp4', NULL, 'HD英语无字', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27639.html'),
(59, '九一神雕侠侣HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15484001393.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/c8d8f71dea35566f85564149a8cc8324\r\nHD高清$http://sina.com-l-sina.com/20190124/28408_62a68886/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190124/28408_62a68886/九一神雕侠侣.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27609.html'),
(60, '卧虎藏龙2HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901251548398128.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/share/6f760a053c4fc2b0e7a369b42fd7f68c\r\nHD高清$http://sina.com-l-sina.com/20190123/27137_c85f5806/index.m3u8\r\nHD高清$http://xunlei7.okzyxz.com/20190123/27137_c85f5806/卧虎藏龙2.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27586.html'),
(61, '幽灵车：复仇之路HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15482981330.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/d108ce39d7f265448f15d0a68683ed17\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190123/21244_5d1a9514/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190123/21244_5d1a9514/幽灵车：复仇之路.The.Car.Road.To.Revenge.2019.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27537.html'),
(62, '被解救的姜戈HD高清', 'http://pic.china-gif.com/pic/upload/vod/2017-12-12/201712121513055726.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://vip.okokbo.com/share/bFU6PsNWwbtjXO57\r\nHD高清$http://vip.okokbo.com/20171212/KDndHfUu/index.m3u8', NULL, 'HD高清', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-4063.html'),
(63, '飞虎精英之人间有情HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901231548222311.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-l-youku.com/20190122/18740_50fa6105/index.m3u8\r\nHD高清$http://youku.com-l-youku.com/share/705c03a1245566a3edb2d1c3ddcbb6ff\r\nHD高清$http://xunlei8.okzyxz.com/20190122/18740_50fa6105/飞虎精英之人间有情.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27500.html'),
(64, '危城HD', 'http://pic.china-gif.com/pic/upload/vod/2018-05/152515945919.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/20190122/21230_c9985bf7/index.m3u8\r\nHD高清$http://iqiyi.com-l-iqiyi.com/share/a4cfff2f82da85e81bb59f671dc8bb1d\r\nHD高清$http://xunlei.okzyxz.com/20190122/21230_c9985bf7/危城.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-13143.html'),
(65, '大侠沈胜衣HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901221548143795.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-l-youku.com/20190121/18578_ca6d75ba/index.m3u8\r\nHD高清$http://youku.com-l-youku.com/share/80f0fe8bd3a7ea69b926c38b6e3c4772\r\nHD高清$http://xunlei8.okzyxz.com/20190121/18578_ca6d75ba/大侠沈胜衣.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27451.html'),
(66, '诱拐2003HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15480751902.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/20190121/26654_e39bb666/index.m3u8\r\nHD高清$http://sina.com-l-sina.com/share/d9236c0a634ecbcb339a2646250c420c\r\nHD高清$http://xunlei7.okzyxz.com/20190121/26654_e39bb666/诱拐2003.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27418.html'),
(67, '家园防线HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/154807430710.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/20190121/26637_2868b65a/index.m3u8\r\nHD高清$http://sina.com-l-sina.com/share/f1e57fc231d053ef54780bd2c288b5cb\r\nHD高清$http://xunlei7.okzyxz.com/20190121/26637_2868b65a/家园防线.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27405.html'),
(68, '白夜最长时HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15480743018.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/20190121/26639_6ccc4209/index.m3u8\r\nHD高清$http://sina.com-l-sina.com/share/6af814698155afb9511dd5e91454834a\r\nHD高清$http://xunlei7.okzyxz.com/20190121/26639_6ccc4209/白夜最长时.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27402.html'),
(69, '黄飞鸿与鬼脚七HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15480402141.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/6d81df16fca504b6fb9280b11d2b0ae0\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190120/21191_8fb06c54/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190120/21191_8fb06c54/黄飞鸿与鬼脚七.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27341.html'),
(70, '黄飞鸿对黄飞鸿HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15480402110.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/9eb6efc1928a2c550b803bcd5d64faaf\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190120/21190_cae77022/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190120/21190_cae77022/黄飞鸿对黄飞鸿国语中字.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27340.html'),
(71, '“大”人物HC', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901051546685012.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HC高清$http://bilibili.com-l-bilibili.com/share/416e5cf0acb7e553a880b7647903da6e\r\nHC高清$http://bilibili.com-l-bilibili.com/20190120/7951_4ad4108d/index.m3u8\r\nHC高清$http://xunlei1.okzyxz.com/20190120/7951_4ad4108d/大人物HC.mp4', NULL, 'HC', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26206.html'),
(72, '极线杀手HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901201547966433.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD精校字幕$http://bilibili.com-l-bilibili.com/20190120/7950_0d84286b/index.m3u8\r\nHD精校字幕$http://bilibili.com-l-bilibili.com/share/08808cfb5939be387af3c159b83c6b98\r\n迅雷HD$http://xunlei1.okzyxz.com/20190120/7950_0d84286b/极线杀手 Polar (2019)Polar.2019.HD完美.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27310.html'),
(73, '天生杀人狂HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/154797117417.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/20190120/25983_7473a67e/index.m3u8\r\nHD高清$http://sina.com-l-sina.com/share/f20fc1528a7cf30c9d94068b6e65a20e\r\nHD高清$http://xunlei7.okzyxz.com/20190120/25983_7473a67e/天生杀人狂.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27301.html'),
(74, '贴身女保镖2019HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15478122870.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/1986405e39c5a79665af1746738c1f46\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190118/21143_e2112051/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190118/21143_e2112051/贴身女保镖.Close.2019.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27186.html'),
(75, '姐姐2019HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/154781232210.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/1a042e38b6cad7c50aafe731b44212a4\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190118/21144_32a1d788/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190118/21144_32a1d788/姐姐 [FHDRip1080p韩语中字].mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27188.html'),
(76, '霍元甲之精武天下HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15478057950.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/930dcd054bee88067db8ded7a2086106\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190118/21140_dbf3820f/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190118/21140_dbf3820f/霍元甲之精武天下.2019.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27174.html'),
(77, '中俄列车大劫案HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901181547790060.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-l-youku.com/20190118/16862_ddc815ab/index.m3u8\r\nHD高清$http://youku.com-l-youku.com/share/3550284cdc2575eae68335f00870aaab\r\nHD高清$http://xunlei8.okzyxz.com/20190118/16862_ddc815ab/中俄列车大劫案.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27146.html'),
(78, '洪拳大师1978HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15476992021.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/bdbd38069899d6d54d7c8547f4c6b77c\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190116/21100_0fd7de15/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190116/21100_0fd7de15/洪拳大师.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-27063.html'),
(79, '锦衣神探HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15476096931.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/32e7b56fb911eb28c0d28e10db9e353a\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190115/21082_a3429fd2/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190115/21082_a3429fd2/锦衣神探.2019.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26984.html'),
(80, '特工风云HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15476096962.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/96b6715edb4b085b70f0cff47d43a1ed\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190115/21080_649807bc/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190115/21080_649807bc/与魔共舞-英语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26982.html'),
(81, '七灵宝塔HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15476087600.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/d9f69d6ca121fc20a0c854b91483958c\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190115/21076_96b2803a/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190115/21076_96b2803a/七灵宝塔.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26978.html'),
(82, '沉默者HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15476087631.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/738c875d02a61f56eb30127ae50d0c88\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190115/21071_26e15900/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190115/21071_26e15900/沉默者-英语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26973.html'),
(83, '无品大将迷魂战HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15476080010.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://pptv.com-l-pptv.com/share/dbf138511ed1d9278bde43cc0000e49a\r\nHD高清$http://pptv.com-l-pptv.com/20190115/12835_9dc0ac03/index.m3u8\r\nHD高清$http://xunlei3.okzyxz.com/20190115/12835_9dc0ac03/无品大将迷魂战 HD1280国语中字.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26969.html'),
(84, '开封降魔记HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/201901151547562876.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://youku.com-l-youku.com/20190115/16010_d8af8b72/index.m3u8\r\nHD高清$http://youku.com-l-youku.com/share/67a20639726a041ddbbd0f78e010f78b\r\nHD高清$http://xunlei8.okzyxz.com/20190115/16010_d8af8b72/开封降魔记.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26962.html'),
(85, '冰海陷落HD', 'http://pic.china-gif.com/pic/upload/vod/2018-10/15409533172.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/5ee3d718e484b7fee862c8d6a7b89c84\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190115/21068_8dff41cc/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190115/21068_8dff41cc/冰海陷落.Hunter Killer.2018.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-22541.html'),
(86, '叶问3HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15474528652.jpg', NULL, '1', '', '0', '0', '0', NULL, '粤语$http://sina.com-l-sina.com/20190114/24031_d9f5067f/index.m3u8\r\n国语$http://sina.com-l-sina.com/20190114/24030_4212030e/index.m3u8\r\n粤语$http://sina.com-l-sina.com/share/8474b8609e772af467ac0fc4acad4dd4\r\n国语$http://sina.com-l-sina.com/share/5de6755473dc988fe6c7db81f26a53ac\r\n粤语$http://xunlei7.okzyxz.com/20190114/24031_d9f5067f/叶问3粤语.mp4\r\n国语$http://xunlei7.okzyxz.com/20190114/24030_4212030e/叶问3国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26860.html'),
(87, '叶问2：宗师传奇HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/154745289512.jpg', NULL, '1', '', '0', '0', '0', NULL, '粤语$http://sina.com-l-sina.com/20190114/24029_4cd2ae95/index.m3u8\r\n国语$http://sina.com-l-sina.com/20190114/24028_4d30d044/index.m3u8\r\n粤语$http://sina.com-l-sina.com/share/383d86008edae3a3a7e68c59c0da6dbe\r\n国语$http://sina.com-l-sina.com/share/d3edf7943d676d05300127b451a0f4ce\r\n粤语$http://xunlei7.okzyxz.com/20190114/24029_4cd2ae95/叶问2粤语.mp4\r\n国语$http://xunlei7.okzyxz.com/20190114/24028_4d30d044/叶问2国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26859.html'),
(88, '铁汉柔情1990HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15474418976.jpg', NULL, '1', '', '0', '0', '0', NULL, '第01集$http://iqiyi.com-l-iqiyi.com/share/47b263e3b40d20089f2d73695fd2c2bb\r\n第02集$http://iqiyi.com-l-iqiyi.com/share/2ea3ff45d620f62b6669490c57394f3c\r\n第01集$http://iqiyi.com-l-iqiyi.com/20190113/21014_52106ecc/index.m3u8\r\n第02集$http://iqiyi.com-l-iqiyi.com/20190113/21013_76045b7a/index.m3u8\r\n第01集$http://xunlei.okzyxz.com/20190113/21014_52106ecc/铁汉柔情1989CD1.mp4\r\n第02集$http://xunlei.okzyxz.com/20190113/21013_76045b7a/铁汉柔情1989CD2.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26832.html'),
(89, '冬荫功2：拳霸天下HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15473905362.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/20190113/23877_84a670bf/index.m3u8\r\nHD高清$http://sina.com-l-sina.com/share/b127736036570a93d69257db8d329047\r\nHD高清$http://xunlei7.okzyxz.com/20190113/23877_84a670bf/冬荫功2.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26808.html'),
(90, '冬荫功HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15473905321.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/20190113/23879_84bf43e3/index.m3u8\r\nHD高清$http://sina.com-l-sina.com/share/73c0551eb9d9731879220abc605cb9b3\r\nHD高清$http://xunlei7.okzyxz.com/20190113/23879_84bf43e3/冬荫功.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26807.html'),
(91, '铁血精英HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15473652802.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/20190113/23871_ac501376/index.m3u8\r\nHD高清$http://sina.com-l-sina.com/share/bbb8f66a204ee518c9a971fcc7492cef\r\nHD高清$http://xunlei7.okzyxz.com/20190113/23871_ac501376/铁血精英.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26783.html'),
(92, '硬汉团HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15473605883.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/304db9bced11bfeb3539e3b68b9d811c\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190113/20995_4a38cbad/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190113/20995_4a38cbad/硬汉团.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26754.html'),
(93, '大毒枭HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15473026094.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://sina.com-l-sina.com/20190112/23513_7cb4c89f/index.m3u8\r\nHD高清$http://sina.com-l-sina.com/share/707d151938a001b172e8029cbeccf67b\r\nHD高清$http://xunlei7.okzyxz.com/20190112/23513_7cb4c89f/大毒枭.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26721.html'),
(94, '太子爷出差HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15472047632.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/d0531daf947fa47ce14609890e1b91a2\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190111/20961_a9191ddd/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190111/20961_a9191ddd/太子爷出差.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26608.html'),
(95, '荷兰杀手HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15471887403.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/2f7a9c9514d09783e9f4159877dc80ac\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190111/20956_b934b003/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190111/20956_b934b003/荷兰杀手.Dutch.Kills.2015.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26603.html'),
(96, '杀死琼HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/154718207911.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/fc0aafd651946d038137a3b480c2e639\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190110/20943_7cf2fd6e/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190110/20943_7cf2fd6e/杀死琼.Killing.Joan.2018.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26554.html'),
(97, '铁臂双雄HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15471145008.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/7048c496a6cf49699109089b743c2bf6\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190110/20922_1d6d3a16/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190110/20922_1d6d3a16/铁臂双雄.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26507.html'),
(98, '重案实录纸醉金迷HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15470995440.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/6b967fe2534e4c3e13a69881876a9cdf\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190110/20911_f9180294/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190110/20911_f9180294/重案实录之纸醉金迷国语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26496.html'),
(99, '虎影HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15470410623.jpg', NULL, '1', '', '0', '0', '0', NULL, 'HD高清$http://iqiyi.com-l-iqiyi.com/share/518d52eee664842ce523e2cce507315c\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190109/20906_c2eea6d1/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190109/20906_c2eea6d1/虎影-日语.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26444.html'),
(100, '哥斯拉：噬星者HD', 'http://pic.china-gif.com/pic/upload/vod/2019-01/15470164260.jpg', '', '1', '', '0', '0', '2', '0', 'HD高清$http://iqiyi.com-l-iqiyi.com/share/786fc7b5f34ec5a502ca28e7717617f2\r\nHD高清$http://iqiyi.com-l-iqiyi.com/20190109/20895_ba9f1583/index.m3u8\r\nHD高清$http://xunlei.okzyxz.com/20190109/20895_ba9f1583/Godzilla.The.Planet.Eater.2018.mp4', NULL, 'HD', '1550582756zyzcj.php', 'http://okokzy.cc/?m=vod-detail-id-26432.html'),
(101, '韩国范拍f152', 'http://pic.china-gif.com/pic/upload/vod/2019-02/15506703252.jpg', '', '1', '', '0', '0', '0', '0', '第01集$http://tudou.com-l-tudou.com/share/ccda428c489a0d3bf7a1b8c432b535cf\r\n第01集$http://tudou.com-l-tudou.com/20190220/16052_02980b92/index.m3u8\r\n第01集$http://xunlei4.okzyxz.com/20190220/16052_02980b92/f152.mp4', NULL, '高清', '1550582756zyzfb.php', 'http://okokzy.cc/?m=vod-detail-id-29090.html'),
(102, '阿丽塔：战斗天使', 'https://gss0.bdstatic.com/94o3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike933%2C5%2C5%2C933%2C330/sign=fbdbd432815494ee932f074b4c9c8b9b/30adcbef76094b36a4aa4e60aecc7cd98d109d06.jpg', '', '1', '', '0', '0', '0', 'http://app.baiyug.cn:2019/vip/index.php?url=', '高清HD$http://video.mtime.com/73778/?mid=25412', NULL, '预告片', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_videogroup`
--

CREATE TABLE IF NOT EXISTS `aikcms_videogroup` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aik_videogroup_name` varchar(255) NOT NULL,
  `aik_videogroup_usergroup` varchar(68) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`aik_videogroup_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `aikcms_videogroup`
--

INSERT INTO `aikcms_videogroup` (`id`, `aik_videogroup_name`, `aik_videogroup_usergroup`) VALUES
(1, '动作片', '0'),
(2, '喜剧片', '0'),
(3, '会员专属', '1,2,3');

-- --------------------------------------------------------

--
-- 表的结构 `aikcms_zhibo`
--

CREATE TABLE IF NOT EXISTS `aikcms_zhibo` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aik_zhibo_name` varchar(255) NOT NULL,
  `aik_zhibo_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`aik_zhibo_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=80 ;

--
-- 转存表中的数据 `aikcms_zhibo`
--

INSERT INTO `aikcms_zhibo` (`id`, `aik_zhibo_name`, `aik_zhibo_url`) VALUES
(1, 'CCTV-1高清', 'http://ivi.bupt.edu.cn/player.html?channel=cctv1hd'),
(2, 'CCTV-3高清', 'http://ivi.bupt.edu.cn/player.html?channel=cctv3hd'),
(3, 'CCTV-5+高清', 'http://ivi.bupt.edu.cn/player.html?channel=cctv5phd'),
(4, 'CCTV-6高清', 'http://ivi.bupt.edu.cn/player.html?channel=cctv6hd'),
(5, 'CCTV-8高清', 'http://ivi.bupt.edu.cn/player.html?channel=cctv8hd'),
(6, 'CHC高清电影', 'http://ivi.bupt.edu.cn/player.html?channel=chchd'),
(7, '北京卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=btv1hd'),
(8, '北京文艺高清', 'http://ivi.bupt.edu.cn/player.html?channel=btv2hd'),
(9, '北京纪实高清', 'http://ivi.bupt.edu.cn/player.html?channel=btv11hd'),
(10, '湖南卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=hunanhd'),
(11, '浙江卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=zjhd'),
(12, '江苏卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=jshd'),
(13, '东方卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=dfhd'),
(14, '安徽卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=ahhd'),
(15, '黑龙江卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=hljhd'),
(16, '辽宁卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=lnhd'),
(17, '深圳卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=szhd'),
(18, '广东卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=gdhd'),
(19, '天津卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=tjhd'),
(20, '湖北卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=hbhd'),
(21, '山东卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=sdhd'),
(22, '重庆卫视高清', 'http://ivi.bupt.edu.cn/player.html?channel=cqhd'),
(23, 'CCTV-1综合', 'http://ivi.bupt.edu.cn/player.html?channel=cctv1'),
(24, 'CCTV-2财经', 'http://ivi.bupt.edu.cn/player.html?channel=cctv2'),
(25, 'CCTV-3综艺', 'http://ivi.bupt.edu.cn/player.html?channel=cctv3'),
(26, 'CCTV-4中文国际', 'http://ivi.bupt.edu.cn/player.html?channel=cctv4'),
(27, 'CCTV-6电影', 'http://ivi.bupt.edu.cn/player.html?channel=cctv6'),
(28, 'CCTV-7军事农业', 'http://ivi.bupt.edu.cn/player.html?channel=cctv7'),
(29, 'CCTV-8电视剧', 'http://ivi.bupt.edu.cn/player.html?channel=cctv8'),
(30, 'CCTV-9纪录', 'http://ivi.bupt.edu.cn/player.html?channel=cctv9'),
(31, 'CCTV-10科教', 'http://ivi.bupt.edu.cn/player.html?channel=cctv10'),
(32, 'CCTV-11戏曲', 'http://ivi.bupt.edu.cn/player.html?channel=cctv11'),
(33, 'CCTV-12社会与法', 'http://ivi.bupt.edu.cn/player.html?channel=cctv12'),
(34, 'CCTV-13新闻', 'http://ivi.bupt.edu.cn/player.html?channel=cctv13'),
(35, 'CCTV-14少儿', 'http://ivi.bupt.edu.cn/player.html?channel=cctv14'),
(36, 'CCTV-15音乐', 'http://ivi.bupt.edu.cn/player.html?channel=cctv15'),
(37, 'CCTV-NEWS', 'http://ivi.bupt.edu.cn/player.html?channel=cctv16'),
(38, '北京卫视', 'http://ivi.bupt.edu.cn/player.html?channel=btv1'),
(39, '北京文艺', 'http://ivi.bupt.edu.cn/player.html?channel=btv2'),
(40, '北京科教', 'http://ivi.bupt.edu.cn/player.html?channel=btv3'),
(41, '北京影视', 'http://ivi.bupt.edu.cn/player.html?channel=btv4'),
(42, '北京财经', 'http://ivi.bupt.edu.cn/player.html?channel=btv5'),
(43, '北京生活', 'http://ivi.bupt.edu.cn/player.html?channel=btv7'),
(44, '北京青年', 'http://ivi.bupt.edu.cn/player.html?channel=btv8'),
(45, '北京新闻', 'http://ivi.bupt.edu.cn/player.html?channel=btv9'),
(46, '北京卡酷少儿', 'http://ivi.bupt.edu.cn/player.html?channel=btv10'),
(47, '深圳卫视', 'http://ivi.bupt.edu.cn/player.html?channel=sztv'),
(48, '安徽卫视', 'http://ivi.bupt.edu.cn/player.html?channel=ahtv'),
(49, '河南卫视', 'http://ivi.bupt.edu.cn/player.html?channel=hntv'),
(50, '陕西卫视', 'http://ivi.bupt.edu.cn/player.html?channel=sxtv'),
(51, '吉林卫视', 'http://ivi.bupt.edu.cn/player.html?channel=jltv'),
(52, '广东卫视', 'http://ivi.bupt.edu.cn/player.html?channel=gdtv'),
(53, '山东卫视', 'http://ivi.bupt.edu.cn/player.html?channel=sdtv'),
(54, '湖北卫视', 'http://ivi.bupt.edu.cn/player.html?channel=hbtv'),
(55, '广西卫视', 'http://ivi.bupt.edu.cn/player.html?channel=gxtv'),
(56, '河北卫视', 'http://ivi.bupt.edu.cn/player.html?channel=hebtv'),
(57, '西藏卫视', 'http://ivi.bupt.edu.cn/player.html?channel=xztv'),
(58, '内蒙古卫视', 'http://ivi.bupt.edu.cn/player.html?channel=nmtv'),
(59, '青海卫视', 'http://ivi.bupt.edu.cn/player.html?channel=qhtv'),
(60, '四川卫视', 'http://ivi.bupt.edu.cn/player.html?channel=sctv'),
(61, '江苏卫视', 'http://ivi.bupt.edu.cn/player.html?channel=jstv'),
(62, '天津卫视', 'http://ivi.bupt.edu.cn/player.html?channel=tjtv'),
(63, '山西卫视', 'http://ivi.bupt.edu.cn/player.html?channel=sxrtv'),
(64, '辽宁卫视', 'http://ivi.bupt.edu.cn/player.html?channel=lntv'),
(65, '厦门卫视', 'http://ivi.bupt.edu.cn/player.html?channel=xmtv'),
(66, '新疆卫视', 'http://ivi.bupt.edu.cn/player.html?channel=xjtv'),
(67, '东方卫视', 'http://ivi.bupt.edu.cn/player.html?channel=dftv'),
(68, '黑龙江卫视', 'http://ivi.bupt.edu.cn/player.html?channel=hljtv'),
(69, '湖南卫视', 'http://ivi.bupt.edu.cn/player.html?channel=hunantv'),
(70, '云南卫视', 'http://ivi.bupt.edu.cn/player.html?channel=yntv'),
(71, '江西卫视', 'http://ivi.bupt.edu.cn/player.html?channel=jxtv'),
(72, '福建东南卫视', 'http://ivi.bupt.edu.cn/player.html?channel=dntv'),
(73, '浙江卫视', 'http://ivi.bupt.edu.cn/player.html?channel=zjtv'),
(74, '贵州卫视', 'http://ivi.bupt.edu.cn/player.html?channel=gztv'),
(75, '宁夏卫视', 'http://ivi.bupt.edu.cn/player.html?channel=nxtv'),
(76, '甘肃卫视', 'http://ivi.bupt.edu.cn/player.html?channel=gstv'),
(77, '重庆卫视', 'http://ivi.bupt.edu.cn/player.html?channel=cqtv'),
(78, '兵团卫视', 'http://ivi.bupt.edu.cn/player.html?channel=bttv'),
(79, '旅游卫视', 'http://ivi.bupt.edu.cn/player.html?channel=lytv');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
